# Nearby Chat / چت نزدیک 2.0
Offline messenger (Bluetooth + Wi-Fi via Google Nearby Connections): chat, groups, files, voice calls,
history, notifications, background connection, profile photo, themes, English + Persian.

Build: put this zip in the repo root; the GitHub Action unzips it and builds the APK (Artifacts -> NearbyChat-apk).

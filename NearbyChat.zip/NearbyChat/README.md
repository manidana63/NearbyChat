# Nearby Chat / چت نزدیک

Offline messenger for Android (Bluetooth + Wi-Fi via Google Nearby Connections): text, files, voice calls. English + Persian.

## Get the APK from GitHub
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab → **Build APK** → wait until it turns green (~3–5 min). You can also press **Run workflow**.
3. Open the finished run → **Artifacts** → download `NearbyChat-apk` → unzip → `app-debug.apk`.
4. Copy the APK to both phones and install (allow "install unknown apps").

## Use
Open the app on both phones, enter a name, tap Start, allow permissions, tap the other device under "Nearby devices".
Requires Google Play Services on both phones.

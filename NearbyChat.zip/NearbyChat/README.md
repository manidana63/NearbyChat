# Nearby Chat / چت نزدیک 3.0
Offline messenger for Android with its own transport (no Google services):
- Wi-Fi: phones on the same network (router or one phone's hotspot) find each other (UDP beacons) and talk over TCP.
- Bluetooth: classic RFCOMM; first time pair the phones (or make one visible and scan), after that it reconnects by itself.
Chat, groups, files, voice calls, history, notifications, backup, English + Persian.
The app never turns Bluetooth or Wi-Fi on by itself.

Build: put this zip in the repo root; the GitHub Action unzips it and builds the APK (Artifacts -> NearbyChat-apk).

package com.example.nearbychat

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val faMonths = listOf(
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
)

fun faDigits(s: String): String = buildString {
    s.forEach { append(if (it in '0'..'9') '۰' + (it - '0') else it) }
}

/** Gregorian -> Jalali (Solar Hijri). Returns [year, month, day]. */
fun gregorianToJalali(gy: Int, gm: Int, gd: Int): IntArray {
    val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
    val gy2 = if (gm > 2) gy + 1 else gy
    var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gdm[gm - 1]
    var jy = -1595 + (33 * (days / 12053))
    days %= 12053
    jy += 4 * (days / 1461)
    days %= 1461
    if (days > 365) {
        jy += (days - 1) / 365
        days = (days - 1) % 365
    }
    val jm: Int
    val jd: Int
    if (days < 186) { jm = 1 + days / 31; jd = 1 + days % 31 }
    else { jm = 7 + (days - 186) / 30; jd = 1 + (days - 186) % 30 }
    return intArrayOf(jy, jm, jd)
}

private fun parts(t: Long): IntArray {
    val c = Calendar.getInstance().apply { timeInMillis = t }
    return intArrayOf(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}

fun dayKey(t: Long): Int = parts(t).let { it[0] * 10000 + it[1] * 100 + it[2] }

/** cal: 0 = Gregorian, 1 = Jalali */
fun fmtDate(t: Long, cal: Int): String {
    val p = parts(t)
    return if (cal == 1) {
        val j = gregorianToJalali(p[0], p[1], p[2])
        faDigits("${j[2]} ${faMonths[j[1] - 1]} ${j[0]}")
    } else SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(t))
}

fun fmtClock(t: Long, cal: Int): String {
    val s = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
    return if (cal == 1) faDigits(s) else s
}

fun fmtFull(t: Long, cal: Int) = fmtDate(t, cal) + "  " + fmtClock(t, cal)

/** Chat-list style: time for today, short date otherwise. */
fun fmtShort(t: Long, cal: Int): String {
    if (dayKey(t) == dayKey(System.currentTimeMillis())) return fmtClock(t, cal)
    val p = parts(t)
    return if (cal == 1) {
        val j = gregorianToJalali(p[0], p[1], p[2])
        faDigits("${j[2]} ${faMonths[j[1] - 1]}")
    } else SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(t))
}

package com.example.nearbychat

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------- bottom bar

@Composable
fun MainBottomBar(tab: Int, chatBadge: Int, onTab: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(color = cs.surface, shadowElevation = 10.dp) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 6.dp)) {
            val items = listOf("📞" to R.string.tab_calls, "👤" to R.string.tab_contacts, "✉️" to R.string.tab_messages, "💬" to R.string.tab_chats)
            items.forEachIndexed { i, (emoji, label) ->
                val sel = tab == i
                val sc by animateFloatAsState(if (sel) 1.18f else 1f, label = "tab")
                val pill by animateColorAsState(if (sel) cs.primaryContainer else Color.Transparent, label = "pill")
                Column(Modifier.weight(1f).clickable { onTab(i) }.padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(contentAlignment = Alignment.TopEnd) {
                        Box(Modifier.clip(RoundedCornerShape(16.dp)).background(pill).padding(horizontal = 20.dp, vertical = 4.dp)) {
                            Text(emoji, fontSize = 20.sp, modifier = Modifier.scale(sc))
                        }
                        if (i == 3 && chatBadge > 0) Box(Modifier.size(16.dp).clip(CircleShape).background(Color(0xFFD32F2F)), contentAlignment = Alignment.Center) {
                            Text(if (chatBadge > 9) "9+" else "$chatBadge", color = Color.White, fontSize = 9.sp)
                        }
                    }
                    Text(stringResource(label), fontSize = 11.sp, color = if (sel) cs.primary else cs.onSurfaceVariant,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- messages (SMS)

@Composable
fun MessagesTab(net: Net, nav: PhoneNav) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val perm = rememberPerm(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_CONTACTS)
    val ver = PhoneRepo.version
    val threads by produceState(emptyList<SmsThread>(), ver, perm.granted) {
        value = withContext(Dispatchers.IO) { PhoneRepo.threads(PhoneRepo.loadSms(ctx)) }
    }
    var q by remember { mutableStateOf("") }
    val isDef = remember(ver) { PhoneRepo.isDefaultSms(ctx) }
    val role = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { PhoneRepo.bump() }
    val visible = threads.filter { t ->
        !PhoneRepo.isBlockedKey(t.key, true) && (q.isBlank() ||
            (PhoneRepo.nameFor(t.address) ?: t.address).contains(q, true) || t.last.body.contains(q, true))
    }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (!perm.granted) PermGate(R.string.perm_sms, perm) else {
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, singleLine = true,
                    placeholder = { Text(stringResource(R.string.search)) },
                    shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().padding(12.dp)
                )
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
                    if (!isDef) item(key = "banner") {
                        Surface(color = cs.primaryContainer, shape = RoundedCornerShape(16.dp), modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(stringResource(R.string.sms_default_hint), fontSize = 14.sp)
                                Button(onClick = { try { role.launch(PhoneRepo.roleIntent(ctx, true)) } catch (_: Exception) {} }) {
                                    Text(stringResource(R.string.set_default))
                                }
                            }
                        }
                    }
                    items(visible, key = { it.key }) { t -> ThreadRow(net, t) { nav.sms(t.key, t.address) } }
                }
            }
        }
        FloatingActionButton(
            onClick = { nav.newSms("") }, containerColor = cs.primary, contentColor = cs.onPrimary,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
        ) { Icon(Icons.Filled.Add, stringResource(R.string.new_message)) }
    }
}

@Composable
fun ThreadRow(net: Net, t: SmsThread, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val name = PhoneRepo.nameFor(t.address) ?: net.numStr(t.address)
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        GenericAvatar(PhoneRepo.nameFor(t.address) ?: t.address, 50.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(name, Modifier.weight(1f), fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontWeight = if (t.unread > 0) FontWeight.Bold else FontWeight.Medium)
                Text(fmtShort(t.last.date, net.calendar), fontSize = 12.sp, color = if (t.unread > 0) cs.primary else cs.onSurfaceVariant)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text((if (t.last.type != 1) stringResource(R.string.you) + ": " else "") + t.last.body, Modifier.weight(1f),
                    fontSize = 14.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (t.unread > 0) {
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.defaultMinSize(22.dp, 22.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
                        Text(net.numStr("${t.unread}"), color = cs.onPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SmsBubble(net: Net, m: SmsMsg, onLink: (Int, String) -> Unit, onLong: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val mine = m.type != 1
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Surface(color = if (mine) cs.primaryContainer else cs.surface, shape = RoundedCornerShape(net.bubbleDp()),
            shadowElevation = 1.dp, modifier = Modifier.widthIn(max = 300.dp)) {
            Column(Modifier.combinedClickable(onClick = {}, onLongClick = onLong).padding(horizontal = 10.dp, vertical = 6.dp)) {
                LinkText(m.body, 16.sp, LocalContentColor.current, cs.primary, false, onPlainTap = {}, onLong = onLong, onLink = onLink)
                Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                    Text(fmtClock(m.date, net.calendar), fontSize = 11.sp, color = cs.onSurfaceVariant)
                    if (m.type == 5) Text("  ⚠", fontSize = 12.sp, color = Color(0xFFD32F2F))
                }
            }
        }
    }
}

@Composable
fun SimChips(sims: List<SimInfo>, slot: Int, onPick: (Int) -> Unit) {
    if (sims.size < 2) return
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        sims.forEach { s -> FilterChip(selected = slot == s.slot, onClick = { onPick(if (slot == s.slot) -1 else s.slot) },
            label = { Text(s.short.ifEmpty { "SIM ${s.slot + 1}" }) }) }
    }
}

@Composable
fun SmsThreadScreen(net: Net, key: String, address: String, onBack: () -> Unit, nav: PhoneNav) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val ver = PhoneRepo.version
    val msgs by produceState(emptyList<SmsMsg>(), ver, key) {
        value = withContext(Dispatchers.IO) { PhoneRepo.loadSms(ctx).filter { PhoneRepo.keyOf(it.address) == key }.sortedBy { it.date } }
    }
    val cname = PhoneRepo.nameFor(address)
    val title = cname ?: net.numStr(address)
    val sims = remember { PhoneRepo.sims(ctx) }
    var slot by remember {
        mutableIntStateOf(PhoneRepo.simRule(ctx, address).let { if (it >= 0) it else if (net.simSms >= 0) net.simSms else -1 })
    }
    var text by rememberSaveable { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var delAll by remember { mutableStateOf(false) }
    var msgSel by remember { mutableStateOf<SmsMsg?>(null) }
    val listState = rememberLazyListState()
    var firstScroll by remember { mutableStateOf(true) }
    var linkAction by remember { mutableStateOf<Pair<Int, String>?>(null) }
    val blockedNow = PhoneRepo.blocked.any { it.key == key }

    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) {
            withContext(Dispatchers.IO) { PhoneRepo.markRead(ctx, key) }
            if (firstScroll) { listState.scrollToItem(msgs.size - 1); firstScroll = false }
            else listState.animateScrollToItem(msgs.size - 1)
        }
    }

    fun doSend() {
        val subId = sims.firstOrNull { it.slot == slot }?.subId ?: -1
        net.requestSend(1, address, text.trim(), null, subId)
        text = ""
    }

    CallerHost(net) { call ->
        Column(Modifier.fillMaxSize().background(cs.background)) {
            TopBar(title, onBack, subtitle = if (cname != null) net.numStr(address) else null,
                lead = { GenericAvatar(cname ?: address, 38.dp) }) {
                IconButton(onClick = { call(address, -1) }) { Icon(Icons.Filled.Call, stringResource(R.string.call), tint = Color.White) }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null, tint = Color.White) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(if (blockedNow) R.string.unblock else R.string.block)) },
                            onClick = {
                                menu = false
                                if (blockedNow) PhoneRepo.unblock(ctx, key) else PhoneRepo.block(ctx, address)
                            })
                        DropdownMenuItem(text = { Text(stringResource(R.string.delete_conversation)) }, onClick = { menu = false; delAll = true })
                        if (cname == null) DropdownMenuItem(text = { Text(stringResource(R.string.add_to_contacts)) },
                            onClick = { menu = false; nav.form(-1L, address) })
                    }
                }
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(vertical = 8.dp)) {
                itemsIndexed(msgs, key = { _, m -> "${m.id}-${m.date}" }) { i, m ->
                    Column {
                        if (i == 0 || dayKey(msgs[i - 1].date) != dayKey(m.date)) DateChip(fmtDate(m.date, net.calendar))
                        SmsBubble(net, m, { k, v -> linkAction = k to v }) { msgSel = m }
                    }
                }
            }
            Surface(color = cs.surface, shadowElevation = 6.dp) {
                Column(Modifier.padding(6.dp)) {
                    net.pendingSends.filter { it.kind == 1 && PhoneRepo.keyOf(it.conv) == key }.forEach { p ->
                        SendCountdown(net, p) { net.cancelSend(p); if (text.isBlank()) text = p.text }
                    }
                    if (sims.size >= 2) Row(Modifier.padding(start = 8.dp, bottom = 4.dp)) { SimChips(sims, slot) { slot = it } }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = text, onValueChange = { text = it },
                            placeholder = { Text(stringResource(R.string.type_message)) },
                            shape = RoundedCornerShape(24.dp), maxLines = 5, modifier = Modifier.weight(1f))
                        Spacer(Modifier.width(6.dp))
                        val ok = text.isNotBlank()
                        Box(Modifier.size(48.dp).clip(CircleShape).background(if (ok) cs.primary else cs.surfaceVariant)
                            .clickable(enabled = ok) { doSend() }, contentAlignment = Alignment.Center) {
                            Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.send), tint = if (ok) cs.onPrimary else cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    linkAction?.let { LinkActionDialog(it.first, it.second) { linkAction = null } }

    if (delAll) AlertDialog(
        onDismissRequest = { delAll = false },
        text = { Text(stringResource(R.string.confirm_delete_conversation)) },
        confirmButton = {
            TextButton(onClick = {
                delAll = false
                if (PhoneRepo.isDefaultSms(ctx)) { PhoneRepo.deleteThread(ctx, key); onBack() }
                else { Toast.makeText(ctx, R.string.need_default_sms, Toast.LENGTH_LONG).show() }
            }) { Text(stringResource(R.string.delete)) }
        },
        dismissButton = { TextButton(onClick = { delAll = false }) { Text(stringResource(R.string.cancel)) } }
    )

    msgSel?.let { m ->
        AlertDialog(
            onDismissRequest = { msgSel = null },
            text = {
                Column {
                    TextButton(onClick = {
                        msgSel = null
                        try { ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("sms", m.body)) } catch (_: Exception) {}
                    }) { Text(stringResource(R.string.copy)) }
                    TextButton(onClick = {
                        msgSel = null
                        if (m.id < 0 || PhoneRepo.isDefaultSms(ctx)) { PhoneRepo.deleteSms(ctx, m.id); PhoneRepo.bump() }
                        else Toast.makeText(ctx, R.string.need_default_sms, Toast.LENGTH_LONG).show()
                    }) { Text(stringResource(R.string.delete), color = Color(0xFFD32F2F)) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { msgSel = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

// ---------------------------------------------------------------- contact details

@Composable
fun ContactInfoScreen(net: Net, id: Long, onBack: () -> Unit, nav: PhoneNav) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val ver = PhoneRepo.version
    val c = remember(id, ver) { PhoneRepo.contacts.firstOrNull { it.id == id } }
    val scope = rememberCoroutineScope()
    val writePerm = rememberPerm(Manifest.permission.WRITE_CONTACTS, Manifest.permission.READ_CONTACTS)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null && c != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                val b = PhoneRepo.photoBytes(ctx, u)
                b != null && PhoneRepo.setContactPhoto(ctx, c.id, b)
            }
            PhoneRepo.bump()
            if (!ok) Toast.makeText(ctx, R.string.connect_failed, Toast.LENGTH_SHORT).show()
        }
    }
    val sims = remember { PhoneRepo.sims(ctx) }
    if (c == null) {
        Column(Modifier.fillMaxSize()) { TopBar("", onBack) }
        return
    }
    CallerHost(net) { call ->
        Column(Modifier.fillMaxSize().background(cs.background).verticalScroll(rememberScrollState())) {
            TopBar(c.name, onBack) {
                TextButton(onClick = { nav.form(c.id, "") }) { Text(stringResource(R.string.edit), color = Color.White) }
            }
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.clip(CircleShape).clickable { if (!writePerm.granted) writePerm.request() else picker.launch("image/*") }) {
                    GenericAvatar(c.name, 120.dp, c.photoFull ?: c.photo)
                    Box(Modifier.align(Alignment.BottomEnd).size(34.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
                        Text("📷", fontSize = 16.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(c.name, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            }
            c.emails.forEach { em ->
                Surface(shape = RoundedCornerShape(16.dp), color = cs.surface, shadowElevation = 1.dp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Row(Modifier.fillMaxWidth().clickable {
                        try { ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$em"))) } catch (_: Exception) {}
                    }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("✉️", fontSize = 18.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(em, fontSize = 16.sp)
                    }
                }
            }
            c.numbers.forEach { n ->
                var rule by remember(n) { mutableIntStateOf(PhoneRepo.simRule(ctx, n)) }
                val k = PhoneRepo.keyOf(n)
                val isBlocked = PhoneRepo.blocked.any { it.key == k }
                val appUser = net.phoneToUser[PhoneRepo.norm(n)]
                Surface(shape = RoundedCornerShape(16.dp), color = cs.surface, shadowElevation = 1.dp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(net.numStr(n), Modifier.weight(1f), fontSize = 20.sp)
                            IconButton(onClick = { call(n, -1) }) { Icon(Icons.Filled.Call, stringResource(R.string.call), tint = Color(0xFF25D366)) }
                            IconButton(onClick = { nav.sms(k, n) }) { Text("💬", fontSize = 20.sp) }
                        }
                        if (sims.size >= 2) {
                            Text(stringResource(R.string.call_with), fontSize = 12.sp, color = cs.onSurfaceVariant)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(selected = rule < 0, onClick = { rule = -1; PhoneRepo.setSimRule(ctx, n, -1) },
                                    label = { Text(stringResource(R.string.sim_default)) })
                                sims.forEach { s ->
                                    FilterChip(selected = rule == s.slot, onClick = { rule = s.slot; PhoneRepo.setSimRule(ctx, n, s.slot) },
                                        label = { Text(s.short.ifEmpty { "SIM ${s.slot + 1}" }) })
                                }
                            }
                        }
                        if (appUser != null) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (net.online.contains(appUser)) Button(onClick = { nav.appCall(appUser) }) { Text("📲 " + stringResource(R.string.free_call)) }
                            OutlinedButton(onClick = { nav.chat(appUser) }) { Text(stringResource(R.string.chat_in_app)) }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(stringResource(R.string.block_number), Modifier.weight(1f), fontSize = 14.sp)
                            Switch(checked = isBlocked, onCheckedChange = { if (it) PhoneRepo.block(ctx, n) else PhoneRepo.unblock(ctx, k) })
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ---------------------------------------------------------------- blocked

@Composable
fun BlockedScreen(net: Net, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var num by remember { mutableStateOf("") }
    var unk by remember { mutableStateOf(PhoneRepo.prefs(ctx).getBoolean("blk_unknown", false)) }
    var priv by remember { mutableStateOf(PhoneRepo.prefs(ctx).getBoolean("blk_private", false)) }
    val perm = rememberPerm(Manifest.permission.READ_CONTACTS)
    Column(Modifier.fillMaxSize().background(cs.background)) {
        TopBar(stringResource(R.string.blocked_title), onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.block_hint), fontSize = 13.sp, color = cs.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = num, onValueChange = { num = it }, singleLine = true,
                            label = { Text(stringResource(R.string.number)) }, modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                        Button(onClick = { if (num.isNotBlank()) { PhoneRepo.block(ctx, PhoneRepo.ascii(num).trim()); num = "" } }) {
                            Text(stringResource(R.string.block))
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.block_unknown), Modifier.weight(1f))
                        Switch(checked = unk, onCheckedChange = {
                            unk = it
                            PhoneRepo.prefs(ctx).edit().putBoolean("blk_unknown", it).apply()
                            if (it && !perm.granted) perm.request()
                        })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.block_private), Modifier.weight(1f))
                        Switch(checked = priv, onCheckedChange = { priv = it; PhoneRepo.prefs(ctx).edit().putBoolean("blk_private", it).apply() })
                    }
                }
            }
            item { SecLabel(stringResource(R.string.blocked_numbers)) }
            if (PhoneRepo.blocked.isEmpty()) item {
                Text(stringResource(R.string.none_blocked), color = cs.onSurfaceVariant, modifier = Modifier.padding(16.dp))
            }
            items(PhoneRepo.blocked.toList(), key = { "b" + it.key }) { b ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    GenericAvatar(b.label, 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(net.numStr(b.label), fontSize = 16.sp, maxLines = 1)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = b.calls, onClick = { PhoneRepo.update(ctx, b.copy(calls = !b.calls)) },
                                label = { Text(stringResource(R.string.f_calls)) })
                            FilterChip(selected = b.sms, onClick = { PhoneRepo.update(ctx, b.copy(sms = !b.sms)) },
                                label = { Text(stringResource(R.string.f_sms)) })
                        }
                    }
                    IconButton(onClick = { PhoneRepo.unblock(ctx, b.key) }) { Icon(Icons.Filled.Close, stringResource(R.string.unblock)) }
                }
            }
            item { SecLabel(stringResource(R.string.blocked_history)) }
            if (PhoneRepo.blockLog.isEmpty()) item {
                Text(stringResource(R.string.none_blocked_yet), color = cs.onSurfaceVariant, modifier = Modifier.padding(16.dp))
            }
            items(PhoneRepo.blockLog.toList(), key = { "e${it.time}${it.key}${it.kind}" }) { e ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Text((if (e.kind == "call") "📞 " else "✉️ ") + (PhoneRepo.nameFor(e.key) ?: net.numStr(e.key)), fontSize = 15.sp)
                    Text(fmtFull(e.time, net.calendar), fontSize = 12.sp, color = cs.onSurfaceVariant)
                    if (e.text.isNotBlank()) Text(e.text, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}


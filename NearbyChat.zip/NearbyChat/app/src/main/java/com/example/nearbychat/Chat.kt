package com.example.nearbychat

import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread
import kotlin.math.abs

class Ask(val msg: Int, val action: () -> Unit)

/** 0 image, 1 video, 2 audio, 3 other */
fun kindOf(name: String): Int = when (name.substringAfterLast('.', "").lowercase()) {
    "jpg", "jpeg", "png", "webp", "gif", "bmp" -> 0
    "mp4", "mkv", "webm", "3gp", "mov", "avi" -> 1
    "mp3", "m4a", "aac", "wav", "ogg", "opus", "flac" -> 2
    else -> 3
}

@Composable
fun ChatScreen(net: Net, id: String, onBack: () -> Unit, onCall: (String) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val group = net.isGroup(id)
    val title = net.title(id)
    val g = net.groups.find { it.id == id }
    val msgs = net.chats.getOrPut(id) { mutableStateListOf() }
    var text by rememberSaveable { mutableStateOf("") }
    var pending by remember { mutableStateOf<Attach?>(null) }
    val selected = remember { mutableStateListOf<String>() }
    var ask by remember { mutableStateOf<Ask?>(null) }
    var delDialog by remember { mutableStateOf(false) }
    var showList by remember { mutableStateOf(false) }
    var attachMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var toSave by remember { mutableStateOf<Msg?>(null) }
    val listState = rememberLazyListState()
    val selecting = selected.isNotEmpty()
    BackHandler(selecting) { selected.clear() }

    DisposableEffect(id) {
        net.activeChat = id
        net.markRead(id)
        onDispose { if (net.activeChat == id) net.activeChat = null }
    }
    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) {
            net.markRead(id)
            listState.animateScrollToItem(msgs.size - 1)
        }
    }
    LaunchedEffect(group && g == null) { if (group && g == null) onBack() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val n = net.displayName(uri)
            val mime = ctx.contentResolver.getType(uri)
            pending = Attach(uri, n, mime?.startsWith("image/") == true || isImage(n))
        }
    }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        val m = toSave
        toSave = null
        val p = m?.filePath
        if (uri != null && p != null) {
            thread {
                val ok = try {
                    ctx.contentResolver.openOutputStream(uri)?.use { o -> File(p).inputStream().use { it.copyTo(o) } }
                    true
                } catch (_: Exception) { false }
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(ctx, if (ok) R.string.saved else R.string.connect_failed, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun save(m: Msg) {
        toSave = m
        saver.launch(m.fileName ?: "file")
    }

    fun doSend() {
        val a = pending
        if (a != null) {
            if (!net.canSendNow(id)) {
                Toast.makeText(ctx, R.string.offline, Toast.LENGTH_SHORT).show()
                return
            }
            net.sendFile(id, a.uri)
        }
        if (text.isNotBlank()) net.sendText(id, text.trim())
        pending = null
        text = ""
    }

    val isOnline = !group && net.online.contains(id)
    val ls = net.lastSeen[id] ?: 0L
    val subtitle = when {
        group -> stringResource(R.string.members_count, g?.members?.size ?: 0)
        isOnline -> stringResource(R.string.online)
        ls > 0 -> stringResource(R.string.last_seen, fmtFull(ls, net.calendar))
        else -> stringResource(R.string.offline_status)
    }

    Column(Modifier.fillMaxSize().background(cs.background)) {
        if (selecting) {
            TopBar(stringResource(R.string.selected_count, selected.size), onBack = { selected.clear() }) {
                val one = if (selected.size == 1) msgs.find { it.id == selected[0] } else null
                if (one?.filePath != null) TextButton(onClick = { save(one) }) {
                    Text(stringResource(R.string.save_file), color = Color.White)
                }
                IconButton(onClick = { delDialog = true }) { Icon(Icons.Filled.Delete, stringResource(R.string.delete), tint = Color.White) }
            }
        } else {
            TopBar(title, onBack, subtitle, lead = { Avatar(net, id, title, 38.dp, group = group) }) {
                if (isOnline) IconButton(onClick = { onCall(id) }) {
                    Icon(Icons.Filled.Call, stringResource(R.string.call), tint = Color.White)
                }
                Box {
                    IconButton(onClick = { moreMenu = true }) { Icon(Icons.Filled.MoreVert, null, tint = Color.White) }
                    DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                        DropdownMenuItem(text = { Text(stringResource(R.string.clear_history)) }, onClick = {
                            moreMenu = false
                            ask = Ask(R.string.confirm_clear) { net.clearChat(id); selected.clear() }
                        })
                        if (group && g != null) {
                            if (g.creator == net.myId) {
                                DropdownMenuItem(text = { Text(stringResource(R.string.delete_group)) }, onClick = {
                                    moreMenu = false
                                    ask = Ask(R.string.confirm_delete_group_all) { net.deleteGroup(id); onBack() }
                                })
                            } else {
                                DropdownMenuItem(text = { Text(stringResource(R.string.delete_group_local)) }, onClick = {
                                    moreMenu = false
                                    ask = Ask(R.string.confirm_delete_group_local) { net.deleteGroup(id); onBack() }
                                })
                            }
                        }
                    }
                }
            }
        }

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(vertical = 8.dp)) {
            itemsIndexed(msgs, key = { _, m -> m.id }) { i, m ->
                Column {
                    if (i == 0 || (i - 1 < msgs.size && dayKey(msgs[i - 1].time) != dayKey(m.time)))
                        DateChip(fmtDate(m.time, net.calendar))
                    Bubble(
                        m = m, group = group, selected = selected.contains(m.id), selecting = selecting, cal = net.calendar,
                        onToggle = { if (selected.contains(m.id)) selected.remove(m.id) else selected.add(m.id) },
                        onSave = { save(it) },
                        onItem = { idx -> net.toggleItem(id, m.id, idx) }
                    )
                }
            }
        }

        Surface(color = cs.surface, shadowElevation = 6.dp) {
            Column(Modifier.animateContentSize()) {
                pending?.let { a ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        val bmp = if (a.image) rememberUriBitmap(a.uri, 200) else null
                        Box(Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant), contentAlignment = Alignment.Center) {
                            if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else Text(when (kindOf(a.name)) { 1 -> "🎬"; 2 -> "🎵"; else -> "📎" }, fontSize = 24.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(a.name, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        IconButton(onClick = { pending = null }) { Icon(Icons.Filled.Close, null) }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box {
                        IconButton(onClick = { attachMenu = true }) {
                            Icon(Icons.Filled.Add, stringResource(R.string.attach), tint = cs.primary)
                        }
                        DropdownMenu(expanded = attachMenu, onDismissRequest = { attachMenu = false }) {
                            DropdownMenuItem(text = { Text("📎  " + stringResource(R.string.file_label)) }, onClick = {
                                attachMenu = false; picker.launch("*/*")
                            })
                            DropdownMenuItem(text = { Text("🛒  " + stringResource(R.string.shopping_list)) }, onClick = {
                                attachMenu = false; showList = true
                            })
                        }
                    }
                    OutlinedTextField(
                        value = text, onValueChange = { text = it },
                        placeholder = { Text(stringResource(R.string.type_message)) },
                        shape = RoundedCornerShape(24.dp), maxLines = 4, modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(6.dp))
                    val ok = text.isNotBlank() || pending != null
                    val bg by animateColorAsState(if (ok) cs.primary else cs.surfaceVariant, tween(200), label = "send")
                    Box(Modifier.size(48.dp).clip(CircleShape).background(bg).clickable(enabled = ok) { doSend() },
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.send),
                            tint = if (ok) cs.onPrimary else cs.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (showList) ShoppingListDialog(net.calendar, onDismiss = { showList = false }) { t, items ->
        net.sendList(id, t, items)
        showList = false
    }

    if (delDialog) {
        val canAll = selected.isNotEmpty() && selected.all { sid -> msgs.find { it.id == sid }?.mine == true }
        AlertDialog(
            onDismissRequest = { delDialog = false },
            title = { Text(stringResource(R.string.delete_messages_title)) },
            text = {
                Column {
                    TextButton(onClick = {
                        net.deleteMessages(id, selected.toSet()); selected.clear(); delDialog = false
                    }) { Text(stringResource(R.string.delete_for_me)) }
                    if (canAll) TextButton(onClick = {
                        net.deleteForEveryone(id, selected.toSet()); selected.clear(); delDialog = false
                    }) { Text(stringResource(R.string.delete_for_all), color = Color(0xFFD32F2F)) }
                    TextButton(onClick = { delDialog = false }) { Text(stringResource(R.string.cancel)) }
                }
            },
            confirmButton = {}
        )
    }

    ask?.let { a ->
        AlertDialog(
            onDismissRequest = { ask = null },
            text = { Text(stringResource(a.msg)) },
            confirmButton = { TextButton(onClick = { a.action(); ask = null }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton(onClick = { ask = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
fun DateChip(t: String) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        Surface(shape = RoundedCornerShape(12.dp), color = cs.surfaceVariant) {
            Text(t, fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Bubble(
    m: Msg, group: Boolean, selected: Boolean, selecting: Boolean, cal: Int,
    onToggle: () -> Unit, onSave: (Msg) -> Unit, onItem: (Int) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val fresh = remember { System.currentTimeMillis() - m.time < 2000 }
    val a = remember { Animatable(if (fresh) 0f else 1f) }
    LaunchedEffect(Unit) { if (fresh) a.animateTo(1f, tween(260, easing = FastOutSlowInEasing)) }
    val shape = if (m.mine) RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 4.dp, bottomStart = 16.dp)
    else RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 4.dp)

    Row(
        Modifier.fillMaxWidth()
            .background(if (selected) cs.primary.copy(alpha = 0.22f) else Color.Transparent)
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .graphicsLayer {
                alpha = a.value
                translationY = (1f - a.value) * 40f
                scaleX = 0.92f + 0.08f * a.value
                scaleY = 0.92f + 0.08f * a.value
            },
        horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (m.mine) cs.primaryContainer else cs.surface,
            shape = shape, shadowElevation = 1.dp, modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(
                Modifier.combinedClickable(
                    onClick = {
                        if (selecting) onToggle()
                        else m.filePath?.let { openFile(ctx, File(it)) }
                    },
                    onLongClick = onToggle
                ).padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                if (group && !m.mine) Text(m.senderName, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = Color.hsv((abs(m.sender.hashCode()) % 360).toFloat(), 0.6f, 0.8f))

                val name = m.fileName
                if (name != null) {
                    val kind = kindOf(name)
                    if (kind == 0 && m.filePath != null) {
                        val bmp = rememberBitmap(m.filePath, 0, 800)
                        if (bmp != null) Image(bmp, null,
                            Modifier.widthIn(max = 240.dp).heightIn(max = 300.dp).clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Fit)
                        else Box(Modifier.size(200.dp, 140.dp).clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant))
                    } else {
                        Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(when (kind) { 1 -> "🎬"; 2 -> "🎵"; else -> "📎" }, fontSize = 24.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(name, color = cs.primary, fontWeight = FontWeight.Medium)
                        }
                    }
                    if (m.filePath != null) Text("⬇ " + stringResource(R.string.save_file), color = cs.primary, fontSize = 13.sp,
                        modifier = Modifier.clickable { if (selecting) onToggle() else onSave(m) }.padding(vertical = 4.dp))
                }

                if (m.lst != null) ListCard(m.lst, cal, onItem)
                if (m.text != null) Text(m.text, fontSize = 16.sp)

                Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                    Text(fmtClock(m.time, cal), fontSize = 11.sp, color = cs.onSurfaceVariant)
                    if (m.mine) {
                        val seenTick = m.st >= 2 && !group
                        Spacer(Modifier.width(4.dp))
                        Text(
                            when { m.st == 0 -> "🕓"; seenTick -> "✓✓"; else -> "✓" },
                            fontSize = 12.sp, color = if (seenTick) Color(0xFF34B7F1) else cs.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ListCard(src: String, cal: Int, onItem: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val data = remember(src) { try { JSONObject(src) } catch (_: Exception) { null } }
    if (data == null) return
    val items = data.optJSONArray("items") ?: JSONArray()
    val done = data.optJSONArray("d")?.let { arr -> (0 until arr.length()).map { arr.getInt(it) }.toSet() } ?: emptySet()
    val total = items.length()
    Column(Modifier.widthIn(min = 220.dp)) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(cs.primary).padding(10.dp)) {
            Text("🛒  " + data.optString("title"), color = cs.onPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("📅  " + fmtFull(data.optLong("date"), cal), color = cs.onPrimary.copy(alpha = 0.85f), fontSize = 12.sp)
        }
        for (i in 0 until total) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = i in done, onCheckedChange = { onItem(i) })
                Text(items.optString(i), fontSize = 15.sp,
                    textDecoration = if (i in done) TextDecoration.LineThrough else null,
                    color = if (i in done) cs.onSurfaceVariant else Color.Unspecified)
            }
        }
        val count = "${done.size}/$total"
        Text(if (cal == 1) faDigits(count) else count, fontSize = 12.sp, color = cs.onSurfaceVariant,
            modifier = Modifier.align(Alignment.End))
    }
}

@Composable
fun ShoppingListDialog(cal: Int, onDismiss: () -> Unit, onSend: (String, List<String>) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val defTitle = stringResource(R.string.list_title_default)
    var title by remember { mutableStateOf(defTitle) }
    val items = remember { mutableStateListOf("") }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.8f), shape = RoundedCornerShape(20.dp), color = cs.surface) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🛒  " + stringResource(R.string.shopping_list), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("📅  " + fmtFull(System.currentTimeMillis(), cal), fontSize = 13.sp, color = cs.onSurfaceVariant)
                OutlinedTextField(value = title, onValueChange = { title = it }, singleLine = true,
                    label = { Text(stringResource(R.string.list_title)) }, modifier = Modifier.fillMaxWidth())
                LazyColumn(Modifier.weight(1f)) {
                    itemsIndexed(items) { i, v ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(value = v, onValueChange = { items[i] = it }, singleLine = true,
                                placeholder = { Text(stringResource(R.string.item_hint)) }, modifier = Modifier.weight(1f))
                            IconButton(onClick = { if (items.size > 1) items.removeAt(i) else items[0] = "" }) {
                                Icon(Icons.Filled.Close, null)
                            }
                        }
                    }
                    item {
                        TextButton(onClick = { items.add("") }) {
                            Icon(Icons.Filled.Add, null)
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.add_item))
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { onSend(title, items.toList()) }, enabled = items.any { it.isNotBlank() }) {
                        Text(stringResource(R.string.send))
                    }
                }
            }
        }
    }
}

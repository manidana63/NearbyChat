package com.example.nearbychat

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF075E54)
private val Accent = Color(0xFF25D366)
private val ChatBg = Color(0xFFECE5DD)
private val MineBubble = Color(0xFFDCF8C6)

class MainActivity : ComponentActivity() {
    private val net get() = (application as App).net
    private var pendingName = ""

    private fun nearbyPerms(): List<String> {
        val l = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.NEARBY_WIFI_DEVICES
        if (Build.VERSION.SDK_INT >= 31) {
            l += Manifest.permission.BLUETOOTH_SCAN
            l += Manifest.permission.BLUETOOTH_ADVERTISE
            l += Manifest.permission.BLUETOOTH_CONNECT
        }
        if (Build.VERSION.SDK_INT <= 32) {
            l += Manifest.permission.ACCESS_FINE_LOCATION
            l += Manifest.permission.ACCESS_COARSE_LOCATION
        }
        return l
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (nearbyPerms().all { granted(it) }) net.start(pendingName)
            else Toast.makeText(this, R.string.perm_denied, Toast.LENGTH_LONG).show()
        }

    private val micLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    override fun attachBaseContext(base: Context) {
        val lang = base.getSharedPreferences("prefs", MODE_PRIVATE).getString("lang", null)
        if (lang == null) {
            super.attachBaseContext(base)
        } else {
            val loc = Locale(lang)
            Locale.setDefault(loc)
            val cfg = Configuration(base.resources.configuration)
            cfg.setLocale(loc)
            cfg.setLayoutDirection(loc)
            super.attachBaseContext(base.createConfigurationContext(cfg))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(primary = Green, secondary = Accent)
            ) {
                Root(
                    net = net,
                    onLang = {
                        val cur = resources.configuration.locales[0].language
                        val next = if (cur == "fa") "en" else "fa"
                        getSharedPreferences("prefs", MODE_PRIVATE).edit().putString("lang", next).apply()
                        recreate()
                    },
                    onStart = { name ->
                        pendingName = name
                        permLauncher.launch((nearbyPerms() + Manifest.permission.RECORD_AUDIO).toTypedArray())
                    },
                    onCall = { id ->
                        if (granted(Manifest.permission.RECORD_AUDIO)) net.startCall(id)
                        else {
                            Toast.makeText(this, R.string.mic_needed, Toast.LENGTH_LONG).show()
                            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onAccept = {
                        if (!granted(Manifest.permission.RECORD_AUDIO))
                            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        net.acceptCall()
                    }
                )
            }
        }
    }
}

@Composable
fun Root(
    net: Net,
    onLang: () -> Unit,
    onStart: (String) -> Unit,
    onCall: (String) -> Unit,
    onAccept: () -> Unit
) {
    var open by remember { mutableStateOf<String?>(null) }
    BackHandler(open != null) { open = null }
    Box(Modifier.fillMaxSize()) {
        val id = open
        if (id == null) Home(net, onLang, onStart) { open = it }
        else Chat(net, id, onBack = { open = null }, onCall = onCall)
        if (net.callState != CallState.IDLE) CallScreen(net, onAccept)
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().background(Green).statusBarsPadding().height(56.dp).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
            }
        } else Spacer(Modifier.width(12.dp))
        Text(
            title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
        )
        actions()
    }
}

@Composable
fun Avatar(name: String, size: Int = 44) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(Accent),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name.trim().take(1).uppercase(), color = Color.White,
            fontSize = (size / 2.2).sp, fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun PeerRow(name: String, subtitle: String?, trailing: @Composable () -> Unit = {}, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(name)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            if (subtitle != null)
                Text(subtitle, fontSize = 14.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}

@Composable
fun Home(net: Net, onLang: () -> Unit, onStart: (String) -> Unit, onOpen: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf(net.myName) }
    Column(Modifier.fillMaxSize().background(Color.White)) {
        TopBar(stringResource(R.string.app_name)) {
            TextButton(onClick = onLang) {
                Text(stringResource(R.string.lang_switch), color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        if (!net.running) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    label = { Text(stringResource(R.string.your_name)) },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { if (name.isNotBlank()) onStart(name.trim()) },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) { Text(stringResource(R.string.start)) }
                Text(stringResource(R.string.hint), color = Color.Gray, fontSize = 14.sp)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                item { SectionTitle(stringResource(R.string.chats)) }
                if (net.connected.isEmpty()) item {
                    Text(stringResource(R.string.no_chats), color = Color.Gray, modifier = Modifier.padding(16.dp))
                }
                items(net.connected, key = { it.id }) { p ->
                    val last = net.chats[p.id]?.lastOrNull()
                    PeerRow(p.name, last?.text ?: last?.fileName?.let { "📎 $it" }) { onOpen(p.id) }
                }
                item { SectionTitle(stringResource(R.string.nearby)) }
                if (net.discovered.isEmpty()) item {
                    Text(stringResource(R.string.searching), color = Color.Gray, modifier = Modifier.padding(16.dp))
                }
                items(net.discovered, key = { it.id }) { p ->
                    PeerRow(p.name, null, trailing = {
                        OutlinedButton(onClick = { net.connect(p.id) }) { Text(stringResource(R.string.connect)) }
                    }) { net.connect(p.id) }
                }
                item {
                    TextButton(onClick = { net.stop() }, modifier = Modifier.padding(8.dp)) {
                        Text(stringResource(R.string.stop), color = Color(0xFFD32F2F))
                    }
                }
            }
        }
    }
}

@Composable
fun SectionTitle(t: String) {
    Text(t, color = Green, fontWeight = FontWeight.Bold, fontSize = 14.sp,
        modifier = Modifier.fillMaxWidth().background(Color(0xFFF5F5F5)).padding(horizontal = 16.dp, vertical = 8.dp))
}

@Composable
fun Chat(net: Net, id: String, onBack: () -> Unit, onCall: (String) -> Unit) {
    val peer = net.connected.find { it.id == id }
    if (peer == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val msgs = net.chats[id] ?: remember { mutableStateListOf() }
    var text by rememberSaveable { mutableStateOf("") }
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) net.sendFile(id, uri)
    }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize().background(ChatBg)) {
        TopBar(peer.name, onBack) {
            IconButton(onClick = { onCall(id) }) {
                Icon(Icons.Filled.Call, stringResource(R.string.call), tint = Color.White)
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 8.dp)) {
            items(msgs) { m -> Bubble(m, ctx) }
        }
        Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { picker.launch("*/*") }) {
                Icon(Icons.Filled.Add, stringResource(R.string.attach), tint = Green)
            }
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                placeholder = { Text(stringResource(R.string.type_message)) },
                shape = RoundedCornerShape(24.dp), maxLines = 4,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(48.dp).clip(CircleShape).background(Green)
                .clickable { net.sendText(id, text.trim()); text = "" },
                contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.send), tint = Color.White)
            }
        }
    }
}

@Composable
fun Bubble(m: Msg, ctx: Context) {
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (m.mine) MineBubble else Color.White,
            shape = RoundedCornerShape(12.dp), shadowElevation = 1.dp
        ) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp).clickable(enabled = m.file != null) {
                m.file?.let { openFile(ctx, it) }
            }) {
                if (m.text != null) Text(m.text, fontSize = 16.sp)
                if (m.fileName != null) Text("📎 ${m.fileName}", fontSize = 16.sp,
                    color = if (m.file != null) Green else Color.Unspecified)
                Text(fmt.format(Date(m.time)), fontSize = 11.sp, color = Color.Gray,
                    modifier = Modifier.align(Alignment.End))
            }
        }
    }
}

fun openFile(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
    }
}

@Composable
fun CallScreen(net: Net, onAccept: () -> Unit) {
    val name = net.nameOf(net.callPeer)
    Surface(Modifier.fillMaxSize(), color = Green) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 80.dp)) {
                Avatar(name, 120)
                Spacer(Modifier.height(20.dp))
                Text(name, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(
                        when (net.callState) {
                            CallState.OUTGOING -> R.string.calling
                            CallState.INCOMING -> R.string.incoming_call
                            else -> R.string.in_call
                        }
                    ), color = Color(0xFFCCE8E2), fontSize = 18.sp
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp), modifier = Modifier.padding(bottom = 40.dp)) {
                if (net.callState == CallState.INCOMING) {
                    Button(onClick = onAccept,
                        colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                        Text(stringResource(R.string.accept))
                    }
                    Button(onClick = { net.endCall() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) {
                        Text(stringResource(R.string.decline))
                    }
                } else {
                    Button(onClick = { net.endCall() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) {
                        Text(stringResource(if (net.callState == CallState.OUTGOING) R.string.cancel else R.string.end_call))
                    }
                }
            }
        }
    }
}

package com.example.nearbychat

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val net get() = (application as App).net

    private fun nearbyPerms(): List<String> {
        val l = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l += Manifest.permission.BLUETOOTH_SCAN
            l += Manifest.permission.BLUETOOTH_CONNECT
        }
        if (Build.VERSION.SDK_INT <= 30) {
            l += Manifest.permission.ACCESS_FINE_LOCATION
            l += Manifest.permission.ACCESS_COARSE_LOCATION
        }
        return l
    }

    private fun allPerms(): List<String> {
        val l = nearbyPerms().toMutableList()
        l += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        return l
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            launchNet()
            net.refreshRadios()
        }

    private val micLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun launchNet() {
        net.resume()
        setBackground(net.bgService)
    }

    private fun setBackground(on: Boolean) {
        val i = Intent(this, ConnectionService::class.java)
        if (on) {
            try { ContextCompat.startForegroundService(this, i) } catch (_: Exception) {}
        } else {
            stopService(i)
        }
    }

    private fun ensureRunning() {
        if (net.myName.isBlank()) return
        launchNet()
        if (!nearbyPerms().all { granted(it) } || (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)))
            permLauncher.launch(allPerms().toTypedArray())
    }

    override fun attachBaseContext(base: Context) {
        val lang = base.getSharedPreferences("prefs", MODE_PRIVATE).getString("lang", "system")
        if (lang == null || lang == "system") {
            super.attachBaseContext(base)
        } else {
            val loc = Locale(lang)
            Locale.setDefault(loc)
            val cfg = Configuration(base.resources.configuration)
            cfg.setLocale(loc)
            cfg.setLayoutDirection(loc)
            super.attachBaseContext(base.createConfigurationContext(cfg))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        setContent {
            AppTheme(net) {
                Root(
                    net = net,
                    lang = prefs.getString("lang", "system") ?: "system",
                    onLang = { code ->
                        prefs.edit().putString("lang", code).apply()
                        net.refreshChannels()
                        setBackground(net.bgService)
                        recreate()
                    },
                    onProfileDone = { ensureRunning() },
                    onCall = { id ->
                        if (granted(Manifest.permission.RECORD_AUDIO)) net.startCall(id)
                        else {
                            Toast.makeText(this, R.string.mic_needed, Toast.LENGTH_LONG).show()
                            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onAccept = {
                        if (!granted(Manifest.permission.RECORD_AUDIO))
                            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        net.acceptCall()
                    },
                    onBg = { on -> setBackground(on) },
                    onExit = { exitApp() },
                    onRestored = { exitApp() }
                )
            }
        }
        ensureRunning()
    }

    private fun exitApp() {
        net.exit()
        stopService(Intent(this, ConnectionService::class.java))
        finishAndRemoveTask()
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
            { android.os.Process.killProcess(android.os.Process.myPid()) }, 400
        )
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        i.getStringExtra("conv")?.let { net.openRequest = it }
        i.getStringExtra("sms_key")?.let { k -> net.openSms = k to (i.getStringExtra("sms_addr") ?: k) }
        val data = i.data
        if (data != null) {
            val num = Uri.decode(data.schemeSpecificPart ?: "")
            when (data.scheme) {
                "tel" -> net.openDial = num
                "sms", "smsto", "mms", "mmsto" -> net.openNewSms = num.substringBefore('?')
            }
        } else if (i.action == Intent.ACTION_DIAL) net.openDial = ""
    }

    override fun onStart() {
        super.onStart()
        net.appVisible = true
        PhoneRepo.bump()
        net.activeChat?.let { net.markRead(it) }
    }

    override fun onStop() {
        super.onStop()
        net.appVisible = false
    }
}

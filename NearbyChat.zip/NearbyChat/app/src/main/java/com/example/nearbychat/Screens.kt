package com.example.nearbychat

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

data class Attach(val uri: Uri, val name: String, val image: Boolean)

// ---------------- profile / setup / settings ----------------

@Composable
fun ProfileEditor(net: Net, name: String, onName: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) net.setAvatar(u)
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.clip(CircleShape).clickable { picker.launch("image/*") }) {
            Avatar(net, "me", name.ifBlank { "?" }, 112.dp)
            Box(Modifier.align(Alignment.BottomEnd).size(36.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Edit, null, tint = cs.onPrimary, modifier = Modifier.size(18.dp))
            }
        }
        OutlinedTextField(value = name, onValueChange = onName, singleLine = true,
            label = { Text(stringResource(R.string.your_name)) }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun SetupScreen(net: Net, onDone: () -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Spacer(Modifier.height(24.dp))
        Text(stringResource(R.string.welcome), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(stringResource(R.string.welcome_desc), color = MaterialTheme.colorScheme.onSurfaceVariant)
        ProfileEditor(net, name) { name = it }
        Button(onClick = { net.saveName(name); onDone() }, enabled = name.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(stringResource(R.string.continue_btn)) }
        Text(stringResource(R.string.hint), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SectionLabel(t: String) =
    Text(t, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            Text(desc, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(
    net: Net, lang: String, onLang: (String) -> Unit, onBg: (Boolean) -> Unit,
    onExit: () -> Unit, onRestored: () -> Unit, onBlocked: () -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(net.myName) }
    var restoreUri by remember { mutableStateOf<Uri?>(null) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) net.exportBackup(uri) { ok ->
            Toast.makeText(ctx, if (ok) R.string.backup_saved else R.string.connect_failed, Toast.LENGTH_LONG).show()
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) restoreUri = uri
    }
    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.settings), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            SectionLabel(stringResource(R.string.profile))
            ProfileEditor(net, name) { name = it }
            if (name.isNotBlank() && name.trim() != net.myName) {
                Button(onClick = { net.saveName(name) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.save)) }
            }

            SectionLabel(stringResource(R.string.language))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to R.string.lang_system, "en" to null, "fa" to null).forEach { (code, res) ->
                    FilterChip(selected = lang == code, onClick = { if (lang != code) onLang(code) },
                        label = { Text(when (code) { "en" -> "English"; "fa" -> "فارسی"; else -> stringResource(res!!) }) })
                }
            }

            SectionLabel(stringResource(R.string.conn_mode))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(R.string.mode_auto, R.string.mode_bt, R.string.mode_wifi).forEachIndexed { i, r ->
                    FilterChip(selected = net.mode == i, onClick = { net.changeMode(i) }, label = { Text(stringResource(r)) })
                }
            }
            Text(stringResource(R.string.mode_desc), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

            SectionLabel(stringResource(R.string.theme))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(R.string.theme_system, R.string.theme_light, R.string.theme_dark).forEachIndexed { i, r ->
                    FilterChip(selected = net.theme == i, onClick = { net.changeTheme(i) }, label = { Text(stringResource(r)) })
                }
            }

            SectionLabel(stringResource(R.string.calendar))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(R.string.cal_gregorian, R.string.cal_jalali).forEachIndexed { i, r ->
                    FilterChip(selected = net.calendar == i, onClick = { net.changeCalendar(i) }, label = { Text(stringResource(r)) })
                }
            }

            AppearanceSettings(net)
            PhoneSettings(net, onBlocked)

            SwitchRow(stringResource(R.string.notifications), stringResource(R.string.notifications_desc), net.notifOn) { net.setNotif(it) }
            SwitchRow(stringResource(R.string.background), stringResource(R.string.background_desc), net.bgService) {
                net.setBg(it); onBg(it)
            }

            SectionLabel(stringResource(R.string.backup))
            Text(stringResource(R.string.backup_desc), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { exporter.launch("nearbychat-backup.zip") }) { Text(stringResource(R.string.backup_export)) }
                OutlinedButton(onClick = { importer.launch("*/*") }) { Text(stringResource(R.string.backup_import)) }
            }

            Button(onClick = onExit, modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) {
                Text(stringResource(R.string.exit_full))
            }

            SectionLabel(stringResource(R.string.about))
            Text(stringResource(R.string.your_id, net.myId), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Nearby Chat 4.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    restoreUri?.let { u ->
        AlertDialog(
            onDismissRequest = { restoreUri = null },
            text = { Text(stringResource(R.string.restore_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    restoreUri = null
                    net.importBackup(u) { ok ->
                        Toast.makeText(ctx, if (ok) R.string.restore_done else R.string.connect_failed, Toast.LENGTH_LONG).show()
                        if (ok) onRestored()
                    }
                }) { Text(stringResource(R.string.backup_import)) }
            },
            dismissButton = { TextButton(onClick = { restoreUri = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
private fun animateFloatAsStateCompat(target: Float) =
    androidx.compose.animation.core.animateFloatAsState(target, tween(200), label = "scale")

// ---------------- new group ----------------

@Composable
fun NewGroupScreen(net: Net, onBack: () -> Unit, onCreated: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    val sel = remember { mutableStateListOf<String>() }
    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.new_group), onBack)
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true,
                label = { Text(stringResource(R.string.group_name)) }, modifier = Modifier.fillMaxWidth())
            SectionLabel(stringResource(R.string.select_members))
            if (net.contacts.isEmpty()) Text(stringResource(R.string.no_contacts), color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyColumn(Modifier.weight(1f)) {
                items(net.contacts, key = { it.id }) { c ->
                    Row(Modifier.fillMaxWidth().clickable { if (c.id in sel) sel.remove(c.id) else sel.add(c.id) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = c.id in sel, onCheckedChange = { if (it) sel.add(c.id) else sel.remove(c.id) })
                        Avatar(net, c.id, c.name, 40.dp, online = net.online.contains(c.id))
                        Spacer(Modifier.width(12.dp))
                        Text(c.name, fontSize = 16.sp)
                    }
                }
            }
            Button(onClick = { onCreated(net.createGroup(name, sel.toList())) },
                enabled = name.isNotBlank() && sel.isNotEmpty(), modifier = Modifier.fillMaxWidth().height(50.dp)) {
                Text(stringResource(R.string.create))
            }
        }
    }
}


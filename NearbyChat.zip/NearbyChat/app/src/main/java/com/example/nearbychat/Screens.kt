package com.example.nearbychat

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

data class Attach(val uri: Uri, val name: String, val image: Boolean)

// ---------------- chat ----------------

@Composable
fun ChatScreen(net: Net, id: String, onBack: () -> Unit, onCall: (String) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val group = net.isGroup(id)
    val title = net.title(id)
    val msgs = net.chats.getOrPut(id) { mutableStateListOf() }
    var text by rememberSaveable { mutableStateOf("") }
    var pending by remember { mutableStateOf<Attach?>(null) }
    val listState = rememberLazyListState()

    DisposableEffect(id) {
        net.activeChat = id
        net.markRead(id)
        onDispose { if (net.activeChat == id) net.activeChat = null }
    }
    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) {
            net.markRead(id)
            listState.animateScrollToItem(msgs.size - 1)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val n = net.displayName(uri)
            val mime = ctx.contentResolver.getType(uri)
            pending = Attach(uri, n, mime?.startsWith("image/") == true || isImage(n))
        }
    }

    fun doSend() {
        val a = pending
        if (a != null) {
            if (!net.canSendNow(id)) {
                Toast.makeText(ctx, R.string.offline, Toast.LENGTH_SHORT).show()
                return
            }
            net.sendFile(id, a.uri)
        }
        if (text.isNotBlank()) net.sendText(id, text.trim())
        pending = null
        text = ""
    }

    val isOnline = !group && net.online.contains(id)
    val subtitle = if (group) stringResource(R.string.members_count, net.groups.find { it.id == id }?.members?.size ?: 0)
    else stringResource(if (isOnline) R.string.online else R.string.offline_status)

    Column(Modifier.fillMaxSize().background(cs.background)) {
        TopBar(title, onBack, subtitle, lead = { Avatar(net, id, title, 38.dp, group = group) }) {
            if (isOnline) IconButton(onClick = { onCall(id) }) {
                Icon(Icons.Filled.Call, stringResource(R.string.call), tint = Color.White)
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(vertical = 8.dp)) {
            items(msgs, key = { it.id }) { m -> Bubble(m, group) }
        }
        Surface(color = cs.surface, shadowElevation = 6.dp) {
            Column(Modifier.animateContentSize()) {
                pending?.let { a ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        val bmp = if (a.image) rememberUriBitmap(a.uri, 200) else null
                        Box(Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant), contentAlignment = Alignment.Center) {
                            if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else Text("📎", fontSize = 24.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(a.name, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        IconButton(onClick = { pending = null }) { Icon(Icons.Filled.Close, null) }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { picker.launch("*/*") }) {
                        Icon(Icons.Filled.Add, stringResource(R.string.attach), tint = cs.primary)
                    }
                    OutlinedTextField(
                        value = text, onValueChange = { text = it },
                        placeholder = { Text(stringResource(R.string.type_message)) },
                        shape = RoundedCornerShape(24.dp), maxLines = 4, modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(6.dp))
                    val ok = text.isNotBlank() || pending != null
                    val bg by animateColorAsState(if (ok) cs.primary else cs.surfaceVariant, tween(200), label = "send")
                    Box(Modifier.size(48.dp).clip(CircleShape).background(bg).clickable(enabled = ok) { doSend() },
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.send),
                            tint = if (ok) cs.onPrimary else cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun Bubble(m: Msg, group: Boolean) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val fresh = remember { System.currentTimeMillis() - m.time < 2000 }
    val a = remember { Animatable(if (fresh) 0f else 1f) }
    LaunchedEffect(Unit) { if (fresh) a.animateTo(1f, tween(260, easing = FastOutSlowInEasing)) }

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp)
            .graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 40f; scaleX = 0.92f + 0.08f * a.value; scaleY = 0.92f + 0.08f * a.value },
        horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (m.mine) cs.primaryContainer else cs.surface,
            shape = if (m.mine) RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 4.dp, bottomStart = 16.dp)
            else RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 4.dp),
            shadowElevation = 1.dp, modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                if (group && !m.mine) Text(m.senderName, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = Color.hsv((abs(m.sender.hashCode()) % 360).toFloat(), 0.6f, 0.8f))
                if (m.fileName != null) {
                    val file = m.filePath?.let { File(it) }
                    if (isImage(m.fileName) && m.filePath != null) {
                        val bmp = rememberBitmap(m.filePath, 0, 800)
                        if (bmp != null) Image(bmp, null,
                            Modifier.widthIn(max = 240.dp).heightIn(max = 300.dp).clip(RoundedCornerShape(10.dp))
                                .clickable { file?.let { openFile(ctx, it) } },
                            contentScale = ContentScale.Fit)
                        else Box(Modifier.size(200.dp, 140.dp).clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant))
                    } else {
                        Row(Modifier.clickable(enabled = file != null) { file?.let { openFile(ctx, it) } }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text("📎", fontSize = 22.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(m.fileName, color = cs.primary, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                if (m.text != null) Text(m.text, fontSize = 16.sp)
                Text(fmt.format(Date(m.time)) + if (m.mine) (if (m.pending) "  🕓" else "  ✓") else "",
                    fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.align(Alignment.End))
            }
        }
    }
}

// ---------------- profile / setup / settings ----------------

@Composable
fun ProfileEditor(net: Net, name: String, onName: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) net.setAvatar(u)
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.clip(CircleShape).clickable { picker.launch("image/*") }) {
            Avatar(net, "me", name.ifBlank { "?" }, 112.dp)
            Box(Modifier.align(Alignment.BottomEnd).size(36.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Edit, null, tint = cs.onPrimary, modifier = Modifier.size(18.dp))
            }
        }
        OutlinedTextField(value = name, onValueChange = onName, singleLine = true,
            label = { Text(stringResource(R.string.your_name)) }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun SetupScreen(net: Net, onDone: () -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Spacer(Modifier.height(24.dp))
        Text(stringResource(R.string.welcome), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(stringResource(R.string.welcome_desc), color = MaterialTheme.colorScheme.onSurfaceVariant)
        ProfileEditor(net, name) { name = it }
        Button(onClick = { net.saveName(name); onDone() }, enabled = name.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(stringResource(R.string.continue_btn)) }
        Text(stringResource(R.string.hint), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SectionLabel(t: String) =
    Text(t, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            Text(desc, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(net: Net, lang: String, onLang: (String) -> Unit, onBg: (Boolean) -> Unit, onBack: () -> Unit) {
    var name by remember { mutableStateOf(net.myName) }
    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.settings), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            SectionLabel(stringResource(R.string.profile))
            ProfileEditor(net, name) { name = it }
            if (name.isNotBlank() && name.trim() != net.myName) {
                Button(onClick = { net.saveName(name) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.save)) }
            }

            SectionLabel(stringResource(R.string.language))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to R.string.lang_system, "en" to null, "fa" to null).forEach { (code, res) ->
                    FilterChip(selected = lang == code, onClick = { if (lang != code) onLang(code) },
                        label = { Text(when (code) { "en" -> "English"; "fa" -> "فارسی"; else -> stringResource(res!!) }) })
                }
            }

            SectionLabel(stringResource(R.string.theme))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(R.string.theme_system, R.string.theme_light, R.string.theme_dark).forEachIndexed { i, r ->
                    FilterChip(selected = net.theme == i, onClick = { net.changeTheme(i) }, label = { Text(stringResource(r)) })
                }
            }

            SectionLabel(stringResource(R.string.accent))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Accents.forEachIndexed { i, c ->
                    val sc by animateFloatAsStateCompat(if (net.accent == i) 1.15f else 1f)
                    Box(Modifier.size(40.dp).scale(sc).clip(CircleShape).background(c).clickable { net.changeAccent(i) },
                        contentAlignment = Alignment.Center) {
                        if (net.accent == i) Icon(Icons.Filled.Check, null, tint = Color.White)
                    }
                }
            }

            SwitchRow(stringResource(R.string.notifications), stringResource(R.string.notifications_desc), net.notifOn) { net.setNotif(it) }
            SwitchRow(stringResource(R.string.background), stringResource(R.string.background_desc), net.bgService) {
                net.setBg(it); onBg(it)
            }

            SectionLabel(stringResource(R.string.about))
            Text(stringResource(R.string.your_id, net.myId), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Nearby Chat 2.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun animateFloatAsStateCompat(target: Float) =
    androidx.compose.animation.core.animateFloatAsState(target, tween(200), label = "scale")

// ---------------- new group ----------------

@Composable
fun NewGroupScreen(net: Net, onBack: () -> Unit, onCreated: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    val sel = remember { mutableStateListOf<String>() }
    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.new_group), onBack)
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true,
                label = { Text(stringResource(R.string.group_name)) }, modifier = Modifier.fillMaxWidth())
            SectionLabel(stringResource(R.string.select_members))
            if (net.contacts.isEmpty()) Text(stringResource(R.string.no_contacts), color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyColumn(Modifier.weight(1f)) {
                items(net.contacts, key = { it.id }) { c ->
                    Row(Modifier.fillMaxWidth().clickable { if (c.id in sel) sel.remove(c.id) else sel.add(c.id) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = c.id in sel, onCheckedChange = { if (it) sel.add(c.id) else sel.remove(c.id) })
                        Avatar(net, c.id, c.name, 40.dp, online = net.online.contains(c.id))
                        Spacer(Modifier.width(12.dp))
                        Text(c.name, fontSize = 16.sp)
                    }
                }
            }
            Button(onClick = { onCreated(net.createGroup(name, sel.toList())) },
                enabled = name.isNotBlank() && sel.isNotEmpty(), modifier = Modifier.fillMaxWidth().height(50.dp)) {
                Text(stringResource(R.string.create))
            }
        }
    }
}

// ---------------- call ----------------

@Composable
fun CallScreen(net: Net, onAccept: () -> Unit) {
    val peer = net.callPeer ?: ""
    val name = net.title(peer)
    val pulse = rememberInfiniteTransition(label = "pulse")
    val s by pulse.animateFloat(1f, 1.1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    val red = Color(0xFFD32F2F)
    Surface(Modifier.fillMaxSize(), color = barColor()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 80.dp)) {
                Box(Modifier.scale(if (net.callState == CallState.ACTIVE) 1f else s)) { Avatar(net, peer, name, 130.dp) }
                Spacer(Modifier.height(24.dp))
                Text(name, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(stringResource(when (net.callState) {
                    CallState.OUTGOING -> R.string.calling
                    CallState.INCOMING -> R.string.incoming_call
                    else -> R.string.in_call
                }), color = Color(0xCCFFFFFF), fontSize = 18.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp), modifier = Modifier.padding(bottom = 40.dp)) {
                if (net.callState == CallState.INCOMING) {
                    Button(onClick = onAccept, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))) {
                        Text(stringResource(R.string.accept))
                    }
                    Button(onClick = { net.endCall() }, colors = ButtonDefaults.buttonColors(containerColor = red)) {
                        Text(stringResource(R.string.decline))
                    }
                } else {
                    Button(onClick = { net.endCall() }, colors = ButtonDefaults.buttonColors(containerColor = red)) {
                        Text(stringResource(if (net.callState == CallState.OUTGOING) R.string.cancel else R.string.end_call))
                    }
                }
            }
        }
    }
}

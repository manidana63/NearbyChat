package com.example.nearbychat

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

fun wrapLang(base: Context): Context {
    val lang = base.getSharedPreferences("prefs", Context.MODE_PRIVATE).getString("lang", "system")
    if (lang == null || lang == "system") return base
    val loc = Locale(lang)
    Locale.setDefault(loc)
    val cfg = Configuration(base.resources.configuration)
    cfg.setLocale(loc)
    cfg.setLayoutDirection(loc)
    return base.createConfigurationContext(cfg)
}

/** The phone-call screen. Used when this app is the default phone app. */
class InCallActivity : ComponentActivity() {
    override fun attachBaseContext(base: Context) = super.attachBaseContext(wrapLang(base))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val net = (application as App).net
        setContent { AppTheme(net) { InCallScreen(net) { finish() } } }
    }
}

@Composable
fun InCallScreen(net: Net, onClose: () -> Unit) {
    val ver = CallStore.version
    val calls = CallStore.calls
    val call = CallStore.primary()
    LaunchedEffect(calls.size) {
        if (calls.isEmpty()) {
            delay(700)
            if (CallStore.calls.isEmpty()) onClose()
        }
    }
    if (call == null) {
        Box(Modifier.fillMaxSize().background(barColor()))
        return
    }
    val scope = rememberCoroutineScope()
    val number = CallStore.numberOf(call)
    @Suppress("DEPRECATION")
    val state = call.state
    val contact = remember(number, ver) {
        PhoneRepo.contacts.firstOrNull { c -> c.numbers.any { PhoneRepo.keyOf(it) == PhoneRepo.keyOf(number) } }
    }
    val given = try { call.details.callerDisplayName } catch (_: Exception) { null }
    val name = contact?.name ?: given?.ifBlank { null } ?: ""
    val unknown = stringResource(R.string.unknown)
    val title = name.ifEmpty { if (number.isBlank()) unknown else net.numStr(number) }

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val connect = try { call.details.connectTimeMillis } catch (_: Exception) { 0L }
    val secs = if (connect > 0) ((now - connect) / 1000).coerceAtLeast(0) else 0L
    val timer = net.numStr("%02d:%02d".format(secs / 60, secs % 60))

    val status = when (state) {
        Call.STATE_DIALING, Call.STATE_CONNECTING -> stringResource(R.string.calling)
        Call.STATE_RINGING -> stringResource(R.string.incoming_call)
        Call.STATE_ACTIVE -> timer
        Call.STATE_HOLDING -> stringResource(R.string.call_hold)
        Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> stringResource(R.string.call_ended)
        else -> ""
    }
    val sub = if (name.isNotEmpty() && number.isNotBlank() && state != Call.STATE_ACTIVE) net.numStr(number) + " · " + status else status

    var keypad by remember { mutableStateOf(false) }
    var quick by remember { mutableStateOf(false) }
    val st = net.callStyle
    val lc = callTextColor(st).copy(alpha = 0.85f)
    val red = Color(0xFFD32F2F)
    val green = Color(0xFF25D366)

    CallLayout(
        style = st, title = title, status = sub,
        pulse = state == Call.STATE_RINGING || state == Call.STATE_DIALING || state == Call.STATE_CONNECTING,
        avatar = { GenericAvatar(title, it, contact?.photo) }
    ) {
        if (calls.size > 1) {
            val other = calls.firstOrNull { it !== call }
            if (other != null) TextButton(onClick = { try { call.hold(); other.unhold() } catch (_: Exception) {} }) {
                val on = PhoneRepo.nameFor(CallStore.numberOf(other)) ?: net.numStr(CallStore.numberOf(other))
                Text(stringResource(R.string.switch_call, on), color = lc)
            }
        }
        if (state == Call.STATE_RINGING) {
            Row(horizontalArrangement = Arrangement.spacedBy(56.dp)) {
                RoundBtn("📞", stringResource(R.string.accept), green, Color.White, lc, 72.dp) { call.answer(VideoProfile.STATE_AUDIO_ONLY) }
                RoundBtn("✖", stringResource(R.string.decline), red, Color.White, lc, 72.dp) { call.reject(false, null) }
            }
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = { quick = true }) { Text("💬  " + stringResource(R.string.quick_reply), color = lc) }
        } else {
            if (keypad) {
                val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
                keys.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.padding(vertical = 5.dp)) {
                        row.forEach { k ->
                            Box(
                                Modifier.size(58.dp).clip(CircleShape).background(callBtnBg(st))
                                    .clickable { scope.launch { call.playDtmfTone(k[0]); delay(120); call.stopDtmfTone() } },
                                contentAlignment = Alignment.Center
                            ) { Text(net.numStr(k), fontSize = 22.sp, color = callFg(st)) }
                        }
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    RoundBtn(if (CallStore.muted) "🔇" else "🎤", stringResource(R.string.mute), callBtnBg(st, CallStore.muted), callFg(st, CallStore.muted), lc) {
                        CallStore.service?.setMuted(!CallStore.muted)
                    }
                    RoundBtn("⌨", stringResource(R.string.keypad), callBtnBg(st), callFg(st), lc) { keypad = true }
                    RoundBtn("🔊", stringResource(R.string.speaker), callBtnBg(st, CallStore.route == CallAudioState.ROUTE_SPEAKER),
                        callFg(st, CallStore.route == CallAudioState.ROUTE_SPEAKER), lc) {
                        CallStore.service?.setAudioRoute(
                            if (CallStore.route == CallAudioState.ROUTE_SPEAKER) CallAudioState.ROUTE_WIRED_OR_EARPIECE
                            else CallAudioState.ROUTE_SPEAKER
                        )
                    }
                    RoundBtn("⏸", stringResource(R.string.hold), callBtnBg(st, state == Call.STATE_HOLDING),
                        callFg(st, state == Call.STATE_HOLDING), lc) {
                        if (state == Call.STATE_HOLDING) call.unhold() else call.hold()
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(32.dp), verticalAlignment = Alignment.Bottom) {
                if (keypad) RoundBtn("⌨", stringResource(R.string.hide), callBtnBg(st), callFg(st), lc, 56.dp) { keypad = false }
                RoundBtn("✖", stringResource(R.string.end_call), red, Color.White, lc, 72.dp) { call.disconnect() }
            }
        }
    }

    if (quick) {
        val replies = listOf(R.string.qr1, R.string.qr2, R.string.qr3, R.string.qr4).map { stringResource(it) }
        AlertDialog(
            onDismissRequest = { quick = false },
            title = { Text(stringResource(R.string.quick_reply)) },
            text = {
                Column {
                    replies.forEach { r ->
                        TextButton(onClick = { quick = false; call.reject(true, r) }) { Text(r) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { quick = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

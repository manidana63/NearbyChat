package com.example.nearbychat

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class Cat(val emoji: String, val title: Int, val sub: Int)

private val CATS = listOf(
    Cat("👤", R.string.cat_profile, R.string.cat_profile_sub),
    Cat("🎨", R.string.cat_appearance, R.string.cat_appearance_sub),
    Cat("📞", R.string.cat_calls, R.string.cat_calls_sub),
    Cat("💬", R.string.cat_messages, R.string.cat_messages_sub),
    Cat("🔔", R.string.cat_connection, R.string.cat_connection_sub),
    Cat("💾", R.string.cat_data, R.string.cat_data_sub),
    Cat("ℹ️", R.string.cat_about, R.string.cat_about_sub)
)

@Composable
private fun ChipRow(content: @Composable RowScope.() -> Unit) =
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)

@Composable
private fun Group(title: String, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = RoundedCornerShape(20.dp), color = cs.surface, shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            content()
        }
    }
}

@Composable
fun SettingsScreen(
    net: Net, lang: String, onLang: (String) -> Unit, onBg: (Boolean) -> Unit,
    onExit: () -> Unit, onRestored: () -> Unit, onBlocked: () -> Unit, onBack: () -> Unit
) {
    var cat by rememberSaveable { mutableIntStateOf(-1) }
    BackHandler(cat >= 0) { cat = -1 }
    Column(Modifier.fillMaxSize()) {
        TopBar(
            stringResource(if (cat < 0) R.string.settings else CATS[cat].title),
            { if (cat >= 0) cat = -1 else onBack() }
        )
        Crossfade(cat, label = "settings") { c ->
            if (c < 0) CategoryList(net, { cat = it }, onExit)
            else Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (c) {
                    0 -> ProfileCat(net)
                    1 -> AppearanceCat(net, lang, onLang)
                    2 -> CallsCat(net, onBlocked)
                    3 -> MessagesCat(net)
                    4 -> ConnectionCat(net, onBg)
                    5 -> DataCat(net, onRestored)
                    else -> AboutCat(net)
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun CategoryList(net: Net, onPick: (Int) -> Unit, onExit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(shape = RoundedCornerShape(22.dp), color = cs.primaryContainer, modifier = Modifier.fillMaxWidth().clickable { onPick(0) }) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(net, "me", net.myName.ifBlank { "?" }, 62.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(net.myName, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer)
                    Text(net.numStr(net.myPhone.ifBlank { net.myId }), fontSize = 14.sp, color = cs.onPrimaryContainer.copy(alpha = 0.75f))
                }
                Text("›", fontSize = 26.sp, color = cs.onPrimaryContainer)
            }
        }
        CATS.drop(1).forEachIndexed { i, c ->
            Surface(shape = RoundedCornerShape(18.dp), color = cs.surface, shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth().clickable { onPick(i + 1) }) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
                        Text(c.emoji, fontSize = 20.sp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(c.title), fontSize = 17.sp, fontWeight = FontWeight.Medium)
                        Text(stringResource(c.sub), fontSize = 13.sp, color = cs.onSurfaceVariant)
                    }
                    Text("›", fontSize = 24.sp, color = cs.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Button(onClick = onExit, modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) { Text(stringResource(R.string.exit_full)) }
    }
}

// ---------------------------------------------------------------- categories

@Composable
private fun ProfileCat(net: Net) {
    var name by remember { mutableStateOf(net.myName) }
    var phone by remember { mutableStateOf(net.myPhone) }
    Group(stringResource(R.string.profile)) {
        ProfileEditor(net, name) { name = it }
        if (name.isNotBlank() && name.trim() != net.myName) {
            Button(onClick = { net.saveName(name) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.save)) }
        }
    }
    Group(stringResource(R.string.my_phone)) {
        OutlinedTextField(value = phone, onValueChange = { phone = it; net.changeMyPhone(it) }, singleLine = true,
            label = { Text(stringResource(R.string.my_phone)) }, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
        Text(stringResource(R.string.my_phone_desc), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AppearanceCat(net: Net, lang: String, onLang: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Group(stringResource(R.string.language)) {
        ChipRow {
            listOf("system", "en", "fa").forEach { code ->
                FilterChip(selected = lang == code, onClick = { if (lang != code) onLang(code) },
                    label = { Text(when (code) { "en" -> "English"; "fa" -> "فارسی"; else -> stringResource(R.string.lang_system) }) })
            }
        }
    }
    Group(stringResource(R.string.theme)) {
        ChipRow {
            listOf(R.string.theme_system, R.string.theme_light, R.string.theme_dark).forEachIndexed { i, r ->
                FilterChip(selected = net.theme == i, onClick = { net.changeTheme(i) }, label = { Text(stringResource(r)) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.amoled), fontSize = 16.sp)
                Text(stringResource(R.string.amoled_desc), fontSize = 13.sp, color = cs.onSurfaceVariant)
            }
            Switch(checked = net.amoled, onCheckedChange = { net.amoled = it; net.saveBool("amoled", it) })
        }
        Text(stringResource(R.string.accent), fontWeight = FontWeight.Medium)
        Accents.chunked(5).forEachIndexed { row, list ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                list.forEachIndexed { j, color ->
                    val i = row * 5 + j
                    val sc by animateFloatAsState(if (net.accent == i) 1.15f else 1f, label = "acc")
                    Box(Modifier.size(40.dp).scale(sc).clip(CircleShape).background(color).clickable { net.changeAccent(i) },
                        contentAlignment = Alignment.Center) {
                        if (net.accent == i) Icon(Icons.Filled.Check, null, tint = Color.White)
                    }
                }
            }
        }
    }
    Group(stringResource(R.string.text_and_shapes)) {
        Text(stringResource(R.string.font_size), fontWeight = FontWeight.Medium)
        ChipRow {
            listOf(R.string.fs_small, R.string.fs_normal, R.string.fs_large, R.string.fs_xl).forEachIndexed { i, r ->
                FilterChip(selected = net.fontScale == i, onClick = { net.fontScale = i; net.saveInt("fontScale", i) }, label = { Text(stringResource(r)) })
            }
        }
        Text(stringResource(R.string.bubble_shape), fontWeight = FontWeight.Medium)
        ChipRow {
            listOf(R.string.bs_square, R.string.bs_rounded, R.string.bs_round).forEachIndexed { i, r ->
                FilterChip(selected = net.bubble == i, onClick = { net.bubble = i; net.saveInt("bubble", i) }, label = { Text(stringResource(r)) })
            }
        }
    }
    Group(stringResource(R.string.numbers_and_dates)) {
        Text(stringResource(R.string.digits_style), fontWeight = FontWeight.Medium)
        ChipRow {
            listOf(R.string.dg_auto, R.string.dg_fa, R.string.dg_en).forEachIndexed { i, r ->
                FilterChip(selected = net.digits == i, onClick = { net.digits = i; net.saveInt("digits", i) }, label = { Text(stringResource(r)) })
            }
        }
        Text(stringResource(R.string.calendar), fontWeight = FontWeight.Medium)
        ChipRow {
            listOf(R.string.cal_gregorian, R.string.cal_jalali).forEachIndexed { i, r ->
                FilterChip(selected = net.calendar == i, onClick = { net.changeCalendar(i) }, label = { Text(stringResource(r)) })
            }
        }
    }
}

@Composable
private fun CallsCat(net: Net, onBlocked: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val ver = PhoneRepo.version
    val roleD = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { PhoneRepo.bump() }
    val roleS = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { PhoneRepo.bump() }
    val isD = remember(ver) { PhoneRepo.isDefaultDialer(ctx) }
    val isS = remember(ver) { PhoneRepo.isDefaultSms(ctx) }
    val simsNow = remember { PhoneRepo.sims(ctx) }
    val simNames = remember { mutableStateListOf(PhoneRepo.customSimName(ctx, 0), PhoneRepo.customSimName(ctx, 1)) }

    Group(stringResource(R.string.default_apps)) {
        Text(stringResource(R.string.default_apps_desc), fontSize = 13.sp, color = cs.onSurfaceVariant)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.default_phone) + ": " + stringResource(if (isD) R.string.active else R.string.not_set), Modifier.weight(1f))
            if (!isD) Button(onClick = { try { roleD.launch(PhoneRepo.roleIntent(ctx, false)) } catch (_: Exception) {} }) { Text(stringResource(R.string.set_default)) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.default_sms) + ": " + stringResource(if (isS) R.string.active else R.string.not_set), Modifier.weight(1f))
            if (!isS) Button(onClick = { try { roleS.launch(PhoneRepo.roleIntent(ctx, true)) } catch (_: Exception) {} }) { Text(stringResource(R.string.set_default)) }
        }
    }

    Group(stringResource(R.string.call_look)) {
        Text(stringResource(R.string.call_style), fontWeight = FontWeight.Medium)
        ChipRow {
            listOf(R.string.cs_aurora, R.string.cs_classic, R.string.cs_minimal, R.string.cs_neon).forEachIndexed { i, r ->
                StyleCard(i, net.callStyle == i, stringResource(r)) { net.callStyle = i; net.saveInt("callStyle", i) }
            }
        }
        Text(stringResource(R.string.dial_style), fontWeight = FontWeight.Medium)
        ChipRow {
            listOf(R.string.ds_round, R.string.ds_square, R.string.ds_flat).forEachIndexed { i, r ->
                FilterChip(selected = net.dialStyle == i, onClick = { net.dialStyle = i; net.saveInt("dialStyle", i) }, label = { Text(stringResource(r)) })
            }
        }
    }

    Group(stringResource(R.string.sim_section_title)) {
        Text(stringResource(R.string.sim_names), fontWeight = FontWeight.Medium)
        simNames.forEachIndexed { i, v ->
            val hint = simsNow.firstOrNull { it.slot == i }?.label?.substringAfter(" · ", "") ?: ""
            OutlinedTextField(
                value = v, onValueChange = { simNames[i] = it; PhoneRepo.setSimName(ctx, i, it) }, singleLine = true,
                label = { Text("SIM ${i + 1}") },
                placeholder = { Text(hint.ifBlank { stringResource(R.string.sim_name_hint) }) },
                modifier = Modifier.fillMaxWidth()
            )
        }
        val n0 = simNames[0].trim().ifEmpty { "SIM 1" }
        val n1 = simNames[1].trim().ifEmpty { "SIM 2" }
        val dflt = stringResource(R.string.sim_default)
        val ask = stringResource(R.string.sim_ask)
        Text(stringResource(R.string.sim_calls), fontWeight = FontWeight.Medium)
        ChipRow {
            listOf(-2 to dflt, -1 to ask, 0 to n0, 1 to n1).forEach { (v, l) ->
                FilterChip(selected = net.simCall == v, onClick = { net.simCall = v; net.saveInt("simCall", v) }, label = { Text(l) })
            }
        }
        Text(stringResource(R.string.sim_sms), fontWeight = FontWeight.Medium)
        ChipRow {
            listOf(-2 to dflt, 0 to n0, 1 to n1).forEach { (v, l) ->
                FilterChip(selected = net.simSms == v, onClick = { net.simSms = v; net.saveInt("simSms", v) }, label = { Text(l) })
            }
        }
    }

    OutlinedButton(onClick = onBlocked, modifier = Modifier.fillMaxWidth()) { Text("⛔  " + stringResource(R.string.blocked_title)) }
}

@Composable
private fun MessagesCat(net: Net) {
    val cs = MaterialTheme.colorScheme
    Group(stringResource(R.string.send_delay)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.send_delay), fontSize = 16.sp)
                Text(stringResource(R.string.send_delay_desc), fontSize = 13.sp, color = cs.onSurfaceVariant)
            }
            Switch(checked = net.sendDelay > 0, onCheckedChange = {
                val v = if (it) 5 else 0
                net.sendDelay = v; net.saveInt("sendDelay", v)
            })
        }
        if (net.sendDelay > 0) {
            Text(stringResource(R.string.send_delay_time), fontWeight = FontWeight.Medium)
            ChipRow {
                listOf(3, 5, 10, 15, 30).forEach { s ->
                    FilterChip(selected = net.sendDelay == s, onClick = { net.sendDelay = s; net.saveInt("sendDelay", s) },
                        label = { Text(stringResource(R.string.seconds_n, net.numStr("$s"))) })
                }
            }
        }
    }
    Group(stringResource(R.string.privacy)) {
        SwitchRow(stringResource(R.string.typing_status), stringResource(R.string.typing_status_desc), net.shareTyping) {
            net.shareTyping = it; net.saveBool("typing", it)
        }
    }
}

@Composable
private fun ConnectionCat(net: Net, onBg: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Group(stringResource(R.string.notifications)) {
        SwitchRow(stringResource(R.string.notifications), stringResource(R.string.notifications_desc), net.notifOn) { net.setNotif(it) }
        SwitchRow(stringResource(R.string.popup_tap), stringResource(R.string.popup_tap_desc), net.popupOnTap) {
            net.popupOnTap = it; net.saveBool("popup", it)
        }
    }
    Group(stringResource(R.string.cat_connection)) {
        SwitchRow(stringResource(R.string.background), stringResource(R.string.background_desc), net.bgService) {
            net.setBg(it); onBg(it)
        }
        Text(stringResource(R.string.conn_mode), fontWeight = FontWeight.Medium)
        ChipRow {
            listOf(R.string.mode_auto, R.string.mode_bt, R.string.mode_wifi).forEachIndexed { i, r ->
                FilterChip(selected = net.mode == i, onClick = { net.changeMode(i) }, label = { Text(stringResource(r)) })
            }
        }
        Text(stringResource(R.string.mode_desc), fontSize = 13.sp, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun DataCat(net: Net, onRestored: () -> Unit) {
    val ctx = LocalContext.current
    var restoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) net.exportBackup(uri) { ok ->
            Toast.makeText(ctx, if (ok) R.string.backup_saved else R.string.connect_failed, Toast.LENGTH_LONG).show()
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) restoreUri = uri
    }
    Group(stringResource(R.string.backup)) {
        Text(stringResource(R.string.backup_desc), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { exporter.launch("nearbychat-backup.zip") }) { Text(stringResource(R.string.backup_export)) }
            OutlinedButton(onClick = { importer.launch("*/*") }) { Text(stringResource(R.string.backup_import)) }
        }
    }
    restoreUri?.let { u ->
        AlertDialog(
            onDismissRequest = { restoreUri = null },
            text = { Text(stringResource(R.string.restore_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    restoreUri = null
                    net.importBackup(u) { ok ->
                        Toast.makeText(ctx, if (ok) R.string.restore_done else R.string.connect_failed, Toast.LENGTH_LONG).show()
                        if (ok) onRestored()
                    }
                }) { Text(stringResource(R.string.backup_import)) }
            },
            dismissButton = { TextButton(onClick = { restoreUri = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
private fun AboutCat(net: Net) {
    val cs = MaterialTheme.colorScheme
    Group(stringResource(R.string.about)) {
        Text("Nearby Chat 4.2", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.your_id, net.myId), color = cs.onSurfaceVariant)
        Text(stringResource(R.string.about_desc), fontSize = 13.sp, color = cs.onSurfaceVariant)
    }
}

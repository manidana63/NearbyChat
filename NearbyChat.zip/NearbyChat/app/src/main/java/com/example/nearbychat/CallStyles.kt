package com.example.nearbychat

import android.net.Uri
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

/** Avatar for phone contacts: photo if any, otherwise a coloured initial. */
@Composable
fun GenericAvatar(name: String, size: Dp, photo: String? = null) {
    val bmp = if (photo != null) rememberUriBitmap(Uri.parse(photo), 256) else null
    val bg = Color.hsv((abs(name.hashCode()) % 360).toFloat(), 0.45f, 0.72f)
    Box(Modifier.size(size).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(name.trim().take(1).uppercase().ifEmpty { "#" }, color = Color.White,
            fontSize = (size.value / 2.2f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun RoundBtn(emoji: String, label: String, bg: Color, fg: Color, labelColor: Color, size: Dp = 64.dp, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(size).clip(CircleShape).background(bg).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = (size.value * 0.42f).sp, color = fg)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, color = labelColor)
    }
}

/** Button colours that fit each call-screen style. */
@Composable
fun callBtnBg(style: Int, active: Boolean = false): Color {
    val cs = MaterialTheme.colorScheme
    return when (style) {
        0 -> Color.White.copy(alpha = if (active) 0.38f else 0.16f)
        1 -> Color.White.copy(alpha = if (active) 0.34f else 0.14f)
        2 -> if (active) cs.primary else cs.surfaceVariant
        else -> if (active) cs.primary.copy(alpha = 0.55f) else Color(0xFF1B1B1F)
    }
}

@Composable
fun callFg(style: Int, active: Boolean = false): Color {
    val cs = MaterialTheme.colorScheme
    return if (style == 2) (if (active) cs.onPrimary else cs.onSurface) else Color.White
}

@Composable
fun callTextColor(style: Int): Color = if (style == 2) MaterialTheme.colorScheme.onBackground else Color.White

/**
 * Full-screen call layout used by phone calls and app-to-app calls.
 * style: 0 Aurora (gradient), 1 Classic, 2 Minimal, 3 Neon.
 */
@Composable
fun CallLayout(
    style: Int, title: String, status: String, pulse: Boolean,
    avatar: @Composable (Dp) -> Unit,
    controls: @Composable ColumnScope.() -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val fg = callTextColor(style)
    val bgMod = when (style) {
        0 -> Modifier.background(Brush.verticalGradient(listOf(lerp(cs.primary, Color.Black, 0.2f), lerp(cs.primary, Color.Black, 0.6f), Color(0xFF05070A))))
        1 -> Modifier.background(barColor())
        2 -> Modifier.background(cs.background)
        else -> Modifier.background(Color.Black)
    }
    val inf = rememberInfiniteTransition(label = "call")
    val s by inf.animateFloat(1f, 1.14f, infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "r")
    val neon = lerp(cs.primary, Color.White, 0.35f)

    Box(Modifier.fillMaxSize().then(bgMod)) {
        if (style == 0) {
            Box(Modifier.size(340.dp).align(Alignment.TopEnd).offset(90.dp, (-70).dp).clip(CircleShape).background(Color.White.copy(alpha = 0.06f)))
            Box(Modifier.size(280.dp).align(Alignment.BottomStart).offset((-90).dp, 80.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.05f)))
        }
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 48.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    if (style == 0 && pulse) Box(Modifier.size((150 * s).dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)))
                    if (style == 0 && pulse) Box(Modifier.size((176 * s).dp).clip(CircleShape).background(Color.White.copy(alpha = 0.06f)))
                    if (style == 3) Box(
                        Modifier.size(176.dp).rotate(if (pulse) rot else 0f)
                            .border(3.dp, Brush.sweepGradient(listOf(neon, Color.Transparent, neon)), CircleShape)
                    )
                    if (style == 1 && pulse) Box(Modifier.size((150 * s).dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)))
                    avatar(if (style == 2) 112.dp else 140.dp)
                }
                Spacer(Modifier.height(24.dp))
                Text(title, color = fg, fontSize = 30.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                Spacer(Modifier.height(6.dp))
                Text(status, color = fg.copy(alpha = 0.75f), fontSize = 18.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(bottom = 12.dp)) { controls() }
        }
    }
}

/** App-to-app (Bluetooth / Wi-Fi) call screen. */
@Composable
fun CallScreen(net: Net, onAccept: () -> Unit) {
    val peer = net.callPeer ?: ""
    val name = net.title(peer)
    val st = net.callStyle
    val lc = callTextColor(st).copy(alpha = 0.85f)
    val red = Color(0xFFD32F2F)
    CallLayout(
        style = st, title = name,
        status = stringResource(when (net.callState) {
            CallState.OUTGOING -> R.string.calling
            CallState.INCOMING -> R.string.incoming_call
            else -> R.string.in_call
        }) + " · " + stringResource(R.string.via_app),
        pulse = net.callState != CallState.ACTIVE,
        avatar = { Avatar(net, peer, name, it) }
    ) {
        if (net.callState == CallState.INCOMING) {
            Row(horizontalArrangement = Arrangement.spacedBy(56.dp)) {
                RoundBtn("📞", stringResource(R.string.accept), Color(0xFF25D366), Color.White, lc, 72.dp, onAccept)
                RoundBtn("✖", stringResource(R.string.decline), red, Color.White, lc, 72.dp) { net.endCall() }
            }
        } else {
            RoundBtn("✖", stringResource(if (net.callState == CallState.OUTGOING) R.string.cancel else R.string.end_call),
                red, Color.White, lc, 72.dp) { net.endCall() }
        }
    }
}

/** Small preview card used to pick a call style in settings. */
@Composable
fun StyleCard(style: Int, selected: Boolean, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg: Brush = when (style) {
        0 -> Brush.verticalGradient(listOf(lerp(cs.primary, Color.Black, 0.2f), Color(0xFF05070A)))
        1 -> Brush.verticalGradient(listOf(cs.primary, cs.primary))
        2 -> Brush.verticalGradient(listOf(cs.background, cs.background))
        else -> Brush.verticalGradient(listOf(Color.Black, Color.Black))
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Box(
            Modifier.size(64.dp, 92.dp).clip(RoundedCornerShape(14.dp)).background(bg)
                .border(if (selected) 3.dp else 1.dp, if (selected) cs.primary else cs.onSurfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(26.dp).clip(CircleShape).background(if (style == 2) cs.primary else Color.White.copy(alpha = 0.85f)))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 12.sp, color = if (selected) cs.primary else cs.onSurfaceVariant)
    }
}

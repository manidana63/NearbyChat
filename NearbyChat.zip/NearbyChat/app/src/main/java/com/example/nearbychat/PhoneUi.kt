package com.example.nearbychat

import android.Manifest
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PermState(val granted: Boolean, val request: () -> Unit)

class PhoneNav(
    val dialer: (String) -> Unit,
    val contact: (Long) -> Unit,
    val sms: (String, String) -> Unit,
    val newSms: (String) -> Unit,
    val blocked: () -> Unit,
    val chat: (String) -> Unit,
    val appCall: (String) -> Unit,
    val form: (Long, String) -> Unit
)

/** "Granted" follows the first permission; the others are requested together with it. */
@Composable
fun rememberPerm(primary: String, vararg more: String): PermState {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var ok by remember { mutableStateOf(PhoneRepo.has(ctx, primary)) }
    val list = listOf(primary) + more.toList()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        ok = PhoneRepo.has(ctx, primary)
        PhoneRepo.bump()
    }
    return PermState(ok) { launcher.launch(list.toTypedArray()) }
}

@Composable
fun PermGate(textRes: Int, st: PermState) {
    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(stringResource(textRes), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = st.request) { Text(stringResource(R.string.allow)) }
    }
}

@Composable
fun SecLabel(t: String) =
    Text(t, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))

// ---------------------------------------------------------------- calling

/** Handles permissions, SIM choice (rules, default, ask) and then places the call. */
@Composable
fun CallerHost(net: Net, content: @Composable (call: (String, Int) -> Unit) -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val perm = rememberPerm(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE)
    var ask by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<Pair<String, Int>?>(null) }
    var always by remember { mutableStateOf(false) }

    fun place(num: String, sim: SimInfo?) {
        if (!PhoneRepo.placeCall(ctx, num, sim)) Toast.makeText(ctx, R.string.call_failed, Toast.LENGTH_SHORT).show()
    }

    fun start(num: String, forced: Int) {
        if (num.isBlank()) return
        if (!perm.granted) { pending = num to forced; perm.request(); return }
        val list = PhoneRepo.sims(ctx)
        if (list.size < 2) { place(num, null); return }
        val rule = if (forced >= 0) forced else PhoneRepo.simRule(ctx, num)
        val def = net.simCall
        when {
            rule >= 0 -> place(num, list.firstOrNull { it.slot == rule })
            def >= 0 -> place(num, list.firstOrNull { it.slot == def })
            def == -1 -> { always = false; ask = num }
            else -> place(num, null)
        }
    }

    LaunchedEffect(perm.granted) {
        if (perm.granted) pending?.let { pending = null; start(it.first, it.second) }
    }

    content { n, f -> start(n, f) }

    ask?.let { num ->
        val simList = remember(num) { PhoneRepo.sims(ctx) }
        AlertDialog(
            onDismissRequest = { ask = null },
            title = { Text(stringResource(R.string.choose_sim)) },
            text = {
                Column {
                    simList.forEach { s ->
                        TextButton(onClick = {
                            if (always) PhoneRepo.setSimRule(ctx, num, s.slot)
                            ask = null
                            place(num, s)
                        }) { Text(s.label) }
                    }
                    Row(Modifier.clickable { always = !always }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = always, onCheckedChange = { always = it })
                        Text(stringResource(R.string.always_sim), fontSize = 14.sp)
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { ask = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

// ---------------------------------------------------------------- recents

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CallRow(net: Net, e: CallEntry, onClick: () -> Unit, onLong: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val red = Color(0xFFD32F2F)
    val missed = e.type == 3 || e.type == 5 || e.type == 6
    val (arrow, col) = when (e.type) {
        1 -> "↙" to Color(0xFF25D366)
        2 -> "↗" to cs.primary
        3 -> "✕" to red
        5 -> "⊘" to red
        6 -> "⛔" to red
        else -> "•" to cs.onSurfaceVariant
    }
    val dur = if (e.duration > 0) "  ·  " + net.numStr("%d:%02d".format(e.duration / 60, e.duration % 60)) else ""
    Row(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLong).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GenericAvatar(e.name ?: e.number, 46.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(e.name ?: net.numStr(e.number.ifBlank { stringResource(R.string.unknown) }), fontSize = 17.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (missed) red else Color.Unspecified)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(arrow, color = col, fontSize = 14.sp)
                Spacer(Modifier.width(6.dp))
                Text(fmtFull(e.date, net.calendar) + dur, fontSize = 13.sp, color = cs.onSurfaceVariant)
            }
        }
        Icon(Icons.Filled.Call, null, tint = cs.primary, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun CallsTab(net: Net, nav: PhoneNav) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val cs = MaterialTheme.colorScheme
    val perm = rememberPerm(Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CALL_LOG)
    var filter by remember { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf<CallEntry?>(null) }
    val ver = PhoneRepo.version
    val calls by produceState(emptyList<CallEntry>(), ver, perm.granted) {
        value = withContext(Dispatchers.IO) { PhoneRepo.loadCalls(ctx) }
    }
    val shown = calls.filter { e ->
        when (filter) { 1 -> e.type == 3 || e.type == 5; 2 -> e.type == 1; 3 -> e.type == 2; else -> true }
    }
    CallerHost(net) { call ->
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(R.string.f_all, R.string.f_missed, R.string.f_in, R.string.f_out).forEachIndexed { i, r ->
                        FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(stringResource(r)) })
                    }
                }
                if (!perm.granted) PermGate(R.string.perm_calls, perm)
                else if (shown.isEmpty()) Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.no_calls), color = cs.onSurfaceVariant)
                } else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
                    items(shown, key = { it.id }) { e -> CallRow(net, e, { call(e.number, -1) }, { menu = e }) }
                }
            }
            FloatingActionButton(
                onClick = { nav.dialer("") }, containerColor = cs.primary, contentColor = cs.onPrimary,
                modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
            ) { Text("⌨", fontSize = 24.sp) }
        }
    }
    menu?.let { e ->
        val blockedNow = PhoneRepo.isBlockedKey(PhoneRepo.keyOf(e.number), false)
        AlertDialog(
            onDismissRequest = { menu = null },
            title = { Text(e.name ?: net.numStr(e.number)) },
            text = {
                Column {
                    TextButton(onClick = { menu = null; nav.sms(PhoneRepo.keyOf(e.number), e.number) }) { Text("💬  " + stringResource(R.string.send_sms)) }
                    val known = PhoneRepo.contacts.firstOrNull { c -> c.numbers.any { PhoneRepo.keyOf(it) == PhoneRepo.keyOf(e.number) } }
                    if (known != null) TextButton(onClick = { menu = null; nav.contact(known.id) }) { Text("👤  " + stringResource(R.string.view_contact)) }
                    else if (e.number.isNotBlank()) TextButton(onClick = { menu = null; nav.form(-1L, e.number) }) { Text("➕  " + stringResource(R.string.add_to_contacts)) }
                    TextButton(onClick = { menu = null; nav.dialer(e.number) }) { Text("⌨  " + stringResource(R.string.edit_before_call)) }
                    if (e.number.isNotBlank()) TextButton(onClick = {
                        menu = null
                        if (blockedNow) PhoneRepo.unblock(ctx, PhoneRepo.keyOf(e.number)) else PhoneRepo.block(ctx, e.number)
                    }) { Text(if (blockedNow) "✅  " + stringResource(R.string.unblock) else "⛔  " + stringResource(R.string.block)) }
                    TextButton(onClick = {
                        menu = null
                        if (!PhoneRepo.deleteCall(ctx, e.id)) Toast.makeText(ctx, R.string.need_default_phone, Toast.LENGTH_LONG).show()
                        PhoneRepo.bump()
                    }) { Text("🗑  " + stringResource(R.string.delete_from_log), color = Color(0xFFD32F2F)) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menu = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

// ---------------------------------------------------------------- contacts

@Composable
fun ContactsTab(net: Net, nav: PhoneNav) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val cs = MaterialTheme.colorScheme
    val perm = rememberPerm(Manifest.permission.READ_CONTACTS)
    var q by remember { mutableStateOf("") }
    val ver = PhoneRepo.version
    val list by produceState(emptyList<PhoneContact>(), ver, perm.granted) {
        value = withContext(Dispatchers.IO) { PhoneRepo.loadContacts(ctx) }
    }
    val scope = rememberCoroutineScope()
    val writePerm = rememberPerm(Manifest.permission.WRITE_CONTACTS, Manifest.permission.READ_CONTACTS)
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-vcard")) { uri ->
        if (uri != null) scope.launch {
            val n = withContext(Dispatchers.IO) {
                try { ctx.contentResolver.openOutputStream(uri)?.use { PhoneRepo.exportVcf(ctx, it) } ?: -1 } catch (_: Exception) { -1 }
            }
            Toast.makeText(ctx, if (n >= 0) ctx.getString(R.string.exported_n, n) else ctx.getString(R.string.connect_failed), Toast.LENGTH_LONG).show()
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val n = withContext(Dispatchers.IO) {
                try { ctx.contentResolver.openInputStream(uri)?.use { PhoneRepo.importVcf(ctx, it) } ?: -1 } catch (_: Exception) { -1 }
            }
            PhoneRepo.bump()
            Toast.makeText(ctx, if (n >= 0) ctx.getString(R.string.imported_n, n) else ctx.getString(R.string.connect_failed), Toast.LENGTH_LONG).show()
        }
    }
    val qn = PhoneRepo.norm(q)
    val filtered = remember(list, q) {
        if (q.isBlank()) list else list.filter { c ->
            c.name.contains(q, true) || (qn.isNotEmpty() && c.numbers.any { PhoneRepo.norm(it).contains(qn) })
        }
    }
    val groupsMap = remember(filtered) { filtered.groupBy { it.name.trim().take(1).uppercase().ifEmpty { "#" } } }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                placeholder = { Text(stringResource(R.string.search)) },
                shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().padding(12.dp)
            )
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { if (!writePerm.granted) writePerm.request() else importer.launch("*/*") }) {
                    Text("⬇  " + stringResource(R.string.import_contacts))
                }
                OutlinedButton(onClick = { if (!perm.granted) perm.request() else exporter.launch("contacts.vcf") }) {
                    Text("⬆  " + stringResource(R.string.export_contacts))
                }
            }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
                if (net.contacts.isNotEmpty() && q.isBlank()) {
                    item(key = "hdr-app") { SecLabel(stringResource(R.string.app_contacts)) }
                    items(net.contacts, key = { "app" + it.id }) { c ->
                        Row(Modifier.fillMaxWidth().clickable { nav.chat(c.id) }.padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Avatar(net, c.id, c.name, 44.dp, online = net.online.contains(c.id))
                            Spacer(Modifier.width(14.dp))
                            Text(c.name, Modifier.weight(1f), fontSize = 17.sp)
                            Text("💬", fontSize = 18.sp)
                        }
                    }
                }
                if (!perm.granted) item(key = "gate") { PermGate(R.string.perm_contacts, perm) }
                val stars = filtered.filter { it.starred }
                if (stars.isNotEmpty() && q.isBlank()) {
                    item(key = "hdr-fav") { SecLabel("★  " + stringResource(R.string.favorites)) }
                    items(stars, key = { "fav" + it.id }) { c -> ContactRow(net, c) { nav.contact(c.id) } }
                }
                groupsMap.forEach { (letter, group) ->
                    item(key = "h$letter") { SecLabel(letter) }
                    items(group, key = { it.id }) { c -> ContactRow(net, c) { nav.contact(c.id) } }
                }
            }
        }
        FloatingActionButton(
            onClick = { nav.form(-1L, "") },
            containerColor = cs.primary, contentColor = cs.onPrimary,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
        ) { Icon(Icons.Filled.Add, stringResource(R.string.add_contact)) }
    }
}

@Composable
fun ContactRow(net: Net, c: PhoneContact, onClick: () -> Unit) {
    val hasApp = c.numbers.any { net.phoneToUser.containsKey(PhoneRepo.norm(it)) }
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        GenericAvatar(c.name, 44.dp, c.photo)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(c.name, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (c.numbers.isNotEmpty()) Text(net.numStr(c.numbers.first()), fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (hasApp) Text("📲", fontSize = 18.sp)
    }
}

// ---------------------------------------------------------------- dialer

private val KEYS = listOf(
    "1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO",
    "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to ""
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DialKey(net: Net, main: String, sub: String, onClick: () -> Unit, onLong: (() -> Unit)?) {
    val cs = MaterialTheme.colorScheme
    val style = net.dialStyle
    val shape = if (style == 1) RoundedCornerShape(22.dp) else CircleShape
    val size = if (style == 1) Modifier.size(88.dp, 62.dp) else Modifier.size(74.dp)
    Box(
        size.clip(shape).background(if (style == 2) Color.Transparent else cs.surface)
            .combinedClickable(onClick = onClick, onLongClick = onLong),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(net.numStr(main), fontSize = 28.sp, fontWeight = FontWeight.Medium)
            if (sub.isNotEmpty() && !net.faNum()) Text(sub, fontSize = 10.sp, color = cs.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DialerScreen(net: Net, initial: String, onBack: () -> Unit, nav: PhoneNav) {
    val cs = MaterialTheme.colorScheme
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var digits by remember { mutableStateOf(PhoneRepo.ascii(initial)) }
    var sel by remember { mutableIntStateOf(-1) }
    val sims = remember { PhoneRepo.sims(ctx) }
    val perm = rememberPerm(Manifest.permission.READ_CONTACTS)
    LaunchedEffect(perm.granted) {
        if (perm.granted && PhoneRepo.contacts.isEmpty()) withContext(Dispatchers.IO) { PhoneRepo.loadContacts(ctx) }
    }
    val tone = remember { try { ToneGenerator(AudioManager.STREAM_DTMF, 70) } catch (_: Throwable) { null } }
    DisposableEffect(Unit) { onDispose { try { tone?.release() } catch (_: Throwable) {} } }
    val sug = remember(digits, PhoneRepo.version) { PhoneRepo.suggest(digits) }
    val appUser = if (digits.length >= 7) net.phoneToUser[PhoneRepo.norm(digits)] else null

    fun press(k: String) {
        digits += k
        try {
            tone?.startTone(when (k) { "*" -> ToneGenerator.TONE_DTMF_S; "#" -> ToneGenerator.TONE_DTMF_P; else -> k.toInt() }, 80)
        } catch (_: Throwable) {}
    }

    CallerHost(net) { call ->
        Column(Modifier.fillMaxSize().background(cs.background)) {
            TopBar(stringResource(R.string.dialer), onBack)
            Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center) {
                sug.forEach { c ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { digits = PhoneRepo.ascii(c.numbers.first()).filter { it.isDigit() || it == '+' } }
                        .padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        GenericAvatar(c.name, 34.dp, c.photo)
                        Spacer(Modifier.width(10.dp))
                        Text(c.name, Modifier.weight(1f), maxLines = 1)
                        Text(net.numStr(c.numbers.first()), color = cs.onSurfaceVariant, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (digits.isEmpty()) stringResource(R.string.enter_number) else net.numStr(digits),
                    fontSize = if (digits.length > 12) 26.sp else 38.sp, maxLines = 1,
                    color = if (digits.isEmpty()) cs.onSurfaceVariant else cs.onBackground, fontWeight = FontWeight.Light
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (digits.length >= 3) TextButton(onClick = { nav.form(-1L, digits) }) { Text("➕ " + stringResource(R.string.add_contact)) }
                    if (appUser != null) TextButton(onClick = {
                        if (net.online.contains(appUser)) nav.appCall(appUser) else nav.chat(appUser)
                    }) { Text("📲 " + stringResource(if (net.online.contains(appUser)) R.string.free_call else R.string.chat_in_app)) }
                }
            }
            KEYS.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { (k, s) ->
                        DialKey(net, k, s, { press(k) }, if (k == "0") ({ digits += "+" }) else null)
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.width(120.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (sims.size >= 2) sims.forEach { s ->
                        FilterChip(selected = sel == s.slot, onClick = { sel = if (sel == s.slot) -1 else s.slot },
                            label = { Text(s.tiny(), maxLines = 1) })
                    }
                }
                Box(Modifier.size(72.dp).clip(CircleShape).background(Color(0xFF25D366)).clickable { call(digits, sel) },
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Call, stringResource(R.string.call), tint = Color.White, modifier = Modifier.size(32.dp))
                }
                Box(Modifier.width(120.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(56.dp).clip(CircleShape)
                        .combinedClickable(onClick = { if (digits.isNotEmpty()) digits = digits.dropLast(1) }, onLongClick = { digits = "" }),
                        contentAlignment = Alignment.Center) { Text("⌫", fontSize = 26.sp) }
                }
            }
        }
    }
}

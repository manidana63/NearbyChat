package com.example.nearbychat

import android.app.Application

class App : Application() {
    lateinit var net: Net
    override fun onCreate() {
        super.onCreate()
        net = Net(this)
        PhoneRepo.init(this)
    }
}

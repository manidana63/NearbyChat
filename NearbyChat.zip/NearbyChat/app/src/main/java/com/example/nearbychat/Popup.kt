package com.example.nearbychat

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Small pop-up shown over any app when a message notification is tapped. */
class PopupActivity : ComponentActivity() {
    private var target by mutableStateOf<Triple<String, String, String>?>(null)

    override fun attachBaseContext(base: Context) = super.attachBaseContext(wrapLang(base))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        read(intent)
        val net = (application as App).net
        setContent {
            AppTheme(net, transparent = true) {
                PopupScreen(net, target, onClose = { finish() }, onOpen = { openMain() })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        read(intent)
    }

    private fun read(i: Intent) {
        target = if (i.hasExtra("sms_key")) Triple("sms", i.getStringExtra("sms_key") ?: "", i.getStringExtra("sms_addr") ?: "")
        else i.getStringExtra("conv")?.let { Triple("chat", it, "") }
    }

    private fun openMain() {
        val t = target
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (t != null) {
            if (t.first == "sms") i.putExtra("sms_key", t.second).putExtra("sms_addr", t.third) else i.putExtra("conv", t.second)
        }
        startActivity(i)
        finish()
    }
}

@Composable
fun PopupScreen(net: Net, target: Triple<String, String, String>?, onClose: () -> Unit, onOpen: () -> Unit) {
    if (target == null) return
    val (kind, key, addr) = target
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val isSms = kind == "sms"
    var text by remember(key) { mutableStateOf("") }
    val smsMsgs by produceState(emptyList<SmsMsg>(), key, PhoneRepo.version) {
        value = if (isSms) withContext(Dispatchers.IO) {
            PhoneRepo.loadSms(ctx).filter { PhoneRepo.keyOf(it.address) == key }.sortedBy { it.date }.takeLast(6)
        } else emptyList()
    }
    val chatMsgs: List<Msg> = if (isSms) emptyList<Msg>() else (net.chats[key]?.takeLast(6) ?: emptyList<Msg>())
    val title = if (isSms) (PhoneRepo.nameFor(addr) ?: net.numStr(addr)) else net.title(key)
    val group = !isSms && net.isGroup(key)

    LaunchedEffect(key, chatMsgs.size, smsMsgs.size) {
        if (isSms) withContext(Dispatchers.IO) { PhoneRepo.markRead(ctx, key) } else net.markRead(key, true)
    }

    fun send() {
        val t = text.trim()
        if (t.isEmpty()) return
        if (isSms) {
            val subId = PhoneRepo.sims(ctx).firstOrNull { it.slot == net.simSms }?.subId ?: -1
            net.requestSend(1, addr, t, null, subId)
        } else net.requestSend(0, key, t)
        text = ""
        onClose()
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() },
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp), color = cs.surface, shadowElevation = 16.dp,
            modifier = Modifier.padding(16.dp).fillMaxWidth().widthIn(max = 440.dp)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isSms) GenericAvatar(PhoneRepo.nameFor(addr) ?: addr, 42.dp) else Avatar(net, key, title, 42.dp, group = group)
                    Spacer(Modifier.width(12.dp))
                    Text(title, Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    IconButton(onClick = onClose) { Icon(Icons.Filled.Close, stringResource(R.string.close)) }
                }
                Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (isSms) smsMsgs.forEach { m ->
                        val mine = m.type != 1
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                            Surface(shape = RoundedCornerShape(net.bubbleDp()), color = if (mine) cs.primaryContainer else cs.surfaceVariant) {
                                Text(m.body, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), fontSize = 15.sp)
                            }
                        }
                    } else chatMsgs.forEach { m ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
                            Surface(shape = RoundedCornerShape(net.bubbleDp()), color = if (m.mine) cs.primaryContainer else cs.surfaceVariant) {
                                Text((if (group && !m.mine) m.senderName + ": " else "") + m.preview(),
                                    Modifier.padding(horizontal = 10.dp, vertical = 6.dp), fontSize = 15.sp)
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = text, onValueChange = { text = it }, maxLines = 3, shape = RoundedCornerShape(22.dp),
                        placeholder = { Text(stringResource(R.string.reply)) }, modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(6.dp))
                    val ok = text.isNotBlank()
                    Box(Modifier.size(46.dp).clip(CircleShape).background(if (ok) cs.primary else cs.surfaceVariant)
                        .clickable(enabled = ok) { send() }, contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.send), tint = if (ok) cs.onPrimary else cs.onSurfaceVariant)
                    }
                }
                TextButton(onClick = onOpen, modifier = Modifier.align(Alignment.End)) { Text(stringResource(R.string.popup_open)) }
            }
        }
    }
}

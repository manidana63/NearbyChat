package com.example.nearbychat

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import kotlin.math.abs

@Composable
private fun InfoRow(label: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.Top) {
        Text(label, Modifier.weight(0.4f), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, Modifier.weight(0.6f), fontSize = 15.sp)
    }
}

@Composable
fun ProfileScreen(
    net: Net, id: String, onBack: () -> Unit, onMessage: () -> Unit,
    onCall: (String) -> Unit, onMember: (String) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val group = net.isGroup(id)
    val title = net.title(id)
    val g = net.groups.find { it.id == id }
    val f = net.store.avatarFile(id)
    val custom = net.store.avatarFile("c_$id")
    val hasCustom = remember(net.avatarVersion) { custom.exists() }
    val path = if (hasCustom) custom.absolutePath else if (!group && f.exists()) f.absolutePath else null
    val bmp = rememberBitmap(path, net.avatarVersion, 1024)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) net.setCustomPhoto(id, u) }
    val isOnline = !group && net.online.contains(id)
    val ls = net.lastSeen[id] ?: 0L
    val infoSrc = net.infos[id]
    val info = remember(infoSrc) { try { JSONObject(infoSrc ?: "{}") } catch (_: Exception) { JSONObject() } }
    val msgs = net.chats[id]
    val bg = Color.hsv((abs(id.hashCode()) % 360).toFloat(), 0.45f, 0.72f)
    val unknown = stringResource(R.string.unknown)

    Column(Modifier.fillMaxSize()) {
        TopBar(title, onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            // large picture
            Box(Modifier.fillMaxWidth().aspectRatio(1f).background(bg).clickable { picker.launch("image/*") }, contentAlignment = Alignment.Center) {
                if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text(title.trim().take(1).uppercase(), color = Color.White, fontSize = 110.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(
                    when {
                        group -> stringResource(R.string.members_count, g?.members?.size ?: 0)
                        isOnline -> stringResource(R.string.online)
                        ls > 0 -> stringResource(R.string.last_seen, fmtFull(ls, net.calendar))
                        else -> stringResource(R.string.offline_status)
                    },
                    color = if (isOnline) Color(0xFF25D366) else cs.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onMessage) { Text(stringResource(R.string.message_btn)) }
                    if (isOnline) OutlinedButton(onClick = { onCall(id) }) { Text(stringResource(R.string.call)) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { picker.launch("image/*") }) { Text("📷  " + stringResource(R.string.set_photo)) }
                    if (hasCustom) TextButton(onClick = { net.removeCustomPhoto(id) }) { Text(stringResource(R.string.remove_photo)) }
                }

                Surface(shape = RoundedCornerShape(16.dp), color = cs.surface, shadowElevation = 1.dp) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                        if (group && g != null) {
                            InfoRow(stringResource(R.string.created_by),
                                if (g.creator == net.myId) stringResource(R.string.you)
                                else g.members.find { it.id == g.creator }?.name ?: unknown)
                        } else {
                            InfoRow(stringResource(R.string.device_model), info.optString("model"))
                            InfoRow(stringResource(R.string.phone_name), info.optString("dev"))
                            InfoRow(stringResource(R.string.system_os), info.optString("os"))
                            InfoRow(stringResource(R.string.app_version), info.optString("app"))
                            InfoRow(stringResource(R.string.user_id), id)
                            net.since(id).let { if (it > 0) InfoRow(stringResource(R.string.saved_since), fmtDate(it, net.calendar)) }
                            InfoRow(stringResource(R.string.connection), when (net.linkKind(id)) {
                                "wifi" -> stringResource(R.string.conn_wifi)
                                "bt" -> stringResource(R.string.conn_bt)
                                else -> unknown
                            })
                        }
                        InfoRow(stringResource(R.string.messages_count), (msgs?.size ?: 0).let { if (net.calendar == 1) faDigits("$it") else "$it" })
                        InfoRow(stringResource(R.string.files_count),
                            (msgs?.count { it.fileName != null } ?: 0).let { if (net.calendar == 1) faDigits("$it") else "$it" })
                    }
                }

                if (group && g != null) {
                    Text(stringResource(R.string.members_title), color = cs.primary, fontWeight = FontWeight.Bold)
                    g.members.forEach { mem ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .clickable(enabled = mem.id != net.myId) { onMember(mem.id) }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val nm = if (mem.id == net.myId) net.myName else net.title(mem.id).let { if (it == mem.id) mem.name else it }
                            Avatar(net, if (mem.id == net.myId) "me" else mem.id, nm, 42.dp,
                                online = mem.id != net.myId && net.online.contains(mem.id))
                            Spacer(Modifier.width(12.dp))
                            Text(nm + if (mem.id == net.myId) "  (" + stringResource(R.string.you) + ")" else "", Modifier.weight(1f), fontSize = 16.sp)
                            if (mem.id == g.creator) Text(stringResource(R.string.created_by), fontSize = 12.sp, color = cs.primary)
                        }
                    }
                }
            }
        }
    }
}

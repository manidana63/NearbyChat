package com.example.nearbychat

import android.Manifest
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.ContentProviderOperation
import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.provider.ContactsContract
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.provider.Telephony
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

data class PhoneContact(
    val id: Long, val name: String, val numbers: List<String>, val photo: String?, val starred: Boolean,
    val emails: List<String> = emptyList(), val photoFull: String? = null
)
data class ContactForm(val first: String, val last: String, val phones: List<Pair<Int, String>>, val emails: List<String>, val note: String)
data class ContactDetail(val id: Long, val first: String, val last: String, val phones: List<Pair<Int, String>>, val emails: List<String>, val note: String)
data class CallEntry(val id: Long, val number: String, val name: String?, val type: Int, val date: Long, val duration: Long)
data class SmsMsg(val id: Long, val address: String, val body: String, val date: Long, val type: Int, val read: Boolean, val subId: Int)
data class SmsThread(val key: String, val address: String, val last: SmsMsg, val unread: Int, val count: Int)
data class SimInfo(val slot: Int, val label: String, val subId: Int, val handle: PhoneAccountHandle?, val short: String = "") {
    fun tiny(): String = if (short.startsWith("SIM ")) short.removePrefix("SIM ") else short.take(6)
}
data class BlockedItem(val key: String, val label: String, val calls: Boolean, val sms: Boolean)
data class BlockEvent(val kind: String, val key: String, val text: String, val time: Long)

/** Contacts, call log, SMS, SIMs and the block list. */
object PhoneRepo {
    var version by mutableIntStateOf(0)
    fun bump() { version++ }

    val blocked = mutableStateListOf<BlockedItem>()
    val blockLog = mutableStateListOf<BlockEvent>()
    @Volatile var contacts: List<PhoneContact> = emptyList()
    @Volatile var names: Map<String, String> = emptyMap()
    private var inited = false
    private val main = Handler(Looper.getMainLooper())

    fun prefs(ctx: Context) = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    fun has(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        try {
            val a = JSONArray(prefs(ctx).getString("blocked", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                blocked.add(BlockedItem(o.getString("k"), o.optString("l"), o.optBoolean("c", true), o.optBoolean("s", true)))
            }
            val b = JSONArray(prefs(ctx).getString("blocklog", "[]") ?: "[]")
            for (i in 0 until b.length()) {
                val o = b.getJSONObject(i)
                blockLog.add(BlockEvent(o.getString("t"), o.getString("k"), o.optString("x"), o.getLong("d")))
            }
        } catch (_: Exception) {}
    }

    // ---------------- numbers ----------------

    fun ascii(s: String): String = buildString {
        for (c in s) append(when (c) { in '۰'..'۹' -> '0' + (c - '۰'); in '٠'..'٩' -> '0' + (c - '٠'); else -> c })
    }

    fun norm(n: String): String {
        val d = ascii(n).filter { it in '0'..'9' }
        return if (d.length > 10) d.takeLast(10) else d
    }

    fun keyOf(addr: String): String = norm(addr).ifEmpty { addr.trim().lowercase() }

    fun nameFor(number: String): String? = names[keyOf(number)]

    fun t9(s: String): String = buildString {
        for (ch in s.lowercase()) append(when (ch) {
            in 'a'..'c' -> '2'; in 'd'..'f' -> '3'; in 'g'..'i' -> '4'; in 'j'..'l' -> '5'
            in 'm'..'o' -> '6'; in 'p'..'s' -> '7'; in 't'..'v' -> '8'; in 'w'..'z' -> '9'
            in '0'..'9' -> ch; else -> ' '
        })
    }

    fun suggest(q: String, limit: Int = 3): List<PhoneContact> {
        if (q.length < 2) return emptyList()
        return contacts.filter { c ->
            c.numbers.any { norm(it).contains(q) || ascii(it).filter { ch -> ch in '0'..'9' }.contains(q) } ||
                t9(c.name).replace(" ", "").contains(q)
        }.take(limit)
    }

    // ---------------- contacts ----------------

    fun loadContacts(ctx: Context): List<PhoneContact> {
        if (!has(ctx, Manifest.permission.READ_CONTACTS)) return emptyList()
        val ids = LinkedHashMap<Long, MutableList<String>>()
        val nm = HashMap<Long, String>()
        val ph = HashMap<Long, String?>()
        val pf = HashMap<Long, String?>()
        val st = HashMap<Long, Boolean>()
        val em = HashMap<Long, MutableList<String>>()
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf("contact_id", "display_name", "data1", "photo_thumb_uri", "starred", "photo_uri"),
                null, null, "display_name COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val num = c.getString(2) ?: continue
                    nm[id] = c.getString(1) ?: num
                    ph[id] = c.getString(3)
                    st[id] = c.getInt(4) == 1
                    pf[id] = c.getString(5)
                    val l = ids.getOrPut(id) { mutableListOf() }
                    if (l.none { norm(it) == norm(num) }) l.add(num)
                }
            }
        } catch (_: Exception) {}
        try {
            ctx.contentResolver.query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, arrayOf("contact_id", "data1"), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val a = c.getString(1) ?: continue
                    em.getOrPut(c.getLong(0)) { mutableListOf() }.add(a)
                }
            }
        } catch (_: Exception) {}
        val list = ids.map { (id, nums) ->
            PhoneContact(id, nm[id] ?: "", nums, ph[id], st[id] == true, em[id] ?: emptyList(), pf[id])
        }
        contacts = list
        val m = HashMap<String, String>()
        list.forEach { c -> c.numbers.forEach { n -> m[keyOf(n)] = c.name } }
        names = m
        return list
    }

    // ---------------- call log ----------------

    fun loadCalls(ctx: Context, limit: Int = 500): List<CallEntry> {
        if (!has(ctx, Manifest.permission.READ_CALL_LOG)) return emptyList()
        if (names.isEmpty()) loadContacts(ctx)
        val out = ArrayList<CallEntry>()
        try {
            val proj = arrayOf(CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION)
            val cur = if (Build.VERSION.SDK_INT >= 26) {
                ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, proj, Bundle().apply {
                    putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "date DESC")
                    putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
                }, null)
            } else ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, proj, null, null, "date DESC")
            cur?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val number = c.getString(1) ?: ""
                    out.add(CallEntry(c.getLong(0), number, c.getString(2)?.ifBlank { null } ?: nameFor(number),
                        c.getInt(3), c.getLong(4), c.getLong(5)))
                }
            }
        } catch (_: Exception) {}
        return out
    }

    fun deleteCall(ctx: Context, id: Long): Boolean = try {
        ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, "_id=?", arrayOf(id.toString())) > 0
    } catch (_: Exception) { false }

    // ---------------- SMS ----------------

    fun isDefaultSms(ctx: Context) = try { Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName } catch (_: Throwable) { false }
    fun isDefaultDialer(ctx: Context) = try {
        ctx.getSystemService(TelecomManager::class.java).defaultDialerPackage == ctx.packageName
    } catch (_: Throwable) { false }

    fun roleIntent(ctx: Context, sms: Boolean): Intent =
        if (Build.VERSION.SDK_INT >= 29) {
            ctx.getSystemService(RoleManager::class.java)
                .createRequestRoleIntent(if (sms) RoleManager.ROLE_SMS else RoleManager.ROLE_DIALER)
        } else if (sms) {
            Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, ctx.packageName)
        } else {
            Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, ctx.packageName)
        }

    private fun localSms(ctx: Context): MutableList<SmsMsg> {
        val out = mutableListOf<SmsMsg>()
        try {
            val a = JSONArray(prefs(ctx).getString("smslocal", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(SmsMsg(o.getLong("i"), o.getString("a"), o.getString("b"), o.getLong("d"), 2, true, o.optInt("s", -1)))
            }
        } catch (_: Exception) {}
        return out
    }

    /** Messages we sent while not being the default SMS app (the system does not store those). */
    private fun addLocalSms(ctx: Context, m: SmsMsg) {
        val l = localSms(ctx)
        l.add(m)
        val a = JSONArray()
        l.takeLast(500).forEach { a.put(JSONObject().put("i", it.id).put("a", it.address).put("b", it.body).put("d", it.date).put("s", it.subId)) }
        prefs(ctx).edit().putString("smslocal", a.toString()).apply()
    }

    fun loadSms(ctx: Context, limit: Int = 4000): List<SmsMsg> {
        if (!has(ctx, Manifest.permission.READ_SMS)) return emptyList()
        if (names.isEmpty()) loadContacts(ctx)
        val out = ArrayList<SmsMsg>()
        try {
            val proj = arrayOf("_id", "address", "body", "date", "type", "read")
            val cur = if (Build.VERSION.SDK_INT >= 26) {
                ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, proj, Bundle().apply {
                    putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "date DESC")
                    putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
                }, null)
            } else ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, proj, null, null, "date DESC")
            cur?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    out.add(SmsMsg(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3),
                        c.getInt(4), c.getInt(5) == 1, -1))
                }
            }
        } catch (_: Exception) {}
        if (!isDefaultSms(ctx)) out.addAll(localSms(ctx))
        return out.sortedByDescending { it.date }
    }

    fun threads(msgs: List<SmsMsg>): List<SmsThread> {
        val g = LinkedHashMap<String, MutableList<SmsMsg>>()
        msgs.forEach { g.getOrPut(keyOf(it.address)) { mutableListOf() }.add(it) }
        return g.map { (k, l) -> SmsThread(k, l.first().address, l.first(), l.count { it.type == 1 && !it.read }, l.size) }
            .sortedByDescending { it.last.date }
    }

    @Suppress("DEPRECATION")
    private fun smsManager(ctx: Context, subId: Int): SmsManager =
        if (subId >= 0) {
            if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java).createForSubscriptionId(subId)
            else SmsManager.getSmsManagerForSubscriptionId(subId)
        } else if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
        else SmsManager.getDefault()

    fun sendSms(ctx: Context, to: String, body: String, subId: Int): Boolean {
        if (!has(ctx, Manifest.permission.SEND_SMS) || to.isBlank() || body.isBlank()) return false
        return try {
            val sm = smsManager(ctx, subId)
            val parts = sm.divideMessage(body)
            if (parts.size > 1) sm.sendMultipartTextMessage(to, null, parts, null, null)
            else sm.sendTextMessage(to, null, body, null, null)
            val now = System.currentTimeMillis()
            if (isDefaultSms(ctx)) {
                try {
                    val v = ContentValues()
                    v.put("address", to); v.put("body", body); v.put("date", now); v.put("read", 1); v.put("type", 2)
                    ctx.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, v)
                } catch (_: Exception) {}
            } else addLocalSms(ctx, SmsMsg(-now, to, body, now, 2, true, subId))
            bump()
            true
        } catch (_: Throwable) { false }
    }

    fun markRead(ctx: Context, key: String) {
        if (!isDefaultSms(ctx)) return
        try {
            loadSms(ctx).filter { keyOf(it.address) == key && it.type == 1 && !it.read }.forEach {
                val v = ContentValues(); v.put("read", 1)
                ctx.contentResolver.update(Uri.parse("content://sms/${it.id}"), v, null, null)
            }
        } catch (_: Exception) {}
    }

    fun deleteSms(ctx: Context, id: Long): Boolean = try {
        if (id < 0) {
            val l = localSms(ctx).filter { it.id != id }
            val a = JSONArray()
            l.forEach { a.put(JSONObject().put("i", it.id).put("a", it.address).put("b", it.body).put("d", it.date).put("s", it.subId)) }
            prefs(ctx).edit().putString("smslocal", a.toString()).apply()
            true
        } else ctx.contentResolver.delete(Uri.parse("content://sms/$id"), null, null) > 0
    } catch (_: Exception) { false }

    fun deleteThread(ctx: Context, key: String) {
        loadSms(ctx).filter { keyOf(it.address) == key }.forEach { deleteSms(ctx, it.id) }
        bump()
    }

    // ---------------- SIMs and calling ----------------

    fun sims(ctx: Context): List<SimInfo> {
        if (!has(ctx, Manifest.permission.READ_PHONE_STATE)) return emptyList()
        return try {
            val sm = ctx.getSystemService(SubscriptionManager::class.java)
            val subs = (sm.activeSubscriptionInfoList ?: emptyList()).sortedBy { it.simSlotIndex }
            val tm = ctx.getSystemService(TelecomManager::class.java)
            val handles: List<PhoneAccountHandle> = try { tm.callCapablePhoneAccounts } catch (_: Throwable) { emptyList() }
            subs.mapIndexed { i, s ->
                val icc = try { s.iccId } catch (_: Throwable) { null }
                val h = handles.firstOrNull { it.id == s.subscriptionId.toString() }
                    ?: handles.firstOrNull { icc != null && icc.isNotEmpty() && it.id.contains(icc) }
                    ?: handles.getOrNull(i)
                val nm = simName(ctx, s.simSlotIndex)
                SimInfo(s.simSlotIndex, nm + " · " + (s.displayName ?: ""), s.subscriptionId, h, nm)
            }
        } catch (_: Throwable) { emptyList() }
    }

    fun placeCall(ctx: Context, number: String, sim: SimInfo?): Boolean {
        if (!has(ctx, Manifest.permission.CALL_PHONE)) return false
        return try {
            val extras = Bundle()
            sim?.handle?.let { extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it) }
            ctx.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", number, null), extras)
            true
        } catch (_: Throwable) { false }
    }

    private fun rules(ctx: Context): JSONObject =
        try { JSONObject(prefs(ctx).getString("simrules", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }

    fun simRule(ctx: Context, number: String): Int = rules(ctx).optInt(keyOf(number), -1)

    fun setSimRule(ctx: Context, number: String, slot: Int) {
        val r = rules(ctx)
        if (slot < 0) r.remove(keyOf(number)) else r.put(keyOf(number), slot)
        prefs(ctx).edit().putString("simrules", r.toString()).apply()
    }

    // ---------------- blocking ----------------

    private fun saveBlocked(ctx: Context) {
        val a = JSONArray()
        blocked.forEach { a.put(JSONObject().put("k", it.key).put("l", it.label).put("c", it.calls).put("s", it.sms)) }
        prefs(ctx).edit().putString("blocked", a.toString()).apply()
    }

    fun isBlockedKey(key: String, sms: Boolean) = blocked.any { it.key == key && (if (sms) it.sms else it.calls) }

    fun block(ctx: Context, number: String, calls: Boolean = true, sms: Boolean = true) {
        val k = keyOf(number)
        val label = nameFor(number) ?: number
        val i = blocked.indexOfFirst { it.key == k }
        val item = BlockedItem(k, label, calls, sms)
        if (i < 0) blocked.add(item) else blocked[i] = item
        saveBlocked(ctx)
        bump()
    }

    fun unblock(ctx: Context, key: String) {
        blocked.removeAll { it.key == key }
        saveBlocked(ctx)
        bump()
    }

    fun update(ctx: Context, item: BlockedItem) {
        val i = blocked.indexOfFirst { it.key == item.key }
        if (i >= 0) blocked[i] = item
        saveBlocked(ctx)
    }

    private fun unknownRule(ctx: Context, number: String, sms: Boolean): Boolean {
        val p = prefs(ctx)
        if (!p.getBoolean("blk_unknown", false) || !has(ctx, Manifest.permission.READ_CONTACTS)) return false
        if (number.none { it.isDigit() }) return false
        if (names.isEmpty()) loadContacts(ctx)
        return names[keyOf(number)] == null
    }

    fun isBlockedCall(ctx: Context, number: String): Boolean {
        if (number.isBlank()) return prefs(ctx).getBoolean("blk_private", false)
        return isBlockedKey(keyOf(number), false) || unknownRule(ctx, number, false)
    }

    fun isBlockedSms(ctx: Context, address: String): Boolean =
        isBlockedKey(keyOf(address), true) || unknownRule(ctx, address, true)

    fun logBlock(ctx: Context, kind: String, number: String, text: String) {
        main.post {
            blockLog.add(0, BlockEvent(kind, number, text, System.currentTimeMillis()))
            while (blockLog.size > 200) blockLog.removeAt(blockLog.size - 1)
            val a = JSONArray()
            blockLog.forEach { a.put(JSONObject().put("t", it.kind).put("k", it.key).put("x", it.text).put("d", it.time)) }
            prefs(ctx).edit().putString("blocklog", a.toString()).apply()
        }
    }

    // ---------------- SIM names ----------------

    fun customSimName(ctx: Context, slot: Int): String = prefs(ctx).getString("simname_$slot", null)?.trim() ?: ""
    fun simName(ctx: Context, slot: Int): String = customSimName(ctx, slot).ifEmpty { "SIM ${slot + 1}" }
    fun setSimName(ctx: Context, slot: Int, name: String) {
        prefs(ctx).edit().putString("simname_$slot", name.trim()).apply()
        bump()
    }

    // ---------------- create / edit / delete contacts ----------------

    private const val M_NAME = "vnd.android.cursor.item/name"
    private const val M_PHONE = "vnd.android.cursor.item/phone_v2"
    private const val M_EMAIL = "vnd.android.cursor.item/email_v2"
    private const val M_NOTE = "vnd.android.cursor.item/note"
    private const val M_PHOTO = "vnd.android.cursor.item/photo"

    fun loadDetail(ctx: Context, id: Long): ContactDetail? {
        if (!has(ctx, Manifest.permission.READ_CONTACTS)) return null
        var first = ""
        var last = ""
        var display = ""
        var note = ""
        val phones = mutableListOf<Pair<Int, String>>()
        val emails = mutableListOf<String>()
        try {
            ctx.contentResolver.query(
                ContactsContract.Data.CONTENT_URI, arrayOf("mimetype", "data1", "data2", "data3"),
                "contact_id=?", arrayOf(id.toString()), null
            )?.use { c ->
                while (c.moveToNext()) {
                    val v1 = c.getString(1) ?: ""
                    when (c.getString(0)) {
                        M_NAME -> { display = v1; first = c.getString(2) ?: ""; last = c.getString(3) ?: "" }
                        M_PHONE -> if (v1.isNotBlank()) phones.add(c.getInt(2) to v1)
                        M_EMAIL -> if (v1.isNotBlank()) emails.add(v1)
                        M_NOTE -> note = v1
                    }
                }
            }
        } catch (_: Exception) { return null }
        if (first.isEmpty() && last.isEmpty()) first = display
        return ContactDetail(id, first, last, phones, emails, note)
    }

    private fun rawIdOf(ctx: Context, contactId: Long): Long? = try {
        ctx.contentResolver.query(
            ContactsContract.RawContacts.CONTENT_URI, arrayOf("_id"),
            "contact_id=? AND deleted=0", arrayOf(contactId.toString()), null
        )?.use { if (it.moveToFirst()) it.getLong(0) else null }
    } catch (_: Exception) { null }

    /** Creates (editId == null) or updates a contact. Returns the contact id, 0 if unknown, -1 on failure. */
    fun saveContact(ctx: Context, editId: Long?, f: ContactForm, photo: ByteArray?, reload: Boolean = true): Long {
        if (!has(ctx, Manifest.permission.WRITE_CONTACTS)) return -1L
        return try {
            val raw: Long? = if (editId != null) (rawIdOf(ctx, editId) ?: return -1L) else null
            val ops = ArrayList<ContentProviderOperation>()
            if (raw == null) {
                ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())
            } else {
                val mimes = mutableListOf(M_NAME, M_PHONE, M_EMAIL, M_NOTE)
                if (photo != null) mimes.add(M_PHOTO)
                mimes.forEach { m ->
                    ops.add(ContentProviderOperation.newDelete(ContactsContract.Data.CONTENT_URI)
                        .withSelection("raw_contact_id=? AND mimetype=?", arrayOf(raw.toString(), m)).build())
                }
            }
            fun row(mime: String): ContentProviderOperation.Builder {
                val b = ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                if (raw == null) b.withValueBackReference("raw_contact_id", 0) else b.withValue("raw_contact_id", raw)
                return b.withValue("mimetype", mime)
            }
            if (f.first.isNotEmpty() || f.last.isNotEmpty())
                ops.add(row(M_NAME).withValue("data2", f.first).withValue("data3", f.last).build())
            f.phones.forEach { (t, n) -> ops.add(row(M_PHONE).withValue("data1", n).withValue("data2", t).build()) }
            f.emails.forEach { e -> ops.add(row(M_EMAIL).withValue("data1", e).withValue("data2", 1).build()) }
            if (f.note.isNotEmpty()) ops.add(row(M_NOTE).withValue("data1", f.note).build())
            if (photo != null) ops.add(row(M_PHOTO).withValue("data15", photo).build())
            ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            if (reload) loadContacts(ctx)
            if (editId != null) editId
            else {
                val k = f.phones.firstOrNull()?.second?.let { keyOf(it) }
                contacts.firstOrNull { c -> k != null && c.numbers.any { keyOf(it) == k } }?.id ?: 0L
            }
        } catch (_: Throwable) { -1L }
    }

    fun deleteContact(ctx: Context, id: Long): Boolean = try {
        val ok = ctx.contentResolver.delete(android.content.ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id), null, null) > 0
        loadContacts(ctx)
        ok
    } catch (_: Throwable) { false }

    fun setContactPhoto(ctx: Context, id: Long, bytes: ByteArray): Boolean {
        if (!has(ctx, Manifest.permission.WRITE_CONTACTS)) return false
        return try {
            val raw = rawIdOf(ctx, id) ?: return false
            val ops = ArrayList<ContentProviderOperation>()
            ops.add(ContentProviderOperation.newDelete(ContactsContract.Data.CONTENT_URI)
                .withSelection("raw_contact_id=? AND mimetype=?", arrayOf(raw.toString(), M_PHOTO)).build())
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValue("raw_contact_id", raw).withValue("mimetype", M_PHOTO).withValue("data15", bytes).build())
            ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            loadContacts(ctx)
            true
        } catch (_: Throwable) { false }
    }

    /** Square JPEG (centre crop) from a picked image. */
    fun photoBytes(ctx: Context, uri: Uri, size: Int = 360): ByteArray? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (minOf(o.outWidth, o.outHeight) / (sample * 2) >= size) sample *= 2
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        if (bmp == null) null else {
            val side = minOf(bmp.width, bmp.height)
            val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(sq, size, size, true)
            val bo = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 85, bo)
            bo.toByteArray()
        }
    } catch (_: Throwable) { null }

    // ---------------- import / export (vCard .vcf) ----------------

    fun exportVcf(ctx: Context, out: OutputStream): Int {
        val list = loadContacts(ctx)
        val w = out.bufferedWriter(Charsets.UTF_8)
        fun esc(s: String) = s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
        for (c in list) {
            w.write("BEGIN:VCARD\r\nVERSION:3.0\r\n")
            w.write("FN:" + esc(c.name) + "\r\n")
            w.write("N:;" + esc(c.name) + ";;;\r\n")
            c.numbers.forEach { w.write("TEL;TYPE=CELL:" + it + "\r\n") }
            c.emails.forEach { w.write("EMAIL:" + it + "\r\n") }
            w.write("END:VCARD\r\n")
        }
        w.flush()
        return list.size
    }

    private fun qp(s: String): String {
        val out = ByteArrayOutputStream()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            val h = if (c == '=' && i + 2 < s.length) s.substring(i + 1, i + 3).toIntOrNull(16) else null
            if (h != null) { out.write(h); i += 3 } else { out.write(c.toString().toByteArray(Charsets.UTF_8)); i++ }
        }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    private fun unesc(s: String) = s.replace("\\n", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")

    /** Returns how many contacts were imported. */
    fun importVcf(ctx: Context, input: InputStream): Int {
        val text = input.bufferedReader(Charsets.UTF_8).readText()
        val lines = ArrayList<String>()
        for (raw in text.split("\n")) {
            val l = raw.trimEnd('\r')
            if ((l.startsWith(" ") || l.startsWith("\t")) && lines.isNotEmpty()) lines[lines.size - 1] = lines.last() + l.substring(1)
            else if (lines.isNotEmpty() && lines.last().contains("QUOTED-PRINTABLE", true) && lines.last().endsWith("="))
                lines[lines.size - 1] = lines.last().dropLast(1) + l
            else lines.add(l)
        }
        var count = 0
        var fn = ""
        var fam = ""
        var giv = ""
        var note = ""
        var inCard = false
        var phones = ArrayList<Pair<Int, String>>()
        var emails = ArrayList<String>()
        fun reset() { fn = ""; fam = ""; giv = ""; note = ""; phones = ArrayList(); emails = ArrayList() }
        fun flush() {
            val first = if (giv.isEmpty() && fam.isEmpty()) fn else giv
            if (first.isNotEmpty() || fam.isNotEmpty() || phones.isNotEmpty()) {
                if (saveContact(ctx, null, ContactForm(first, fam, phones, emails, note), null, reload = false) >= 0) count++
            }
        }
        for (l in lines) {
            val i = l.indexOf(':')
            if (i < 0) continue
            val head = l.substring(0, i)
            var value = l.substring(i + 1)
            val prop = head.substringBefore(';').uppercase()
            if (head.contains("QUOTED-PRINTABLE", true)) value = qp(value)
            when (prop) {
                "BEGIN" -> { inCard = true; reset() }
                "END" -> { if (inCard) flush(); inCard = false }
                "FN" -> fn = unesc(value)
                "N" -> { val p = value.split(";"); fam = unesc(p.getOrElse(0) { "" }); giv = unesc(p.getOrElse(1) { "" }) }
                "TEL" -> if (value.isNotBlank()) {
                    val h = head.uppercase()
                    phones.add((if ("HOME" in h) 1 else if ("WORK" in h) 3 else 2) to value.trim())
                }
                "EMAIL" -> if (value.isNotBlank()) emails.add(value.trim())
                "NOTE" -> note = unesc(value)
            }
        }
        loadContacts(ctx)
        return count
    }

    // ---------------- notifications ----------------

    fun notifySms(ctx: Context, address: String, body: String) {
        val net = (ctx.applicationContext as App).net
        if (!net.notifOn) return
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val key = keyOf(address)
        val target = if (net.popupOnTap) PopupActivity::class.java else MainActivity::class.java
        val i = Intent(ctx, target).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("sms_key", key).putExtra("sms_addr", address)
        val pi = PendingIntent.getActivity(ctx, key.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, Net.CH_SMS).setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(nameFor(address) ?: address).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body)).setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(pi).build()
        try { nm.notify(("sms" + key).hashCode(), n) } catch (_: SecurityException) {}
    }
}

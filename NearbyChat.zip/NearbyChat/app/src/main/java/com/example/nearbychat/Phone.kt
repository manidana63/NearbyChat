package com.example.nearbychat

import android.Manifest
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.provider.Telephony
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

data class PhoneContact(val id: Long, val name: String, val numbers: List<String>, val photo: String?, val starred: Boolean)
data class CallEntry(val id: Long, val number: String, val name: String?, val type: Int, val date: Long, val duration: Long)
data class SmsMsg(val id: Long, val address: String, val body: String, val date: Long, val type: Int, val read: Boolean, val subId: Int)
data class SmsThread(val key: String, val address: String, val last: SmsMsg, val unread: Int, val count: Int)
data class SimInfo(val slot: Int, val label: String, val subId: Int, val handle: PhoneAccountHandle?)
data class BlockedItem(val key: String, val label: String, val calls: Boolean, val sms: Boolean)
data class BlockEvent(val kind: String, val key: String, val text: String, val time: Long)

/** Contacts, call log, SMS, SIMs and the block list. */
object PhoneRepo {
    var version by mutableIntStateOf(0)
    fun bump() { version++ }

    val blocked = mutableStateListOf<BlockedItem>()
    val blockLog = mutableStateListOf<BlockEvent>()
    @Volatile var contacts: List<PhoneContact> = emptyList()
    @Volatile var names: Map<String, String> = emptyMap()
    private var inited = false
    private val main = Handler(Looper.getMainLooper())

    fun prefs(ctx: Context) = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    fun has(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        try {
            val a = JSONArray(prefs(ctx).getString("blocked", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                blocked.add(BlockedItem(o.getString("k"), o.optString("l"), o.optBoolean("c", true), o.optBoolean("s", true)))
            }
            val b = JSONArray(prefs(ctx).getString("blocklog", "[]") ?: "[]")
            for (i in 0 until b.length()) {
                val o = b.getJSONObject(i)
                blockLog.add(BlockEvent(o.getString("t"), o.getString("k"), o.optString("x"), o.getLong("d")))
            }
        } catch (_: Exception) {}
    }

    // ---------------- numbers ----------------

    fun ascii(s: String): String = buildString {
        for (c in s) append(when (c) { in '۰'..'۹' -> '0' + (c - '۰'); in '٠'..'٩' -> '0' + (c - '٠'); else -> c })
    }

    fun norm(n: String): String {
        val d = ascii(n).filter { it in '0'..'9' }
        return if (d.length > 10) d.takeLast(10) else d
    }

    fun keyOf(addr: String): String = norm(addr).ifEmpty { addr.trim().lowercase() }

    fun nameFor(number: String): String? = names[keyOf(number)]

    fun t9(s: String): String = buildString {
        for (ch in s.lowercase()) append(when (ch) {
            in 'a'..'c' -> '2'; in 'd'..'f' -> '3'; in 'g'..'i' -> '4'; in 'j'..'l' -> '5'
            in 'm'..'o' -> '6'; in 'p'..'s' -> '7'; in 't'..'v' -> '8'; in 'w'..'z' -> '9'
            in '0'..'9' -> ch; else -> ' '
        })
    }

    fun suggest(q: String, limit: Int = 3): List<PhoneContact> {
        if (q.length < 2) return emptyList()
        return contacts.filter { c ->
            c.numbers.any { norm(it).contains(q) || ascii(it).filter { ch -> ch in '0'..'9' }.contains(q) } ||
                t9(c.name).replace(" ", "").contains(q)
        }.take(limit)
    }

    // ---------------- contacts ----------------

    fun loadContacts(ctx: Context): List<PhoneContact> {
        if (!has(ctx, Manifest.permission.READ_CONTACTS)) return emptyList()
        val ids = LinkedHashMap<Long, MutableList<String>>()
        val nm = HashMap<Long, String>()
        val ph = HashMap<Long, String?>()
        val st = HashMap<Long, Boolean>()
        try {
            ctx.contentResolver.query(
                android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf("contact_id", "display_name", "data1", "photo_thumb_uri", "starred"),
                null, null, "display_name COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val num = c.getString(2) ?: continue
                    nm[id] = c.getString(1) ?: num
                    ph[id] = c.getString(3)
                    st[id] = c.getInt(4) == 1
                    val l = ids.getOrPut(id) { mutableListOf() }
                    if (l.none { norm(it) == norm(num) }) l.add(num)
                }
            }
        } catch (_: Exception) {}
        val list = ids.map { (id, nums) -> PhoneContact(id, nm[id] ?: "", nums, ph[id], st[id] == true) }
        contacts = list
        val m = HashMap<String, String>()
        list.forEach { c -> c.numbers.forEach { n -> m[keyOf(n)] = c.name } }
        names = m
        return list
    }

    // ---------------- call log ----------------

    fun loadCalls(ctx: Context, limit: Int = 500): List<CallEntry> {
        if (!has(ctx, Manifest.permission.READ_CALL_LOG)) return emptyList()
        if (names.isEmpty()) loadContacts(ctx)
        val out = ArrayList<CallEntry>()
        try {
            val proj = arrayOf(CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION)
            val cur = if (Build.VERSION.SDK_INT >= 26) {
                ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, proj, Bundle().apply {
                    putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "date DESC")
                    putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
                }, null)
            } else ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, proj, null, null, "date DESC")
            cur?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val number = c.getString(1) ?: ""
                    out.add(CallEntry(c.getLong(0), number, c.getString(2)?.ifBlank { null } ?: nameFor(number),
                        c.getInt(3), c.getLong(4), c.getLong(5)))
                }
            }
        } catch (_: Exception) {}
        return out
    }

    fun deleteCall(ctx: Context, id: Long): Boolean = try {
        ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, "_id=?", arrayOf(id.toString())) > 0
    } catch (_: Exception) { false }

    // ---------------- SMS ----------------

    fun isDefaultSms(ctx: Context) = try { Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName } catch (_: Throwable) { false }
    fun isDefaultDialer(ctx: Context) = try {
        ctx.getSystemService(TelecomManager::class.java).defaultDialerPackage == ctx.packageName
    } catch (_: Throwable) { false }

    fun roleIntent(ctx: Context, sms: Boolean): Intent =
        if (Build.VERSION.SDK_INT >= 29) {
            ctx.getSystemService(RoleManager::class.java)
                .createRequestRoleIntent(if (sms) RoleManager.ROLE_SMS else RoleManager.ROLE_DIALER)
        } else if (sms) {
            Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, ctx.packageName)
        } else {
            Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, ctx.packageName)
        }

    private fun localSms(ctx: Context): MutableList<SmsMsg> {
        val out = mutableListOf<SmsMsg>()
        try {
            val a = JSONArray(prefs(ctx).getString("smslocal", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(SmsMsg(o.getLong("i"), o.getString("a"), o.getString("b"), o.getLong("d"), 2, true, o.optInt("s", -1)))
            }
        } catch (_: Exception) {}
        return out
    }

    /** Messages we sent while not being the default SMS app (the system does not store those). */
    private fun addLocalSms(ctx: Context, m: SmsMsg) {
        val l = localSms(ctx)
        l.add(m)
        val a = JSONArray()
        l.takeLast(500).forEach { a.put(JSONObject().put("i", it.id).put("a", it.address).put("b", it.body).put("d", it.date).put("s", it.subId)) }
        prefs(ctx).edit().putString("smslocal", a.toString()).apply()
    }

    fun loadSms(ctx: Context, limit: Int = 4000): List<SmsMsg> {
        if (!has(ctx, Manifest.permission.READ_SMS)) return emptyList()
        if (names.isEmpty()) loadContacts(ctx)
        val out = ArrayList<SmsMsg>()
        try {
            val proj = arrayOf("_id", "address", "body", "date", "type", "read")
            val cur = if (Build.VERSION.SDK_INT >= 26) {
                ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, proj, Bundle().apply {
                    putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "date DESC")
                    putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
                }, null)
            } else ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, proj, null, null, "date DESC")
            cur?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    out.add(SmsMsg(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3),
                        c.getInt(4), c.getInt(5) == 1, -1))
                }
            }
        } catch (_: Exception) {}
        if (!isDefaultSms(ctx)) out.addAll(localSms(ctx))
        return out.sortedByDescending { it.date }
    }

    fun threads(msgs: List<SmsMsg>): List<SmsThread> {
        val g = LinkedHashMap<String, MutableList<SmsMsg>>()
        msgs.forEach { g.getOrPut(keyOf(it.address)) { mutableListOf() }.add(it) }
        return g.map { (k, l) -> SmsThread(k, l.first().address, l.first(), l.count { it.type == 1 && !it.read }, l.size) }
            .sortedByDescending { it.last.date }
    }

    @Suppress("DEPRECATION")
    private fun smsManager(ctx: Context, subId: Int): SmsManager =
        if (subId >= 0) {
            if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java).createForSubscriptionId(subId)
            else SmsManager.getSmsManagerForSubscriptionId(subId)
        } else if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
        else SmsManager.getDefault()

    fun sendSms(ctx: Context, to: String, body: String, subId: Int): Boolean {
        if (!has(ctx, Manifest.permission.SEND_SMS) || to.isBlank() || body.isBlank()) return false
        return try {
            val sm = smsManager(ctx, subId)
            val parts = sm.divideMessage(body)
            if (parts.size > 1) sm.sendMultipartTextMessage(to, null, parts, null, null)
            else sm.sendTextMessage(to, null, body, null, null)
            val now = System.currentTimeMillis()
            if (isDefaultSms(ctx)) {
                try {
                    val v = ContentValues()
                    v.put("address", to); v.put("body", body); v.put("date", now); v.put("read", 1); v.put("type", 2)
                    ctx.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, v)
                } catch (_: Exception) {}
            } else addLocalSms(ctx, SmsMsg(-now, to, body, now, 2, true, subId))
            bump()
            true
        } catch (_: Throwable) { false }
    }

    fun markRead(ctx: Context, key: String) {
        if (!isDefaultSms(ctx)) return
        try {
            loadSms(ctx).filter { keyOf(it.address) == key && it.type == 1 && !it.read }.forEach {
                val v = ContentValues(); v.put("read", 1)
                ctx.contentResolver.update(Uri.parse("content://sms/${it.id}"), v, null, null)
            }
        } catch (_: Exception) {}
    }

    fun deleteSms(ctx: Context, id: Long): Boolean = try {
        if (id < 0) {
            val l = localSms(ctx).filter { it.id != id }
            val a = JSONArray()
            l.forEach { a.put(JSONObject().put("i", it.id).put("a", it.address).put("b", it.body).put("d", it.date).put("s", it.subId)) }
            prefs(ctx).edit().putString("smslocal", a.toString()).apply()
            true
        } else ctx.contentResolver.delete(Uri.parse("content://sms/$id"), null, null) > 0
    } catch (_: Exception) { false }

    fun deleteThread(ctx: Context, key: String) {
        loadSms(ctx).filter { keyOf(it.address) == key }.forEach { deleteSms(ctx, it.id) }
        bump()
    }

    // ---------------- SIMs and calling ----------------

    fun sims(ctx: Context): List<SimInfo> {
        if (!has(ctx, Manifest.permission.READ_PHONE_STATE)) return emptyList()
        return try {
            val sm = ctx.getSystemService(SubscriptionManager::class.java)
            val subs = (sm.activeSubscriptionInfoList ?: emptyList()).sortedBy { it.simSlotIndex }
            val tm = ctx.getSystemService(TelecomManager::class.java)
            val handles: List<PhoneAccountHandle> = try { tm.callCapablePhoneAccounts } catch (_: Throwable) { emptyList() }
            subs.mapIndexed { i, s ->
                val icc = try { s.iccId } catch (_: Throwable) { null }
                val h = handles.firstOrNull { it.id == s.subscriptionId.toString() }
                    ?: handles.firstOrNull { icc != null && icc.isNotEmpty() && it.id.contains(icc) }
                    ?: handles.getOrNull(i)
                SimInfo(s.simSlotIndex, "SIM ${s.simSlotIndex + 1} · ${s.displayName ?: ""}", s.subscriptionId, h)
            }
        } catch (_: Throwable) { emptyList() }
    }

    fun placeCall(ctx: Context, number: String, sim: SimInfo?): Boolean {
        if (!has(ctx, Manifest.permission.CALL_PHONE)) return false
        return try {
            val extras = Bundle()
            sim?.handle?.let { extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it) }
            ctx.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", number, null), extras)
            true
        } catch (_: Throwable) { false }
    }

    private fun rules(ctx: Context): JSONObject =
        try { JSONObject(prefs(ctx).getString("simrules", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }

    fun simRule(ctx: Context, number: String): Int = rules(ctx).optInt(keyOf(number), -1)

    fun setSimRule(ctx: Context, number: String, slot: Int) {
        val r = rules(ctx)
        if (slot < 0) r.remove(keyOf(number)) else r.put(keyOf(number), slot)
        prefs(ctx).edit().putString("simrules", r.toString()).apply()
    }

    // ---------------- blocking ----------------

    private fun saveBlocked(ctx: Context) {
        val a = JSONArray()
        blocked.forEach { a.put(JSONObject().put("k", it.key).put("l", it.label).put("c", it.calls).put("s", it.sms)) }
        prefs(ctx).edit().putString("blocked", a.toString()).apply()
    }

    fun isBlockedKey(key: String, sms: Boolean) = blocked.any { it.key == key && (if (sms) it.sms else it.calls) }

    fun block(ctx: Context, number: String, calls: Boolean = true, sms: Boolean = true) {
        val k = keyOf(number)
        val label = nameFor(number) ?: number
        val i = blocked.indexOfFirst { it.key == k }
        val item = BlockedItem(k, label, calls, sms)
        if (i < 0) blocked.add(item) else blocked[i] = item
        saveBlocked(ctx)
        bump()
    }

    fun unblock(ctx: Context, key: String) {
        blocked.removeAll { it.key == key }
        saveBlocked(ctx)
        bump()
    }

    fun update(ctx: Context, item: BlockedItem) {
        val i = blocked.indexOfFirst { it.key == item.key }
        if (i >= 0) blocked[i] = item
        saveBlocked(ctx)
    }

    private fun unknownRule(ctx: Context, number: String, sms: Boolean): Boolean {
        val p = prefs(ctx)
        if (!p.getBoolean("blk_unknown", false) || !has(ctx, Manifest.permission.READ_CONTACTS)) return false
        if (number.none { it.isDigit() }) return false
        if (names.isEmpty()) loadContacts(ctx)
        return names[keyOf(number)] == null
    }

    fun isBlockedCall(ctx: Context, number: String): Boolean {
        if (number.isBlank()) return prefs(ctx).getBoolean("blk_private", false)
        return isBlockedKey(keyOf(number), false) || unknownRule(ctx, number, false)
    }

    fun isBlockedSms(ctx: Context, address: String): Boolean =
        isBlockedKey(keyOf(address), true) || unknownRule(ctx, address, true)

    fun logBlock(ctx: Context, kind: String, number: String, text: String) {
        main.post {
            blockLog.add(0, BlockEvent(kind, number, text, System.currentTimeMillis()))
            while (blockLog.size > 200) blockLog.removeAt(blockLog.size - 1)
            val a = JSONArray()
            blockLog.forEach { a.put(JSONObject().put("t", it.kind).put("k", it.key).put("x", it.text).put("d", it.time)) }
            prefs(ctx).edit().putString("blocklog", a.toString()).apply()
        }
    }

    // ---------------- notifications ----------------

    fun notifySms(ctx: Context, address: String, body: String) {
        val net = (ctx.applicationContext as App).net
        if (!net.notifOn) return
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val key = keyOf(address)
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("sms_key", key).putExtra("sms_addr", address)
        val pi = PendingIntent.getActivity(ctx, key.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, Net.CH_SMS).setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(nameFor(address) ?: address).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body)).setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(pi).build()
        try { nm.notify(("sms" + key).hashCode(), n) } catch (_: SecurityException) {}
    }
}

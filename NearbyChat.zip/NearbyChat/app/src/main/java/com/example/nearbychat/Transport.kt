package com.example.nearbychat

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.DataInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketAddress
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

/** A device seen by Wi-Fi beacon ("wifi") or Bluetooth scan ("bt"). */
data class Seen(val kind: String, val key: String, val userId: String, val name: String, val addr: String, val port: Int)

/**
 * One open connection (Bluetooth RFCOMM or TCP over Wi-Fi). Frames: [type:1][length:4][payload].
 * 1 = JSON, 2 = file chunk (pid:8 + data), 3 = file end (pid:8), 6 = audio, 7 = ping.
 * Control frames always go before file chunks, so chat stays responsive during transfers.
 */
class Link(
    val id: String,
    val kind: String,
    val addr: String,
    val outbound: Boolean,
    private val ins: InputStream,
    private val outs: OutputStream,
    private val closer: () -> Unit
) {
    @Volatile var open = true
    @Volatile var lastRx = System.currentTimeMillis()
    @Volatile var established = false
    var userId: String? = null
    var name: String = ""
    var accepted = false
    var peerAccepted = false
    var onFrame: ((Link, Int, ByteArray) -> Unit)? = null
    var onClose: ((Link) -> Unit)? = null
    val rxOut = ConcurrentHashMap<Long, OutputStream>()
    val rxFile = ConcurrentHashMap<Long, File>()

    private class Frame(val prio: Int, val seq: Long, val data: ByteArray, val chunk: Boolean) : Comparable<Frame> {
        override fun compareTo(other: Frame): Int =
            if (prio != other.prio) prio.compareTo(other.prio) else seq.compareTo(other.seq)
    }

    private val q = PriorityBlockingQueue<Frame>()
    private val seq = AtomicLong()
    private val credits = Semaphore(6)

    private fun plain(type: Int, p: ByteArray, len: Int = p.size): ByteArray {
        val b = ByteBuffer.allocate(5 + len)
        b.put(type.toByte())
        b.putInt(len)
        b.put(p, 0, len)
        return b.array()
    }

    private fun withPid(type: Int, pid: Long, p: ByteArray?, n: Int): ByteArray {
        val b = ByteBuffer.allocate(5 + 8 + n)
        b.put(type.toByte())
        b.putInt(8 + n)
        b.putLong(pid)
        if (p != null && n > 0) b.put(p, 0, n)
        return b.array()
    }

    private fun put(f: Frame) { if (open) q.add(f) }

    fun sendJson(j: JSONObject) = put(Frame(0, seq.incrementAndGet(), plain(1, j.toString().toByteArray(Charsets.UTF_8)), false))
    fun ping() = put(Frame(0, seq.incrementAndGet(), plain(7, ByteArray(0)), false))

    fun sendAudio(b: ByteArray, n: Int) {
        if (q.size < 40) put(Frame(0, seq.incrementAndGet(), plain(6, b, n), false))
    }

    private fun sendChunk(pid: Long, data: ByteArray, n: Int): Boolean {
        while (open) { if (credits.tryAcquire(200, TimeUnit.MILLISECONDS)) break }
        if (!open) return false
        put(Frame(1, seq.incrementAndGet(), withPid(2, pid, data, n), true))
        return true
    }

    private fun sendEnd(pid: Long) = put(Frame(1, seq.incrementAndGet(), withPid(3, pid, null, 0), false))

    /** Streams a file in the background (the JSON "meta" frame must be sent before). */
    fun sendFile(pid: Long, file: File) {
        thread(name = "link-file") {
            try {
                file.inputStream().use { fi ->
                    val buf = ByteArray(16 * 1024)
                    while (open) {
                        val n = fi.read(buf)
                        if (n < 0) break
                        if (!sendChunk(pid, buf, n)) return@thread
                    }
                }
                sendEnd(pid)
            } catch (_: Exception) {}
        }
    }

    fun start() {
        thread(name = "link-w") {
            try {
                while (open) {
                    val f = q.take()
                    if (!open) break
                    outs.write(f.data)
                    outs.flush()
                    if (f.chunk) credits.release()
                }
            } catch (_: Exception) {
            } finally { close() }
        }
        thread(name = "link-r") {
            try {
                val din = DataInputStream(ins)
                while (open) {
                    val type = din.readUnsignedByte()
                    val len = din.readInt()
                    if (len < 0 || len > 4_000_000) throw IOException("bad frame")
                    val buf = ByteArray(len)
                    din.readFully(buf)
                    lastRx = System.currentTimeMillis()
                    onFrame?.invoke(this, type, buf)
                }
            } catch (_: Exception) {
            } finally { close() }
        }
    }

    @Synchronized
    fun close() {
        if (!open) return
        open = false
        try { closer() } catch (_: Exception) {}
        q.add(Frame(-1, 0, ByteArray(0), false))
        credits.release(8)
        rxOut.values.forEach { try { it.close() } catch (_: Exception) {} }
        rxFile.values.forEach { try { it.delete() } catch (_: Exception) {} }
        rxOut.clear()
        rxFile.clear()
        onClose?.invoke(this)
    }
}

/**
 * Our own transport, no Google services. Wi-Fi: UDP beacons on the local network + TCP.
 * Bluetooth: classic RFCOMM server/client. Nothing here ever switches a radio on.
 */
class Transport(private val ctx: Context, private val cb: Callbacks) {
    interface Callbacks {
        fun onNewLink(link: Link)
        fun onSeen(s: Seen)
        fun onConnectFailed(key: String)
    }

    companion object {
        private const val BEACON_PORT = 47855
        private val BT_UUID: UUID = UUID.fromString("7a3c6b0e-5b1a-4d8e-9a53-4e6561726279")
        private val IFACES = listOf("wlan", "ap", "swlan", "softap", "p2p", "eth")
    }

    var myId = ""
    var myName = ""
    @Volatile var useWifi = true
    @Volatile var useBt = true
    @Volatile private var running = false
    private val linkSeq = AtomicLong()

    fun start() {
        if (running) return
        running = true
        if (useBt) startBt()
        if (useWifi) startWifi()
    }

    fun stop() {
        running = false
        stopWifi()
        stopBtServer()
    }

    fun refresh() {
        if (!running) return
        if (useBt) { if (btOn()) startBt() else stopBtServer() }
    }

    fun applyMode() {
        if (!running) return
        if (useBt) startBt() else stopBtServer()
        if (useWifi) startWifi() else stopWifi()
    }

    // ---------------- Wi-Fi ----------------

    private var tcp: ServerSocket? = null
    private var udp: DatagramSocket? = null
    private var lock: WifiManager.MulticastLock? = null

    private fun startWifi() {
        if (tcp != null) return
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            lock = wm.createMulticastLock("nearbychat").apply { setReferenceCounted(false); acquire() }
        } catch (_: Throwable) {}
        try {
            val ss = ServerSocket(0)
            tcp = ss
            thread(name = "wifi-accept") {
                while (running && !ss.isClosed) {
                    try {
                        val s = ss.accept()
                        s.tcpNoDelay = true
                        s.keepAlive = true
                        newWifiLink(s, false)
                    } catch (_: Exception) { if (ss.isClosed) break }
                }
            }
            val us = DatagramSocket(null as SocketAddress?)
            us.reuseAddress = true
            us.bind(InetSocketAddress(BEACON_PORT))
            us.broadcast = true
            udp = us
            thread(name = "wifi-rx") {
                val buf = ByteArray(512)
                while (running && !us.isClosed) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        us.receive(p)
                        handleBeacon(p)
                    } catch (_: Exception) { if (us.isClosed) break }
                }
            }
            thread(name = "wifi-tx") {
                while (running && !us.isClosed) {
                    sendBeacon(us, ss.localPort)
                    try { Thread.sleep(4000) } catch (_: InterruptedException) { break }
                }
            }
        } catch (_: Exception) {
            stopWifi()
        }
    }

    private fun stopWifi() {
        try { tcp?.close() } catch (_: Exception) {}
        try { udp?.close() } catch (_: Exception) {}
        tcp = null
        udp = null
        try { lock?.release() } catch (_: Exception) {}
        lock = null
    }

    private fun sendBeacon(us: DatagramSocket, port: Int) {
        val data = "NC1|$myId|${myName.replace('|', ' ').take(24)}|$port".toByteArray(Charsets.UTF_8)
        val targets = mutableSetOf<InetAddress>()
        try {
            for (ni in java.util.Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                if (IFACES.none { ni.name.startsWith(it) }) continue
                for (ia in ni.interfaceAddresses) ia.broadcast?.let { targets.add(it) }
            }
        } catch (_: Exception) {}
        for (t in targets) try { us.send(DatagramPacket(data, data.size, t, BEACON_PORT)) } catch (_: Exception) {}
    }

    private fun handleBeacon(p: DatagramPacket) {
        val s = String(p.data, 0, p.length, Charsets.UTF_8)
        val parts = s.split("|", limit = 4)
        if (parts.size < 4 || parts[0] != "NC1") return
        val uid = parts[1]
        if (uid == myId || uid.isEmpty()) return
        val port = parts[3].trim().toIntOrNull() ?: return
        val ip = p.address?.hostAddress ?: return
        cb.onSeen(Seen("wifi", "wifi:$uid", uid, parts[2], ip, port))
    }

    private fun newWifiLink(s: Socket, outbound: Boolean) {
        val ip = s.inetAddress?.hostAddress ?: "?"
        val l = Link("wifi:$ip:${s.port}#${linkSeq.incrementAndGet()}", "wifi", ip, outbound,
            s.getInputStream(), s.getOutputStream()) { try { s.close() } catch (_: Exception) {} }
        cb.onNewLink(l)
    }

    fun connectWifi(key: String, ip: String, port: Int) {
        thread(name = "wifi-connect") {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(ip, port), 5000)
                s.tcpNoDelay = true
                s.keepAlive = true
                newWifiLink(s, true)
            } catch (_: Exception) {
                cb.onConnectFailed(key)
            }
        }
    }

    // ---------------- Bluetooth ----------------

    private var btServer: BluetoothServerSocket? = null
    private var discRecv: BroadcastReceiver? = null
    private val btExec = Executors.newSingleThreadExecutor()

    private val adapter: BluetoothAdapter?
        get() = try { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter } catch (_: Throwable) { null }

    @SuppressLint("MissingPermission")
    fun btOn(): Boolean = try { adapter?.isEnabled == true } catch (_: Throwable) { false }

    private fun btPerm(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun startBt() {
        if (btServer != null || !btOn() || !btPerm()) return
        try {
            val ss = adapter!!.listenUsingInsecureRfcommWithServiceRecord("NearbyChat", BT_UUID)
            btServer = ss
            thread(name = "bt-accept") {
                while (running && btServer === ss) {
                    try {
                        val s = ss.accept()
                        newBtLink(s, false)
                    } catch (_: Exception) { break }
                }
                if (btServer === ss) { try { ss.close() } catch (_: Exception) {}; btServer = null }
            }
        } catch (_: Throwable) {
            btServer = null
        }
    }

    private fun stopBtServer() {
        try { btServer?.close() } catch (_: Exception) {}
        btServer = null
        discRecv?.let { try { ctx.unregisterReceiver(it) } catch (_: Exception) {} }
        discRecv = null
    }

    @SuppressLint("MissingPermission")
    private fun newBtLink(s: BluetoothSocket, outbound: Boolean) {
        val mac = try { s.remoteDevice.address } catch (_: Throwable) { "?" }
        val l = Link("bt:$mac#${linkSeq.incrementAndGet()}", "bt", mac, outbound,
            s.inputStream, s.outputStream) { try { s.close() } catch (_: Exception) {} }
        cb.onNewLink(l)
    }

    @SuppressLint("MissingPermission")
    fun connectBt(mac: String) {
        if (!useBt || !btOn() || !btPerm()) { cb.onConnectFailed("bt:$mac"); return }
        btExec.execute {
            var ok = false
            try {
                val ad = adapter
                if (ad != null) {
                    try { ad.cancelDiscovery() } catch (_: Throwable) {}
                    val s = ad.getRemoteDevice(mac).createInsecureRfcommSocketToServiceRecord(BT_UUID)
                    try {
                        s.connect()
                        ok = true
                        newBtLink(s, true)
                    } catch (_: Exception) {
                        try { s.close() } catch (_: Exception) {}
                    }
                }
            } catch (_: Throwable) {}
            if (!ok) cb.onConnectFailed("bt:$mac")
        }
    }

    @SuppressLint("MissingPermission")
    private fun reportBt(d: BluetoothDevice) {
        val cls = try { d.bluetoothClass?.majorDeviceClass } catch (_: Throwable) { null }
        if (cls != null && cls != BluetoothClass.Device.Major.PHONE &&
            cls != BluetoothClass.Device.Major.COMPUTER && cls != BluetoothClass.Device.Major.UNCATEGORIZED
        ) return
        val name = (try { d.name } catch (_: Throwable) { null }) ?: d.address
        cb.onSeen(Seen("bt", "bt:${d.address}", "", name, d.address, 0))
    }

    @Suppress("DEPRECATION")
    private fun deviceOf(i: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    /** User-initiated: lists paired phones and scans for visible ones. */
    @SuppressLint("MissingPermission")
    fun scanBluetooth() {
        if (!useBt || !btOn() || !btPerm()) return
        try {
            val ad = adapter ?: return
            ad.bondedDevices?.forEach { reportBt(it) }
            if (discRecv == null) {
                val r = object : BroadcastReceiver() {
                    override fun onReceive(c: Context?, i: Intent?) {
                        val intent = i ?: return
                        if (intent.action == BluetoothDevice.ACTION_FOUND) deviceOf(intent)?.let { reportBt(it) }
                    }
                }
                ContextCompat.registerReceiver(ctx, r, IntentFilter(BluetoothDevice.ACTION_FOUND), ContextCompat.RECEIVER_EXPORTED)
                discRecv = r
            }
            if (!ad.isDiscovering) ad.startDiscovery()
        } catch (_: Throwable) {}
    }
}

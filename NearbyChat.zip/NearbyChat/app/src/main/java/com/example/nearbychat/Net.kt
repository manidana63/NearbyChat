package com.example.nearbychat

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.util.Base64
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Collections
import java.util.UUID
import kotlin.concurrent.thread

data class Found(val ep: String, val userId: String, val name: String)
enum class CallState { IDLE, OUTGOING, INCOMING, ACTIVE }

/**
 * Networking + data. Uses Google Nearby Connections (Bluetooth / BLE / Wi-Fi LAN / Wi-Fi Direct,
 * chosen automatically, no internet needed). Lives in the Application so it keeps running
 * while the foreground service is alive.
 */
class Net(private val app: Context) {
    companion object {
        const val CH_MSG = "messages"
        const val CH_CALL = "calls"
        const val CH_SERVICE = "service"
    }

    val store = Store(app)
    private val prefs = store.prefs
    private val client: ConnectionsClient = Nearby.getConnectionsClient(app)
    private val main = Handler(Looper.getMainLooper())
    private val serviceId = "com.example.nearbychat.v2"
    private val strategy = Strategy.P2P_CLUSTER
    private val rate = 16000

    // ---- settings / profile (observable) ----
    val myId: String = prefs.getString("uid", null)
        ?: UUID.randomUUID().toString().take(8).also { prefs.edit().putString("uid", it).apply() }
    var myName by mutableStateOf(prefs.getString("name", "") ?: "")
    var avatarVersion by mutableIntStateOf(0)
    var theme by mutableIntStateOf(prefs.getInt("theme", 0))      // 0 system, 1 light, 2 dark
    var accent by mutableIntStateOf(prefs.getInt("accent", 0))
    var notifOn by mutableStateOf(prefs.getBoolean("notif", true))
    var bgService by mutableStateOf(prefs.getBoolean("bg", true))
    var calendar by mutableIntStateOf(prefs.getInt("cal", if (java.util.Locale.getDefault().language == "fa") 1 else 0)) // 0 Gregorian, 1 Jalali

    fun changeTheme(v: Int) { theme = v; prefs.edit().putInt("theme", v).apply() }
    fun changeAccent(v: Int) { accent = v; prefs.edit().putInt("accent", v).apply() }
    fun setNotif(v: Boolean) { notifOn = v; prefs.edit().putBoolean("notif", v).apply() }
    fun setBg(v: Boolean) { bgService = v; prefs.edit().putBoolean("bg", v).apply() }
    fun changeCalendar(v: Int) { calendar = v; prefs.edit().putInt("cal", v).apply() }

    fun saveName(n: String) {
        myName = n.trim()
        prefs.edit().putString("name", myName).apply()
        if (running) { client.stopAdvertising(); advertise() }
    }

    // ---- observable data ----
    var running by mutableStateOf(false)
    var appVisible = false
    var activeChat: String? = null
    var openRequest by mutableStateOf<String?>(null)

    val contacts = mutableStateListOf<Contact>()
    val groups = mutableStateListOf<Group>()
    val online = mutableStateListOf<String>()
    val nearby = mutableStateListOf<Found>()
    val requests = mutableStateListOf<Found>()
    val chats = mutableStateMapOf<String, SnapshotStateList<Msg>>()
    val unread = mutableStateMapOf<String, Int>()
    val lastSeen = mutableStateMapOf<String, Long>()
    var callState by mutableStateOf(CallState.IDLE)
    var callPeer by mutableStateOf<String?>(null)

    private val epInfo = mutableMapOf<String, Found>()
    private val epToUser = mutableMapOf<String, String>()
    private val userToEp = mutableMapOf<String, String>()
    private val outgoing = mutableSetOf<String>()
    private val requesting = mutableSetOf<String>()
    private val fileMeta = mutableMapOf<Long, JSONObject>()
    private val filePayloads = mutableMapOf<Long, Payload>()
    private val seen: MutableSet<String> = Collections.newSetFromMap(
        object : LinkedHashMap<String, Boolean>() {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?) = size > 2000
        }
    )

    init {
        contacts.addAll(store.loadContacts())
        contacts.forEach { c -> prefs.getLong("ls_${c.id}", 0L).let { if (it > 0) lastSeen[c.id] = it } }
        groups.addAll(store.loadGroups())
        store.chatIds().forEach { id ->
            val l = mutableStateListOf<Msg>()
            val msgs = store.loadChat(id)
            l.addAll(msgs)
            msgs.forEach { seen.add(it.id) }
            chats[id] = l
            val u = prefs.getInt("u_$id", 0)
            if (u > 0) unread[id] = u
        }
        createChannels()
    }

    fun isGroup(conv: String) = conv.startsWith("g_")
    fun title(conv: String): String =
        if (isGroup(conv)) groups.find { it.id == conv }?.name ?: conv
        else contacts.find { it.id == conv }?.name ?: epInfo.values.find { it.userId == conv }?.name ?: conv

    private fun userOf(ep: String) = epToUser[ep] ?: epInfo[ep]?.userId
    private fun toast(r: Int) = Toast.makeText(app, app.getString(r), Toast.LENGTH_SHORT).show()

    // ---------- start / stop ----------

    fun startIfReady() {
        if (myName.isNotBlank()) start()
    }

    fun start() {
        if (running || myName.isBlank()) return
        running = true
        advertise()
        discover()
        main.postDelayed(refresher, 45_000)
    }

    private val refresher = object : Runnable {
        override fun run() {
            if (!running) return
            client.stopDiscovery()
            discover()
            main.postDelayed(this, 45_000)
        }
    }

    private fun advertise() {
        client.startAdvertising(
            "$myId|${myName.take(24)}", serviceId, connCb,
            AdvertisingOptions.Builder().setStrategy(strategy).build()
        )
    }

    private fun discover() {
        client.startDiscovery(
            serviceId, discCb,
            DiscoveryOptions.Builder().setStrategy(strategy).build()
        )
    }

    // ---------- connections ----------

    fun connect(f: Found) {
        if (userToEp.containsKey(f.userId) || !requesting.add(f.ep)) return
        outgoing.add(f.ep)
        client.requestConnection("$myId|${myName.take(24)}", f.ep, connCb)
            .addOnFailureListener { requesting.remove(f.ep); outgoing.remove(f.ep) }
    }

    fun acceptRequest(f: Found) {
        requests.remove(f)
        client.acceptConnection(f.ep, payloadCb)
    }

    fun rejectRequest(f: Found) {
        requests.remove(f)
        client.rejectConnection(f.ep)
    }

    private fun parse(ep: String, raw: String): Found? {
        val i = raw.indexOf('|')
        if (i < 1) return null
        return Found(ep, raw.substring(0, i), raw.substring(i + 1).ifBlank { raw.substring(0, i) })
    }

    private val discCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(ep: String, info: DiscoveredEndpointInfo) {
            val f = parse(ep, info.endpointName) ?: return
            if (f.userId == myId || userToEp.containsKey(f.userId)) return
            if (nearby.none { it.ep == ep }) nearby.add(f)
            if (contacts.any { it.id == f.userId }) {
                // known contact: reconnect automatically (one side immediately, the other as a fallback)
                val delay = if (myId < f.userId) 500L else 15_000L
                main.postDelayed({
                    if (running && !userToEp.containsKey(f.userId) && nearby.any { it.ep == ep }) connect(f)
                }, delay)
            }
        }

        override fun onEndpointLost(ep: String) {
            nearby.removeAll { it.ep == ep }
        }
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(ep: String, info: ConnectionInfo) {
            val f = parse(ep, info.endpointName)
            if (f == null) { client.rejectConnection(ep); return }
            epInfo[ep] = f
            if (ep in outgoing || contacts.any { it.id == f.userId }) {
                client.acceptConnection(ep, payloadCb)
            } else if (requests.none { it.ep == ep }) {
                requests.add(f)
            }
        }

        override fun onConnectionResult(ep: String, result: ConnectionResolution) {
            requesting.remove(ep)
            outgoing.remove(ep)
            requests.removeAll { it.ep == ep }
            val f = epInfo[ep] ?: return
            if (!result.status.isSuccess) return
            epToUser[ep] = f.userId
            userToEp[f.userId] = ep
            if (!online.contains(f.userId)) online.add(f.userId)
            nearby.removeAll { it.userId == f.userId }
            val idx = contacts.indexOfFirst { it.id == f.userId }
            if (idx < 0) contacts.add(Contact(f.userId, f.name))
            else if (contacts[idx].name != f.name) contacts[idx] = Contact(f.userId, f.name)
            store.saveContacts(contacts.toList())
            chats.getOrPut(f.userId) { mutableStateListOf() }
            sendAvatar(ep)
            groups.filter { g -> g.members.any { it.id == f.userId } }.forEach { sendGroupInfo(it, listOf(ep)) }
            flushPending(f.userId, ep)
            flushReceipts(f.userId)
            sendTombs(f.userId, ep)
            stamp(f.userId, true)
        }

        override fun onDisconnected(ep: String) {
            val uid = epToUser.remove(ep) ?: return
            userToEp.remove(uid)
            online.remove(uid)
            stamp(uid, true)
            if (callPeer == uid) endCall(notify = false)
            main.postDelayed({ if (running) { client.stopDiscovery(); discover() } }, 3000)
        }
    }

    // ---------- payloads ----------

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(ep: String, p: Payload) {
            when (p.type) {
                Payload.Type.BYTES -> try {
                    handleJson(ep, JSONObject(String(p.asBytes() ?: return, Charsets.UTF_8)))
                } catch (_: Exception) {}
                Payload.Type.FILE -> filePayloads[p.id] = p
                Payload.Type.STREAM -> { incoming = p; tryPlay() }
            }
        }

        override fun onPayloadTransferUpdate(ep: String, u: PayloadTransferUpdate) {
            if (u.status == PayloadTransferUpdate.Status.SUCCESS) {
                filePayloads.remove(u.payloadId)?.let { saveReceivedFile(ep, it) }
            }
        }
    }

    private fun handleJson(ep: String, j: JSONObject) {
        userOf(ep)?.let { stamp(it, false) }
        when (j.getString("t")) {
            "m" -> onMessage(ep, j)
            "f" -> fileMeta[j.getLong("pid")] = j
            "r" -> onReceipt(ep, j)
            "gd" -> onGroupDelete(ep, j)
            "g" -> onGroup(j)
            "a" -> onAvatar(j)
            "c" -> handleCall(ep, j.getString("k"))
        }
    }

    private fun send(eps: List<String>, j: JSONObject) {
        if (eps.isNotEmpty()) client.sendPayload(eps, Payload.fromBytes(j.toString().toByteArray(Charsets.UTF_8)))
    }

    private fun addMsg(conv: String, m: Msg) {
        val list = chats.getOrPut(conv) { mutableStateListOf() }
        list.add(m)
        store.saveChat(conv, list.toList())
        if (!m.mine) {
            if (appVisible && activeChat == conv) {
                markRead(conv)
            } else {
                unread[conv] = (unread[conv] ?: 0) + 1
                prefs.edit().putInt("u_$conv", unread[conv] ?: 0).apply()
                notifyMessage(conv, m)
            }
        }
    }

    /** Called when the user is actually looking at this chat. */
    fun markRead(conv: String) {
        if (!appVisible) return
        unread.remove(conv)
        prefs.edit().remove("u_$conv").apply()
        NotificationManagerCompat.from(app).cancel(conv.hashCode())
        val l = chats[conv]
        if (l != null) {
            var ch = false
            for (i in l.indices) if (!l[i].mine && l[i].st == 0) { l[i] = l[i].copy(st = 1); ch = true }
            if (ch) store.saveChat(conv, l.toList())
        }
        flushReceipts(conv)
    }

    private fun msgJson(m: Msg, conv: String): JSONObject {
        val j = JSONObject().put("t", "m").put("id", m.id).put("s", myId).put("n", myName).put("x", m.text ?: "")
        if (m.lst != null) j.put("l", m.lst)
        if (isGroup(conv)) j.put("c", conv)
        return j
    }

    private fun targetsFor(conv: String): List<String> =
        if (isGroup(conv)) groups.find { it.id == conv }?.members?.filter { it.id != myId }
            ?.mapNotNull { userToEp[it.id] } ?: emptyList()
        else listOfNotNull(userToEp[conv])

    fun canSendNow(conv: String) = targetsFor(conv).isNotEmpty()

    private fun flushPending(uid: String, ep: String) {
        val list = chats[uid] ?: return
        var changed = false
        for (i in list.indices) {
            val m = list[i]
            if (m.mine && m.pending) {
                send(listOf(ep), msgJson(m, uid))
                list[i] = m.copy(st = 1)
                changed = true
            }
        }
        if (changed) store.saveChat(uid, list.toList())
    }

    private fun onMessage(ep: String, j: JSONObject) {
        val id = j.getString("id")
        if (!seen.add(id)) return
        val s = j.getString("s")
        val c = j.optString("c", "")
        val group = c.isNotEmpty()
        if (group && groups.none { it.id == c }) return
        addMsg(if (group) c else s, Msg(id, s, j.optString("n"), false,
            text = j.optString("x").ifEmpty { null }, lst = j.optString("l").ifEmpty { null }))
        if (group) { // relay so members that are not directly connected to the sender still get it
            val g = groups.first { it.id == c }
            val targets = g.members.mapNotNull { userToEp[it.id] }.filter { it != ep && userOf(it) != s }
            send(targets, j)
        }
    }

    // ---------- files ----------

    fun displayName(uri: Uri): String {
        var name = "file"
        try {
            app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
            }
        } catch (_: Exception) {}
        return name
    }

    fun sendFile(conv: String, uri: Uri) {
        if (!canSendNow(conv)) { toast(R.string.offline); return }
        val name = displayName(uri)
        thread {
            try {
                val dest = File(store.filesDir, "${System.currentTimeMillis()}_${name.replace('/', '_')}")
                app.contentResolver.openInputStream(uri)?.use { i -> dest.outputStream().use { i.copyTo(it) } }
                main.post { dispatchFile(conv, dest, name) }
            } catch (_: Exception) {
                main.post { toast(R.string.connect_failed) }
            }
        }
    }

    private fun dispatchFile(conv: String, file: File, name: String) {
        val eps = targetsFor(conv)
        if (eps.isEmpty()) { toast(R.string.offline); return }
        try {
            val payload = Payload.fromFile(file)
            val m = Msg(UUID.randomUUID().toString(), myId, myName, true, fileName = name, filePath = file.absolutePath, st = 1)
            val meta = JSONObject().put("t", "f").put("pid", payload.id).put("id", m.id)
                .put("s", myId).put("n", myName).put("name", name)
            if (isGroup(conv)) meta.put("c", conv)
            send(eps, meta)
            client.sendPayload(eps, payload)
            seen.add(m.id)
            addMsg(conv, m)
        } catch (_: Exception) {
            toast(R.string.connect_failed)
        }
    }

    private fun saveReceivedFile(ep: String, p: Payload) {
        val meta = fileMeta.remove(p.id)
        val name = (meta?.optString("name") ?: "file_${p.id}").replace('/', '_')
        val dest = File(store.filesDir, "${System.currentTimeMillis()}_$name")
        thread {
            try {
                val pfd = p.asFile()?.asParcelFileDescriptor() ?: return@thread
                ParcelFileDescriptor.AutoCloseInputStream(pfd).use { i -> dest.outputStream().use { i.copyTo(it) } }
                main.post {
                    val s = meta?.optString("s")?.ifEmpty { null } ?: userOf(ep) ?: return@post
                    val c = meta?.optString("c", "") ?: ""
                    val id = meta?.optString("id")?.ifEmpty { null } ?: UUID.randomUUID().toString()
                    if (!seen.add(id)) return@post
                    addMsg(if (c.isNotEmpty()) c else s,
                        Msg(id, s, meta?.optString("n") ?: "", false, fileName = name, filePath = dest.absolutePath))
                }
            } catch (_: Exception) {}
        }
    }

    // ---------- groups ----------

    fun createGroup(name: String, memberIds: List<String>): String {
        val gid = "g_" + UUID.randomUUID().toString().take(8)
        val members = listOf(Member(myId, myName)) + memberIds.map { Member(it, title(it)) }
        val g = Group(gid, name.trim(), members, myId)
        groups.add(g)
        store.saveGroups(groups.toList())
        chats.getOrPut(gid) { mutableStateListOf() }
        sendGroupInfo(g, targetsFor(gid))
        return gid
    }

    private fun sendGroupInfo(g: Group, eps: List<String>) {
        val m = JSONArray()
        g.members.forEach { m.put(JSONObject().put("i", it.id).put("n", it.name)) }
        send(eps, JSONObject().put("t", "g").put("id", g.id).put("name", g.name).put("m", m).put("o", g.creator))
    }

    private fun onGroup(j: JSONObject) {
        val ma = j.getJSONArray("m")
        val members = (0 until ma.length()).map { ma.getJSONObject(it).let { o -> Member(o.getString("i"), o.getString("n")) } }
        if (members.none { it.id == myId }) return
        if (j.getString("id") in hiddenGroups()) return
        val g = Group(j.getString("id"), j.getString("name"), members, j.optString("o"))
        val i = groups.indexOfFirst { it.id == g.id }
        if (i < 0) groups.add(g) else groups[i] = g
        store.saveGroups(groups.toList())
        chats.getOrPut(g.id) { mutableStateListOf() }
    }

    // ---------- delete / receipts / lists ----------

    fun deleteMessages(conv: String, ids: Set<String>) {
        val l = chats[conv] ?: return
        l.filter { it.id in ids }.forEach { m ->
            m.filePath?.let { p -> try { File(p).delete() } catch (_: Exception) {} }
        }
        l.removeAll { it.id in ids }
        store.saveChat(conv, l.toList())
    }

    fun clearChat(conv: String) {
        deleteMessages(conv, chats[conv]?.map { it.id }?.toSet() ?: emptySet())
        unread.remove(conv)
        prefs.edit().remove("u_$conv").apply()
    }

    private fun hiddenGroups(): Set<String> = prefs.getStringSet("ghide", emptySet()) ?: emptySet()
    private fun hideGroup(gid: String) { prefs.edit().putStringSet("ghide", hiddenGroups() + gid).apply() }

    private fun tombs(): JSONObject = try { JSONObject(prefs.getString("gdel", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }

    private fun addTomb(gid: String, uid: String) {
        val t = tombs()
        val a = t.optJSONArray(gid) ?: JSONArray()
        a.put(uid)
        t.put(gid, a)
        prefs.edit().putString("gdel", t.toString()).apply()
    }

    private fun sendTombs(uid: String, ep: String) {
        val t = tombs()
        var changed = false
        for (gid in t.keys().asSequence().toList()) {
            val a = t.getJSONArray(gid)
            val rest = JSONArray()
            var found = false
            for (i in 0 until a.length()) { if (a.getString(i) == uid) found = true else rest.put(a.getString(i)) }
            if (found) {
                send(listOf(ep), JSONObject().put("t", "gd").put("id", gid))
                if (rest.length() == 0) t.remove(gid) else t.put(gid, rest)
                changed = true
            }
        }
        if (changed) prefs.edit().putString("gdel", t.toString()).apply()
    }

    /** Creator: removes the group for everybody. Others: removes it from this phone only. */
    fun deleteGroup(gid: String) {
        val g = groups.find { it.id == gid } ?: return
        if (g.creator == myId) {
            val msg = JSONObject().put("t", "gd").put("id", gid)
            g.members.filter { it.id != myId }.forEach { mem ->
                val ep = userToEp[mem.id]
                if (ep != null) send(listOf(ep), msg) else addTomb(gid, mem.id)
            }
        }
        removeGroupLocal(gid)
    }

    private fun removeGroupLocal(gid: String) {
        hideGroup(gid)
        clearChat(gid)
        chats.remove(gid)
        store.deleteChat(gid)
        groups.removeAll { it.id == gid }
        store.saveGroups(groups.toList())
    }

    private fun onGroupDelete(ep: String, j: JSONObject) {
        val gid = j.getString("id")
        val g = groups.find { it.id == gid } ?: return
        if (g.creator == userOf(ep)) removeGroupLocal(gid)
    }

    private fun flushReceipts(conv: String) {
        val l = chats[conv] ?: return
        if (isGroup(conv)) {
            for (i in l.indices) if (!l[i].mine && l[i].st == 1) l[i] = l[i].copy(st = 2)
            return
        }
        val ep = userToEp[conv] ?: return
        val ids = JSONArray()
        for (i in l.indices) {
            val m = l[i]
            if (!m.mine && m.st == 1) { ids.put(m.id); l[i] = m.copy(st = 2) }
        }
        if (ids.length() > 0) {
            send(listOf(ep), JSONObject().put("t", "r").put("ids", ids))
            store.saveChat(conv, l.toList())
        }
    }

    private fun onReceipt(ep: String, j: JSONObject) {
        val uid = userOf(ep) ?: return
        val l = chats[uid] ?: return
        val a = j.getJSONArray("ids")
        val ids = (0 until a.length()).map { a.getString(it) }.toSet()
        var changed = false
        for (i in l.indices) {
            val m = l[i]
            if (m.mine && m.id in ids && m.st < 2) { l[i] = m.copy(st = 2); changed = true }
        }
        if (changed) store.saveChat(uid, l.toList())
    }

    private fun stamp(uid: String, force: Boolean) {
        val now = System.currentTimeMillis()
        if (force || now - (lastSeen[uid] ?: 0L) > 60_000) {
            lastSeen[uid] = now
            prefs.edit().putLong("ls_$uid", now).apply()
        }
    }

    private fun sendMsg(conv: String, text: String?, lst: String?) {
        val eps = targetsFor(conv)
        val pending = !isGroup(conv) && eps.isEmpty()
        val m = Msg(UUID.randomUUID().toString(), myId, myName, true, text = text, lst = lst, st = if (pending) 0 else 1)
        seen.add(m.id)
        if (!pending) send(eps, msgJson(m, conv))
        addMsg(conv, m)
    }

    fun sendText(conv: String, text: String) {
        if (text.isNotBlank()) sendMsg(conv, text, null)
    }

    fun sendList(conv: String, title: String, items: List<String>) {
        val clean = items.map { it.trim() }.filter { it.isNotEmpty() }
        if (clean.isEmpty()) return
        val j = JSONObject().put("title", title.trim()).put("date", System.currentTimeMillis())
            .put("items", JSONArray(clean)).put("d", JSONArray())
        sendMsg(conv, null, j.toString())
    }

    fun toggleItem(conv: String, msgId: String, idx: Int) {
        val l = chats[conv] ?: return
        val i = l.indexOfFirst { it.id == msgId }
        if (i < 0) return
        val m = l[i]
        val src = m.lst ?: return
        try {
            val j = JSONObject(src)
            val d = j.optJSONArray("d") ?: JSONArray()
            val out = JSONArray()
            var had = false
            for (k in 0 until d.length()) { if (d.getInt(k) == idx) had = true else out.put(d.getInt(k)) }
            if (!had) out.put(idx)
            j.put("d", out)
            l[i] = m.copy(lst = j.toString())
            store.saveChat(conv, l.toList())
        } catch (_: Exception) {}
    }

    // ---------- avatar ----------

    fun setAvatar(uri: Uri) {
        thread {
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                app.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                var s = 1
                while (minOf(o.outWidth, o.outHeight) / (s * 2) >= 256) s *= 2
                val bmp = app.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
                } ?: return@thread
                val side = minOf(bmp.width, bmp.height)
                val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
                val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
                store.avatarFile("me").outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                main.post {
                    avatarVersion++
                    sendAvatar(null)
                }
            } catch (_: Exception) {}
        }
    }

    private fun sendAvatar(ep: String?) {
        val f = store.avatarFile("me")
        if (!f.exists()) return
        thread {
            try {
                val bmp = BitmapFactory.decodeFile(f.absolutePath) ?: return@thread
                val small = Bitmap.createScaledBitmap(bmp, 96, 96, true)
                val bo = ByteArrayOutputStream()
                small.compress(Bitmap.CompressFormat.JPEG, 70, bo)
                val j = JSONObject().put("t", "a").put("s", myId)
                    .put("b", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP))
                main.post { send(if (ep != null) listOf(ep) else userToEp.values.toList(), j) }
            } catch (_: Exception) {}
        }
    }

    private fun onAvatar(j: JSONObject) {
        try {
            store.avatarFile(j.getString("s")).writeBytes(Base64.decode(j.getString("b"), Base64.NO_WRAP))
            avatarVersion++
        } catch (_: Exception) {}
    }

    // ---------- notifications ----------

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = app.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_MSG, app.getString(R.string.ch_messages), NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_CALL, app.getString(R.string.ch_calls), NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, app.getString(R.string.ch_service), NotificationManager.IMPORTANCE_LOW))
    }

    private fun openIntent(conv: String?, code: Int): PendingIntent {
        val i = Intent(app, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        if (conv != null) i.putExtra("conv", conv)
        return PendingIntent.getActivity(app, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun notifyMessage(conv: String, m: Msg) {
        if (!notifOn) return
        val nm = NotificationManagerCompat.from(app)
        if (!nm.areNotificationsEnabled()) return
        val g = isGroup(conv)
        val body = (if (g) "${m.senderName}: " else "") + m.preview()
        val n = NotificationCompat.Builder(app, CH_MSG)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(title(conv)).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(openIntent(conv, conv.hashCode())).build()
        try { nm.notify(conv.hashCode(), n) } catch (_: SecurityException) {}
    }

    private fun notifyCall(uid: String) {
        val nm = NotificationManagerCompat.from(app)
        val pi = openIntent(uid, 7)
        val n = NotificationCompat.Builder(app, CH_CALL)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(app.getString(R.string.incoming_call))
            .setContentText(title(uid)).setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL).setOngoing(true)
            .setContentIntent(pi).setFullScreenIntent(pi, true).build()
        try { nm.notify(777, n) } catch (_: SecurityException) {}
    }

    private fun cancelCallNotif() = NotificationManagerCompat.from(app).cancel(777)

    // ---------- calls ----------

    private var ringtone: Ringtone? = null
    private fun ring(on: Boolean) {
        try {
            if (on) {
                ringtone = RingtoneManager.getRingtone(app, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
                ringtone?.play()
            } else {
                ringtone?.stop(); ringtone = null
            }
        } catch (_: Exception) {}
    }

    private fun sig(uid: String, k: String) {
        userToEp[uid]?.let { send(listOf(it), JSONObject().put("t", "c").put("k", k)) }
    }

    fun startCall(uid: String) {
        if (callState != CallState.IDLE || userToEp[uid] == null) return
        callPeer = uid
        callState = CallState.OUTGOING
        sig(uid, "req")
    }

    fun acceptCall() {
        val uid = callPeer ?: return
        ring(false); cancelCallNotif()
        sig(uid, "acc")
        callState = CallState.ACTIVE
        startAudio(uid)
    }

    fun endCall(notify: Boolean = true) {
        val uid = callPeer
        if (notify && uid != null && callState != CallState.IDLE) sig(uid, "end")
        ring(false); cancelCallNotif()
        stopAudio()
        callPeer = null
        callState = CallState.IDLE
    }

    private fun handleCall(ep: String, k: String) {
        val uid = userOf(ep) ?: return
        when (k) {
            "req" -> if (callState == CallState.IDLE) {
                callPeer = uid
                callState = CallState.INCOMING
                ring(true)
                if (!appVisible) notifyCall(uid)
            } else sig(uid, "end")
            "acc" -> if (callState == CallState.OUTGOING && callPeer == uid) {
                callState = CallState.ACTIVE
                startAudio(uid)
            }
            "end" -> if (callPeer == uid) endCall(notify = false)
        }
    }

    @Volatile private var audioOn = false
    @Volatile private var playing = false
    private var incoming: Payload? = null

    private fun startAudio(uid: String) {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        @Suppress("DEPRECATION")
        am.isSpeakerphoneOn = true
        audioOn = true
        tryPlay()
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val ep = userToEp[uid] ?: return
        val pipe = ParcelFileDescriptor.createPipe()
        client.sendPayload(ep, Payload.fromStream(pipe[0]))
        val out = ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
        thread {
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400))
            } catch (e: Exception) { null }
            if (rec == null) { try { out.close() } catch (_: Exception) {}; return@thread }
            val buf = ByteArray(1600)
            try {
                rec.startRecording()
                while (audioOn) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) out.write(buf, 0, n)
                }
            } catch (_: Exception) {
            } finally {
                try { rec.stop() } catch (_: Exception) {}
                rec.release()
                try { out.close() } catch (_: Exception) {}
            }
        }
    }

    private fun tryPlay() {
        val p = incoming ?: return
        if (!audioOn || playing) return
        val stream = p.asStream() ?: return
        playing = true
        thread {
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(min, 6400))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            val buf = ByteArray(1600)
            try {
                track.play()
                val ins = stream.asInputStream()
                while (audioOn) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    if (n > 0) track.write(buf, 0, n)
                }
            } catch (_: Exception) {
            } finally {
                try { track.stop() } catch (_: Exception) {}
                track.release()
                playing = false
            }
        }
    }

    private fun stopAudio() {
        audioOn = false
        try { incoming?.close() } catch (_: Exception) {}
        incoming = null
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_NORMAL
        @Suppress("DEPRECATION")
        am.isSpeakerphoneOn = false
    }
}

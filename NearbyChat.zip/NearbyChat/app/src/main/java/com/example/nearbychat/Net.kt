package com.example.nearbychat

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.res.Configuration
import android.net.wifi.WifiManager
import android.provider.Settings
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.util.Base64
import android.widget.Toast
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.Collections
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.concurrent.thread

data class Found(
    val ep: String, val userId: String, val name: String,
    val kind: String = "", val addr: String = "", val port: Int = 0
)
enum class CallState { IDLE, OUTGOING, INCOMING, ACTIVE }

/**
 * Networking + data. Uses our own transport (see Transport.kt): Bluetooth and Wi-Fi (same network).
 * Lives in the Application so it keeps running while the foreground service is alive.
 */
class Net(private val app: Context) {
    companion object {
        const val CH_MSG = "messages"
        const val CH_CALL = "calls"
        const val CH_SERVICE = "service"
        const val CH_SMS = "sms"
        const val CH_INCALL = "incall"
        const val CH_MISSED = "missed"
    }

    val store = Store(app)
    private val prefs = store.prefs
    private val main = Handler(Looper.getMainLooper())
    private val tp = Transport(app, object : Transport.Callbacks {
        override fun onNewLink(link: Link) { main.post { handleNewLink(link) } }
        override fun onSeen(s: Seen) { main.post { handleSeen(s) } }
        override fun onConnectFailed(key: String) { main.post { connectFailed(key) } }
    })
    private val rate = 16000

    // ---- settings / profile (observable) ----
    val myId: String = prefs.getString("uid", null)
        ?: UUID.randomUUID().toString().take(8).also { prefs.edit().putString("uid", it).apply() }
    var myName by mutableStateOf(prefs.getString("name", "") ?: "")
    var avatarVersion by mutableIntStateOf(0)
    var theme by mutableIntStateOf(prefs.getInt("theme", 0))      // 0 system, 1 light, 2 dark
    var accent by mutableIntStateOf(prefs.getInt("accent", 0))
    var notifOn by mutableStateOf(prefs.getBoolean("notif", true))
    var bgService by mutableStateOf(prefs.getBoolean("bg", true))
    var calendar by mutableIntStateOf(prefs.getInt("cal", if (java.util.Locale.getDefault().language == "fa") 1 else 0)) // 0 Gregorian, 1 Jalali

    fun changeTheme(v: Int) { theme = v; prefs.edit().putInt("theme", v).apply() }
    fun changeAccent(v: Int) { accent = v; prefs.edit().putInt("accent", v).apply() }
    fun setNotif(v: Boolean) { notifOn = v; prefs.edit().putBoolean("notif", v).apply() }
    fun setBg(v: Boolean) { bgService = v; prefs.edit().putBoolean("bg", v).apply() }
    fun changeCalendar(v: Int) { calendar = v; prefs.edit().putInt("cal", v).apply() }

    // ---- phone / look-and-feel settings ----
    var callStyle by mutableIntStateOf(prefs.getInt("callStyle", 0))   // 0 Aurora, 1 Classic, 2 Minimal, 3 Neon
    var dialStyle by mutableIntStateOf(prefs.getInt("dialStyle", 0))   // 0 round, 1 square, 2 flat
    var digits by mutableIntStateOf(prefs.getInt("digits", 0))         // 0 auto, 1 Persian, 2 English
    var fontScale by mutableIntStateOf(prefs.getInt("fontScale", 1))   // 0 small .. 3 extra large
    var bubble by mutableIntStateOf(prefs.getInt("bubble", 1))         // 0 square, 1 rounded, 2 round
    var amoled by mutableStateOf(prefs.getBoolean("amoled", false))
    var simCall by mutableIntStateOf(prefs.getInt("simCall", -2))      // -2 system, -1 ask, 0/1 slot
    var simSms by mutableIntStateOf(prefs.getInt("simSms", -2))
    var myPhone by mutableStateOf(prefs.getString("myphone", "") ?: "")
    val phoneToUser = mutableStateMapOf<String, String>()
    var openSms by mutableStateOf<Pair<String, String>?>(null)
    var openDial by mutableStateOf<String?>(null)
    var openNewSms by mutableStateOf<String?>(null)

    fun saveInt(k: String, v: Int) { prefs.edit().putInt(k, v).apply() }
    fun saveBool(k: String, v: Boolean) { prefs.edit().putBoolean(k, v).apply() }
    fun changeMyPhone(v: String) { myPhone = v; prefs.edit().putString("myphone", v).apply() }
    fun bubbleDp(): Dp = when (bubble) { 0 -> 6.dp; 1 -> 16.dp; else -> 24.dp }

    /** Persian digits on screen? (setting, or the app language when set to Auto) */
    fun faNum(): Boolean {
        if (digits == 1) return true
        if (digits == 2) return false
        val l = prefs.getString("lang", "system") ?: "system"
        return (if (l == "system") Locale.getDefault().language else l) == "fa"
    }

    fun numStr(s: String): String = if (faNum()) faDigits(s) else s

    private fun indexPhone(uid: String, json: String) {
        try {
            val k = PhoneRepo.norm(JSONObject(json).optString("phone"))
            if (k.length >= 7) phoneToUser[k] = uid
        } catch (_: Exception) {}
    }

    fun saveName(n: String) {
        myName = n.trim()
        prefs.edit().putString("name", myName).apply()
        tp.myName = myName
    }

    // ---- observable data ----
    var running by mutableStateOf(false)
    var appVisible = false
    var activeChat: String? = null
    var openRequest by mutableStateOf<String?>(null)

    val contacts = mutableStateListOf<Contact>()
    val groups = mutableStateListOf<Group>()
    val online = mutableStateListOf<String>()
    val nearby = mutableStateListOf<Found>()
    val requests = mutableStateListOf<Found>()
    val chats = mutableStateMapOf<String, SnapshotStateList<Msg>>()
    val unread = mutableStateMapOf<String, Int>()
    val lastSeen = mutableStateMapOf<String, Long>()
    val infos = mutableStateMapOf<String, String>()
    var radiosOff by mutableStateOf(false)
    var callState by mutableStateOf(CallState.IDLE)
    var callPeer by mutableStateOf<String?>(null)

    private val epInfo = mutableMapOf<String, Found>()
    private val epToUser = mutableMapOf<String, String>()
    private val userToEp = mutableMapOf<String, String>()
    private val fileMeta = mutableMapOf<Long, JSONObject>()
    private val seen: MutableSet<String> = Collections.newSetFromMap(
        object : LinkedHashMap<String, Boolean>() {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?) = size > 2000
        }
    )

    init {
        contacts.addAll(store.loadContacts())
        contacts.forEach { c ->
            prefs.getLong("ls_${c.id}", 0L).let { if (it > 0) lastSeen[c.id] = it }
            prefs.getString("info_${c.id}", null)?.let { infos[c.id] = it; indexPhone(c.id, it) }
        }
        groups.addAll(store.loadGroups())
        store.chatIds().forEach { id ->
            val l = mutableStateListOf<Msg>()
            val msgs = store.loadChat(id)
            l.addAll(msgs)
            msgs.forEach { seen.add(it.id) }
            chats[id] = l
            val u = prefs.getInt("u_$id", 0)
            if (u > 0) unread[id] = u
        }
        createChannels()
    }

    /** Strings in the language chosen inside the app (the Application context only knows the system language). */
    private fun lctx(): Context {
        val lang = prefs.getString("lang", "system") ?: "system"
        if (lang == "system") return app
        val cfg = Configuration(app.resources.configuration)
        val loc = Locale(lang)
        cfg.setLocale(loc)
        cfg.setLayoutDirection(loc)
        return app.createConfigurationContext(cfg)
    }

    fun str(r: Int, vararg a: Any): String = lctx().getString(r, *a)
    fun refreshChannels() = createChannels()

    fun since(uid: String): Long = prefs.getLong("since_$uid", 0L)

    fun isGroup(conv: String) = conv.startsWith("g_")
    fun title(conv: String): String =
        if (isGroup(conv)) groups.find { it.id == conv }?.name ?: conv
        else contacts.find { it.id == conv }?.name ?: epInfo.values.find { it.userId == conv }?.name ?: conv

    private fun userOf(ep: String) = epToUser[ep] ?: epInfo[ep]?.userId
    private fun toast(r: Int) = Toast.makeText(app, str(r), Toast.LENGTH_SHORT).show()

    // ---------- start / stop ----------

    /** 0 = automatic (both), 1 = Bluetooth only, 2 = Wi-Fi only */
    var mode by mutableIntStateOf(prefs.getInt("mode", 0))

    private val links = mutableMapOf<String, Link>()
    private val manual = mutableSetOf<String>()
    private val connecting = mutableSetOf<String>()
    private val seenAt = mutableMapOf<String, Long>()
    private val btNext = mutableMapOf<String, Long>()
    private val btBack = mutableMapOf<String, Long>()
    private val btPending = mutableSetOf<String>()
    private var radioReceiver: BroadcastReceiver? = null
    private var tick = 0

    fun changeMode(v: Int) {
        mode = v
        prefs.edit().putInt("mode", v).apply()
        tp.useBt = v != 2
        tp.useWifi = v != 1
        if (running) {
            links.values.toList().forEach { l ->
                if ((l.kind == "bt" && v == 2) || (l.kind == "wifi" && v == 1)) l.close()
            }
            nearby.removeAll { (it.kind == "bt" && v == 2) || (it.kind == "wifi" && v == 1) }
            tp.applyMode()
        }
    }

    fun startIfReady() {
        if (myName.isNotBlank() && !prefs.getBoolean("exited", false)) start()
    }

    /** Called when the user opens the app: leaves the "exited" state and starts everything. */
    fun resume() {
        prefs.edit().putBoolean("exited", false).apply()
        start()
    }

    /** Full stop: nothing keeps running until the user opens the app again. */
    fun exit() {
        try { endCall(true) } catch (_: Exception) {}
        running = false
        main.removeCallbacksAndMessages(null)
        radioReceiver?.let { try { app.unregisterReceiver(it) } catch (_: Exception) {} }
        radioReceiver = null
        online.toList().forEach { stamp(it, true) }
        links.values.toList().forEach { it.close() }
        links.clear()
        tp.stop()
        nearby.clear(); online.clear(); requests.clear()
        epToUser.clear(); userToEp.clear(); epInfo.clear(); manual.clear(); connecting.clear()
        prefs.edit().putBoolean("exited", true).commit()
        NotificationManagerCompat.from(app).cancelAll()
        store.flush()
    }

    fun btOn(): Boolean = tp.btOn()
    fun wifiOn(): Boolean = try {
        (app.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (_: Throwable) { false }

    fun linkKind(uid: String): String? =
        userToEp[uid]?.let { links[it]?.kind } ?: prefs.getString("lk_$uid", null)

    fun start() {
        if (running || myName.isBlank()) return
        running = true
        tp.myId = myId
        tp.myName = myName
        tp.useBt = mode != 2
        tp.useWifi = mode != 1
        watchRadios()
        tp.start()
        radiosOff = !btOn() && !wifiOn()
        main.removeCallbacks(ticker)
        main.postDelayed(ticker, 5000)
    }

    /** Re-check radios / permissions (e.g. after the Bluetooth permission was granted). */
    fun refreshRadios() {
        if (running) tp.refresh()
    }

    private fun watchRadios() {
        if (radioReceiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (!running) return
                tp.refresh()
                radiosOff = !btOn() && !wifiOn()
            }
        }
        radioReceiver = r
        val f = IntentFilter().apply {
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
        }
        ContextCompat.registerReceiver(app, r, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    /** Every 5 s: keep-alive pings, drop dead links, forget old Wi-Fi sightings, retry Bluetooth contacts. */
    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            tick++
            val now = System.currentTimeMillis()
            links.values.toList().forEach { l ->
                if (l.open) {
                    if (tick % 3 == 0) l.ping()
                    if (now - l.lastRx > 55_000) l.close()
                }
            }
            nearby.removeAll { it.kind == "wifi" && now - (seenAt[it.ep] ?: 0L) > 15_000 }
            if (tick % 8 == 0) btAuto()
            radiosOff = !btOn() && !wifiOn()
            main.postDelayed(this, 5000)
        }
    }

    /** Reconnect to known contacts over Bluetooth (their address was saved when we first connected). */
    private fun btAuto() {
        if (!running || mode == 2 || !btOn()) return
        val now = System.currentTimeMillis()
        contacts.forEach { c ->
            if (userToEp.containsKey(c.id)) return@forEach
            val mac = prefs.getString("mac_${c.id}", null) ?: return@forEach
            if (now >= (btNext[mac] ?: 0L) && btPending.add(mac)) tp.connectBt(mac)
        }
    }

    /** User-initiated Bluetooth scan (paired phones + visible phones). */
    fun rescan() {
        if (!running) return
        nearby.removeAll { it.kind == "bt" }
        tp.scanBluetooth()
    }

    // ---------- connections ----------

    fun connect(f: Found) {
        if (f.userId.isNotEmpty() && userToEp.containsKey(f.userId)) return
        manual.add(f.ep)
        if (f.kind == "wifi") tp.connectWifi(f.ep, f.addr, f.port)
        else tp.connectBt(f.addr.ifEmpty { f.ep.removePrefix("bt:") })
    }

    fun acceptRequest(f: Found) {
        requests.remove(f)
        NotificationManagerCompat.from(app).cancel(f.ep.hashCode())
        links[f.ep]?.let { acceptLink(it) }
    }

    fun rejectRequest(f: Found) {
        requests.remove(f)
        NotificationManagerCompat.from(app).cancel(f.ep.hashCode())
        links[f.ep]?.close()
    }

    private fun handleSeen(s: Seen) {
        if (!running) return
        val f = Found(s.key, s.userId, s.name, s.kind, s.addr, s.port)
        if (s.kind == "wifi") {
            if (s.userId == myId || userToEp.containsKey(s.userId)) return
            seenAt[s.key] = System.currentTimeMillis()
            val i = nearby.indexOfFirst { it.ep == s.key }
            if (i < 0) nearby.add(f) else if (nearby[i] != f) nearby[i] = f
            if (contacts.any { it.id == s.userId } && connecting.add(s.key)) {
                // known contact: reconnect automatically (one side first, the other as a fallback)
                val delay = if (myId < s.userId) 300L else 5000L
                main.postDelayed({
                    if (running && !userToEp.containsKey(s.userId)) {
                        nearby.find { it.ep == s.key }?.let { tp.connectWifi(it.ep, it.addr, it.port) }
                    }
                }, delay)
                main.postDelayed({ connecting.remove(s.key) }, 12_000)
            }
        } else {
            val known = contacts.firstOrNull { prefs.getString("mac_${it.id}", null) == s.addr }
            if (known != null && userToEp.containsKey(known.id)) return
            if (nearby.none { it.ep == s.key }) nearby.add(f)
        }
    }

    private fun connectFailed(key: String) {
        if (key.startsWith("bt:")) {
            val mac = key.removePrefix("bt:")
            btPending.remove(mac)
            val b = minOf((btBack[mac] ?: 20_000L) * 2, 300_000L)
            btBack[mac] = b
            btNext[mac] = System.currentTimeMillis() + b
        }
        if (manual.remove(key)) toast(R.string.connect_failed)
    }

    // ---------- links (hello / accept handshake) ----------

    private fun handleNewLink(l: Link) {
        if (!running) { l.close(); return }
        links[l.id] = l
        if (l.outbound && l.kind == "bt") btPending.remove(l.addr)
        l.onFrame = { x, t, d -> onFrame(x, t, d) }
        l.onClose = { x -> main.post { onLinkClosed(x) } }
        l.start()
        l.sendJson(JSONObject().put("t", "hello").put("id", myId).put("name", myName).put("v", 1))
    }

    private fun onFrame(l: Link, type: Int, d: ByteArray) {
        when (type) {
            1 -> {
                val j = try { JSONObject(String(d, Charsets.UTF_8)) } catch (_: Exception) { return }
                main.post { onJson(l, j) }
            }
            2 -> if (l.established) rxChunk(l, d)
            3 -> if (l.established) rxEnd(l, d)
            6 -> if (l.established) playAudio(d)
        }
    }

    private fun onJson(l: Link, j: JSONObject) {
        if (!l.open) return
        when (j.optString("t")) {
            "hello" -> onHello(l, j)
            "acc" -> { l.peerAccepted = true; tryEstablish(l) }
            else -> if (l.established) handleJson(l.id, j)
        }
    }

    private fun onHello(l: Link, j: JSONObject) {
        val uid = j.optString("id")
        if (uid.isEmpty() || uid == myId || l.userId != null) { if (uid == myId) l.close(); return }
        val name = j.optString("name").ifBlank { uid }
        l.userId = uid
        l.name = name
        val f = Found(l.id, uid, name, l.kind)
        epInfo[l.id] = f
        if (l.outbound || contacts.any { it.id == uid }) {
            acceptLink(l)
        } else if (requests.none { it.ep == l.id }) {
            requests.add(f)
            if (!appVisible) notifyRequest(f)
        }
    }

    private fun acceptLink(l: Link) {
        if (l.accepted) return
        l.accepted = true
        l.sendJson(JSONObject().put("t", "acc"))
        tryEstablish(l)
    }

    private fun tryEstablish(l: Link) {
        if (l.accepted && l.peerAccepted && !l.established && l.userId != null) establish(l)
    }

    /** Wi-Fi beats Bluetooth; between equals both phones pick the same winner. */
    private fun score(l: Link, uid: String): Int {
        val winner = if (l.outbound) myId < uid else uid < myId
        return (if (l.kind == "wifi") 10 else 0) + (if (winner) 1 else 0)
    }

    private fun establish(l: Link) {
        val uid = l.userId ?: return
        val old = userToEp[uid]?.let { links[it] }
        if (old != null && old !== l && old.open) {
            if (score(l, uid) <= score(old, uid)) { l.close(); return }
            old.close()
        }
        l.established = true
        val ep = l.id
        val f = epInfo[ep] ?: Found(ep, uid, l.name, l.kind)
        epToUser[ep] = uid
        userToEp[uid] = ep
        if (!online.contains(uid)) online.add(uid)
        nearby.removeAll { it.userId == uid || (it.kind == "bt" && it.addr == l.addr) }
        requests.removeAll { it.ep == ep }
        manual.remove("wifi:$uid")
        manual.remove("bt:${l.addr}")
        val idx = contacts.indexOfFirst { it.id == uid }
        if (idx < 0) {
            contacts.add(Contact(uid, f.name))
            prefs.edit().putLong("since_$uid", System.currentTimeMillis()).apply()
        } else if (contacts[idx].name != f.name) contacts[idx] = Contact(uid, f.name)
        store.saveContacts(contacts.toList())
        prefs.edit().putString("lk_$uid", l.kind).apply()
        if (l.kind == "bt") {
            prefs.edit().putString("mac_$uid", l.addr).apply()
            btBack.remove(l.addr); btNext.remove(l.addr); btPending.remove(l.addr)
        }
        chats.getOrPut(uid) { mutableStateListOf() }
        sendAvatar(ep)
        sendInfo(ep)
        groups.filter { g -> g.members.any { it.id == uid } }.forEach { sendGroupInfo(it, listOf(ep)) }
        flushPending(uid, ep)
        flushReceipts(uid)
        sendQueued(uid, ep)
        sendTombs(uid, ep)
        stamp(uid, true)
    }

    private fun onLinkClosed(l: Link) {
        links.remove(l.id)
        requests.removeAll { it.ep == l.id }
        epInfo.remove(l.id)
        NotificationManagerCompat.from(app).cancel(l.id.hashCode())
        val uid = epToUser.remove(l.id) ?: return
        if (userToEp[uid] == l.id) {
            userToEp.remove(uid)
            online.remove(uid)
            stamp(uid, true)
            if (callPeer == uid) endCall(notify = false)
        }
    }

    // ---------- incoming file data ----------

    private fun rxChunk(l: Link, d: ByteArray) {
        if (d.size < 8) return
        try {
            val pid = ByteBuffer.wrap(d).long
            var os = l.rxOut[pid]
            if (os == null) {
                val f = File(store.filesDir, "rx_$pid.part")
                os = FileOutputStream(f)
                l.rxOut[pid] = os
                l.rxFile[pid] = f
            }
            os.write(d, 8, d.size - 8)
        } catch (_: Exception) {}
    }

    private fun rxEnd(l: Link, d: ByteArray) {
        if (d.size < 8) return
        val pid = ByteBuffer.wrap(d).long
        try { l.rxOut.remove(pid)?.close() } catch (_: Exception) {}
        val f = l.rxFile.remove(pid) ?: return
        val ep = l.id
        main.post { onFileDone(ep, pid, f) }
    }

    private fun onFileDone(ep: String, pid: Long, tmp: File) {
        val meta = fileMeta.remove(pid)
        if (meta != null && meta.optString("kind") == "avatar") {
            val uid = meta.optString("s")
            if (uid.isNotEmpty()) {
                try { tmp.copyTo(store.avatarFile(uid), overwrite = true); avatarVersion++ } catch (_: Exception) {}
            }
            tmp.delete()
            return
        }
        val name = (meta?.optString("name") ?: "file_$pid").replace('/', '_')
        val dest = File(store.filesDir, "${System.currentTimeMillis()}_$name")
        if (!tmp.renameTo(dest)) {
            try { tmp.copyTo(dest, overwrite = true); tmp.delete() } catch (_: Exception) { return }
        }
        val s = meta?.optString("s")?.ifEmpty { null } ?: userOf(ep) ?: return
        val c = meta?.optString("c", "") ?: ""
        val id = meta?.optString("id")?.ifEmpty { null } ?: UUID.randomUUID().toString()
        if (!seen.add(id)) return
        addMsg(if (c.isNotEmpty()) c else s,
            Msg(id, s, meta?.optString("n") ?: "", false, fileName = name, filePath = dest.absolutePath,
                fwd = meta?.optBoolean("fw") == true))
    }

    private fun handleJson(ep: String, j: JSONObject) {
        userOf(ep)?.let { stamp(it, false) }
        when (j.getString("t")) {
            "m" -> onMessage(ep, j)
            "f" -> fileMeta[j.getLong("pid")] = j
            "r" -> onReceipt(ep, j)
            "i" -> onInfo(ep, j)
            "del" -> onDelete(ep, j)
            "lt" -> onItemOp(ep, j)
            "gd" -> onGroupDelete(ep, j)
            "g" -> onGroup(j)
            "a" -> onAvatar(j)
            "c" -> handleCall(ep, j.getString("k"))
        }
    }

    private fun send(eps: List<String>, j: JSONObject) {
        eps.forEach { links[it]?.sendJson(j) }
    }

    private fun addMsg(conv: String, m: Msg) {
        val list = chats.getOrPut(conv) { mutableStateListOf() }
        list.add(m)
        store.saveChat(conv, list.toList())
        if (!m.mine) {
            if (appVisible && activeChat == conv) {
                markRead(conv)
            } else {
                unread[conv] = (unread[conv] ?: 0) + 1
                prefs.edit().putInt("u_$conv", unread[conv] ?: 0).apply()
                notifyMessage(conv, m)
            }
        }
    }

    /** Called when the user is actually looking at this chat. */
    fun markRead(conv: String) {
        if (!appVisible) return
        unread.remove(conv)
        prefs.edit().remove("u_$conv").apply()
        NotificationManagerCompat.from(app).cancel(conv.hashCode())
        val l = chats[conv]
        if (l != null) {
            var ch = false
            for (i in l.indices) if (!l[i].mine && l[i].st == 0) { l[i] = l[i].copy(st = 1); ch = true }
            if (ch) store.saveChat(conv, l.toList())
        }
        flushReceipts(conv)
    }

    private fun msgJson(m: Msg, conv: String): JSONObject {
        val j = JSONObject().put("t", "m").put("id", m.id).put("s", myId).put("n", myName).put("x", m.text ?: "")
        if (m.lst != null) j.put("l", m.lst)
        if (m.fwd) j.put("fw", true)
        if (isGroup(conv)) j.put("c", conv)
        return j
    }

    private fun targetsFor(conv: String): List<String> =
        if (isGroup(conv)) groups.find { it.id == conv }?.members?.filter { it.id != myId }
            ?.mapNotNull { userToEp[it.id] } ?: emptyList()
        else listOfNotNull(userToEp[conv])

    fun canSendNow(conv: String) = targetsFor(conv).isNotEmpty()

    private fun flushPending(uid: String, ep: String) {
        val list = chats[uid] ?: return
        var changed = false
        for (i in list.indices) {
            val m = list[i]
            if (m.mine && m.pending) {
                send(listOf(ep), msgJson(m, uid))
                list[i] = m.copy(st = 1)
                changed = true
            }
        }
        if (changed) store.saveChat(uid, list.toList())
    }

    private fun onMessage(ep: String, j: JSONObject) {
        val id = j.getString("id")
        if (!seen.add(id)) return
        val s = j.getString("s")
        val c = j.optString("c", "")
        val group = c.isNotEmpty()
        if (group && groups.none { it.id == c }) return
        addMsg(if (group) c else s, Msg(id, s, j.optString("n"), false,
            text = j.optString("x").ifEmpty { null }, lst = j.optString("l").ifEmpty { null }, fwd = j.optBoolean("fw")))
        if (group) { // relay so members that are not directly connected to the sender still get it
            val g = groups.first { it.id == c }
            val targets = g.members.mapNotNull { userToEp[it.id] }.filter { it != ep && userOf(it) != s }
            send(targets, j)
        }
    }

    // ---------- files ----------

    fun displayName(uri: Uri): String {
        var name = "file"
        try {
            app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
            }
        } catch (_: Exception) {}
        return name
    }

    fun sendFile(conv: String, uri: Uri) {
        if (!canSendNow(conv)) { toast(R.string.offline); return }
        val name = displayName(uri)
        thread {
            try {
                val dest = File(store.filesDir, "${System.currentTimeMillis()}_${name.replace('/', '_')}")
                app.contentResolver.openInputStream(uri)?.use { i -> dest.outputStream().use { i.copyTo(it) } }
                main.post { dispatchFile(conv, dest, name) }
            } catch (_: Exception) {
                main.post { toast(R.string.connect_failed) }
            }
        }
    }

    private fun dispatchFile(conv: String, file: File, name: String, fwd: Boolean = false) {
        val eps = targetsFor(conv)
        if (eps.isEmpty()) { toast(R.string.offline); return }
        val pid = UUID.randomUUID().mostSignificantBits
        val m = Msg(UUID.randomUUID().toString(), myId, myName, true, fileName = name, filePath = file.absolutePath, st = 1, fwd = fwd)
        val meta = JSONObject().put("t", "f").put("pid", pid).put("id", m.id)
            .put("s", myId).put("n", myName).put("name", name).put("fw", fwd)
        if (isGroup(conv)) meta.put("c", conv)
        eps.forEach { ep -> links[ep]?.let { l -> l.sendJson(meta); l.sendFile(pid, file) } }
        seen.add(m.id)
        addMsg(conv, m)
    }

    // ---------- groups ----------

    fun createGroup(name: String, memberIds: List<String>): String {
        val gid = "g_" + UUID.randomUUID().toString().take(8)
        val members = listOf(Member(myId, myName)) + memberIds.map { Member(it, title(it)) }
        val g = Group(gid, name.trim(), members, myId)
        groups.add(g)
        store.saveGroups(groups.toList())
        chats.getOrPut(gid) { mutableStateListOf() }
        sendGroupInfo(g, targetsFor(gid))
        return gid
    }

    private fun sendGroupInfo(g: Group, eps: List<String>) {
        val m = JSONArray()
        g.members.forEach { m.put(JSONObject().put("i", it.id).put("n", it.name)) }
        send(eps, JSONObject().put("t", "g").put("id", g.id).put("name", g.name).put("m", m).put("o", g.creator))
    }

    private fun onGroup(j: JSONObject) {
        val ma = j.getJSONArray("m")
        val members = (0 until ma.length()).map { ma.getJSONObject(it).let { o -> Member(o.getString("i"), o.getString("n")) } }
        if (members.none { it.id == myId }) return
        if (j.getString("id") in hiddenGroups()) return
        val g = Group(j.getString("id"), j.getString("name"), members, j.optString("o"))
        val i = groups.indexOfFirst { it.id == g.id }
        if (i < 0) groups.add(g) else groups[i] = g
        store.saveGroups(groups.toList())
        chats.getOrPut(g.id) { mutableStateListOf() }
    }

    // ---------- delete / receipts / lists ----------

    fun deleteMessages(conv: String, ids: Set<String>) {
        val l = chats[conv] ?: return
        l.filter { it.id in ids }.forEach { m ->
            m.filePath?.let { p -> try { File(p).delete() } catch (_: Exception) {} }
        }
        l.removeAll { it.id in ids }
        store.saveChat(conv, l.toList())
    }

    fun clearChat(conv: String) {
        deleteMessages(conv, chats[conv]?.map { it.id }?.toSet() ?: emptySet())
        unread.remove(conv)
        prefs.edit().remove("u_$conv").apply()
    }

    private fun hiddenGroups(): Set<String> = prefs.getStringSet("ghide", emptySet()) ?: emptySet()
    private fun hideGroup(gid: String) { prefs.edit().putStringSet("ghide", hiddenGroups() + gid).apply() }

    private fun tombs(): JSONObject = try { JSONObject(prefs.getString("gdel", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }

    private fun addTomb(gid: String, uid: String) {
        val t = tombs()
        val a = t.optJSONArray(gid) ?: JSONArray()
        a.put(uid)
        t.put(gid, a)
        prefs.edit().putString("gdel", t.toString()).apply()
    }

    private fun sendTombs(uid: String, ep: String) {
        val t = tombs()
        var changed = false
        for (gid in t.keys().asSequence().toList()) {
            val a = t.getJSONArray(gid)
            val rest = JSONArray()
            var found = false
            for (i in 0 until a.length()) { if (a.getString(i) == uid) found = true else rest.put(a.getString(i)) }
            if (found) {
                send(listOf(ep), JSONObject().put("t", "gd").put("id", gid))
                if (rest.length() == 0) t.remove(gid) else t.put(gid, rest)
                changed = true
            }
        }
        if (changed) prefs.edit().putString("gdel", t.toString()).apply()
    }

    /** Creator: removes the group for everybody. Others: removes it from this phone only. */
    fun deleteGroup(gid: String) {
        val g = groups.find { it.id == gid } ?: return
        if (g.creator == myId) {
            val msg = JSONObject().put("t", "gd").put("id", gid)
            g.members.filter { it.id != myId }.forEach { mem ->
                val ep = userToEp[mem.id]
                if (ep != null) send(listOf(ep), msg) else addTomb(gid, mem.id)
            }
        }
        removeGroupLocal(gid)
    }

    private fun removeGroupLocal(gid: String) {
        hideGroup(gid)
        clearChat(gid)
        chats.remove(gid)
        store.deleteChat(gid)
        groups.removeAll { it.id == gid }
        store.saveGroups(groups.toList())
    }

    private fun onGroupDelete(ep: String, j: JSONObject) {
        val gid = j.getString("id")
        val g = groups.find { it.id == gid } ?: return
        if (g.creator == userOf(ep)) removeGroupLocal(gid)
    }

    private fun flushReceipts(conv: String) {
        val l = chats[conv] ?: return
        if (isGroup(conv)) {
            for (i in l.indices) if (!l[i].mine && l[i].st == 1) l[i] = l[i].copy(st = 2)
            return
        }
        val ep = userToEp[conv] ?: return
        val ids = JSONArray()
        for (i in l.indices) {
            val m = l[i]
            if (!m.mine && m.st == 1) { ids.put(m.id); l[i] = m.copy(st = 2) }
        }
        if (ids.length() > 0) {
            send(listOf(ep), JSONObject().put("t", "r").put("ids", ids))
            store.saveChat(conv, l.toList())
        }
    }

    private fun onReceipt(ep: String, j: JSONObject) {
        val uid = userOf(ep) ?: return
        val l = chats[uid] ?: return
        val a = j.getJSONArray("ids")
        val ids = (0 until a.length()).map { a.getString(it) }.toSet()
        var changed = false
        for (i in l.indices) {
            val m = l[i]
            if (m.mine && m.id in ids && m.st < 2) { l[i] = m.copy(st = 2); changed = true }
        }
        if (changed) store.saveChat(uid, l.toList())
    }

    private fun stamp(uid: String, force: Boolean) {
        val now = System.currentTimeMillis()
        if (force || now - (lastSeen[uid] ?: 0L) > 60_000) {
            lastSeen[uid] = now
            prefs.edit().putLong("ls_$uid", now).apply()
        }
    }

    private fun sendMsg(conv: String, text: String?, lst: String?, fwd: Boolean = false) {
        val eps = targetsFor(conv)
        val pending = !isGroup(conv) && eps.isEmpty()
        val m = Msg(UUID.randomUUID().toString(), myId, myName, true, text = text, lst = lst, st = if (pending) 0 else 1, fwd = fwd)
        seen.add(m.id)
        if (!pending) send(eps, msgJson(m, conv))
        addMsg(conv, m)
    }

    fun sendText(conv: String, text: String) {
        if (text.isNotBlank()) sendMsg(conv, text, null)
    }

    fun sendList(conv: String, title: String, items: List<String>) {
        val clean = items.map { it.trim() }.filter { it.isNotEmpty() }
        if (clean.isEmpty()) return
        val j = JSONObject().put("title", title.trim()).put("date", System.currentTimeMillis())
            .put("items", JSONArray(clean)).put("d", JSONArray())
        sendMsg(conv, null, j.toString())
    }

    // ----- shared operations (delete for everyone, list ticks) -----

    private fun uidsFor(conv: String): List<String> =
        if (isGroup(conv)) groups.find { it.id == conv }?.members?.map { it.id }?.filter { it != myId } ?: emptyList()
        else listOf(conv)

    private fun queueOp(uid: String, op: JSONObject) {
        val all = try { JSONObject(prefs.getString("outq", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val a = all.optJSONArray(uid) ?: JSONArray()
        a.put(op.toString())
        all.put(uid, a)
        prefs.edit().putString("outq", all.toString()).apply()
    }

    private fun sendQueued(uid: String, ep: String) {
        val all = try { JSONObject(prefs.getString("outq", "{}") ?: "{}") } catch (_: Exception) { return }
        val a = all.optJSONArray(uid) ?: return
        for (i in 0 until a.length()) try { send(listOf(ep), JSONObject(a.getString(i))) } catch (_: Exception) {}
        all.remove(uid)
        prefs.edit().putString("outq", all.toString()).apply()
    }

    /** Send now to online people, keep for offline ones and deliver when they connect. */
    private fun sendOp(uids: List<String>, op: JSONObject) {
        uids.forEach { uid ->
            val ep = userToEp[uid]
            if (ep != null) send(listOf(ep), op) else queueOp(uid, op)
        }
    }

    private fun relay(gid: String, fromEp: String, origin: String, j: JSONObject) {
        val g = groups.find { it.id == gid } ?: return
        val targets = g.members.mapNotNull { userToEp[it.id] }.filter { it != fromEp && userOf(it) != origin }
        send(targets, j)
    }

    /** Removes my own messages on every phone (and for me). */
    fun deleteForEveryone(conv: String, ids: Set<String>) {
        val l = chats[conv] ?: return
        val mine = l.filter { it.id in ids && it.mine }.map { it.id }
        if (mine.isNotEmpty()) {
            val op = JSONObject().put("t", "del").put("id", UUID.randomUUID().toString())
                .put("s", myId).put("ids", JSONArray(mine))
            if (isGroup(conv)) op.put("c", conv)
            seen.add(op.getString("id"))
            sendOp(uidsFor(conv), op)
        }
        deleteMessages(conv, ids)
    }

    private fun onDelete(ep: String, j: JSONObject) {
        if (!seen.add(j.getString("id"))) return
        val s = j.getString("s")
        val c = j.optString("c", "")
        val conv = if (c.isNotEmpty()) c else s
        val a = j.getJSONArray("ids")
        val ids = (0 until a.length()).map { a.getString(it) }.toSet()
        val victims = chats[conv]?.filter { it.id in ids && it.sender == s }?.map { it.id }?.toSet() ?: emptySet()
        if (victims.isNotEmpty()) deleteMessages(conv, victims)
        if (c.isNotEmpty()) relay(c, ep, s, j)
    }

    private fun itemState(m: Msg, idx: Int): Boolean {
        val d = try { JSONObject(m.lst ?: return false).optJSONArray("d") } catch (_: Exception) { null } ?: return false
        for (k in 0 until d.length()) if (d.getInt(k) == idx) return true
        return false
    }

    private fun setItem(conv: String, msgId: String, idx: Int, v: Boolean) {
        val l = chats[conv] ?: return
        val i = l.indexOfFirst { it.id == msgId }
        if (i < 0) return
        val m = l[i]
        val src = m.lst ?: return
        try {
            val j = JSONObject(src)
            val d = j.optJSONArray("d") ?: JSONArray()
            val out = JSONArray()
            for (k in 0 until d.length()) if (d.getInt(k) != idx) out.put(d.getInt(k))
            if (v) out.put(idx)
            j.put("d", out)
            l[i] = m.copy(lst = j.toString())
            store.saveChat(conv, l.toList())
        } catch (_: Exception) {}
    }

    /** Tick / untick a shopping-list item here and on the other side(s). */
    fun toggleItem(conv: String, msgId: String, idx: Int) {
        val m = chats[conv]?.find { it.id == msgId } ?: return
        val v = !itemState(m, idx)
        setItem(conv, msgId, idx, v)
        val op = JSONObject().put("t", "lt").put("id", UUID.randomUUID().toString())
            .put("s", myId).put("m", msgId).put("i", idx).put("v", v)
        if (isGroup(conv)) op.put("c", conv)
        seen.add(op.getString("id"))
        sendOp(uidsFor(conv), op)
    }

    private fun onItemOp(ep: String, j: JSONObject) {
        if (!seen.add(j.getString("id"))) return
        val s = j.getString("s")
        val c = j.optString("c", "")
        setItem(if (c.isNotEmpty()) c else s, j.getString("m"), j.getInt("i"), j.getBoolean("v"))
        if (c.isNotEmpty()) relay(c, ep, s, j)
    }

    /** Forward messages to another chat (files are copied so deleting one copy never affects the other). */
    fun forward(msgs: List<Msg>, conv: String) {
        msgs.sortedBy { it.time }.forEach { m ->
            when {
                m.filePath != null && m.fileName != null -> forwardFile(conv, File(m.filePath), m.fileName)
                m.lst != null -> sendMsg(conv, null, m.lst, true)
                m.text != null -> sendMsg(conv, m.text, null, true)
            }
        }
    }

    private fun forwardFile(conv: String, src: File, name: String) {
        if (!canSendNow(conv)) { toast(R.string.offline); return }
        thread {
            try {
                val dest = File(store.filesDir, "${System.currentTimeMillis()}_${name.replace('/', '_')}")
                src.copyTo(dest, overwrite = true)
                main.post { dispatchFile(conv, dest, name, true) }
            } catch (_: Exception) {
                main.post { toast(R.string.connect_failed) }
            }
        }
    }

    // ----- backup / restore (keeps identity + history across reinstall) -----

    fun exportBackup(uri: Uri, done: (Boolean) -> Unit) {
        store.flush()
        thread {
            val ok = try {
                app.contentResolver.openOutputStream(uri)?.use { os ->
                    ZipOutputStream(os.buffered()).use { z ->
                        val pj = JSONObject()
                        for ((k, v) in prefs.all) {
                            val o = JSONObject()
                            when (v) {
                                is String -> o.put("t", "s").put("v", v)
                                is Int -> o.put("t", "i").put("v", v)
                                is Long -> o.put("t", "l").put("v", v)
                                is Boolean -> o.put("t", "b").put("v", v)
                                is Set<*> -> o.put("t", "ss").put("v", JSONArray(v.map { it.toString() }))
                                else -> continue
                            }
                            pj.put(k, o)
                        }
                        z.putNextEntry(ZipEntry("prefs.json"))
                        z.write(pj.toString().toByteArray(Charsets.UTF_8))
                        z.closeEntry()
                        val root = app.filesDir
                        for (sub in listOf("data", "files", "avatars")) {
                            File(root, sub).walkTopDown().filter { it.isFile }.forEach { f ->
                                z.putNextEntry(ZipEntry(f.relativeTo(root).path.replace('\\', '/')))
                                f.inputStream().use { it.copyTo(z) }
                                z.closeEntry()
                            }
                        }
                    }
                    true
                } ?: false
            } catch (_: Exception) { false }
            main.post { done(ok) }
        }
    }

    fun importBackup(uri: Uri, done: (Boolean) -> Unit) {
        thread {
            val ok = try {
                val root = app.filesDir
                val stage = File(root, "restore_tmp")
                stage.deleteRecursively()
                stage.mkdirs()
                var prefsJson: String? = null
                app.contentResolver.openInputStream(uri)?.use { ins ->
                    ZipInputStream(ins.buffered()).use { z ->
                        var e = z.nextEntry
                        while (e != null) {
                            if (!e.isDirectory) {
                                val out = File(stage, e.name).canonicalFile
                                if (!out.path.startsWith(stage.canonicalPath + File.separator)) throw SecurityException()
                                if (e.name == "prefs.json") prefsJson = String(z.readBytes(), Charsets.UTF_8)
                                else {
                                    out.parentFile?.mkdirs()
                                    out.outputStream().use { z.copyTo(it) }
                                }
                            }
                            z.closeEntry()
                            e = z.nextEntry
                        }
                    }
                }
                val pj = JSONObject(prefsJson ?: throw IllegalStateException("no prefs"))
                store.flush()
                for (sub in listOf("data", "files", "avatars")) {
                    File(root, sub).deleteRecursively()
                    val st = File(stage, sub)
                    if (st.exists()) st.renameTo(File(root, sub))
                }
                val ed = prefs.edit().clear()
                for (k in pj.keys()) {
                    val o = pj.getJSONObject(k)
                    when (o.getString("t")) {
                        "s" -> ed.putString(k, o.getString("v"))
                        "i" -> ed.putInt(k, o.getInt("v"))
                        "l" -> ed.putLong(k, o.getLong("v"))
                        "b" -> ed.putBoolean(k, o.getBoolean("v"))
                        "ss" -> {
                            val a = o.getJSONArray("v")
                            ed.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet())
                        }
                    }
                }
                ed.commit()
                stage.deleteRecursively()
                true
            } catch (_: Exception) { false }
            main.post { done(ok) }
        }
    }

    // ---------- avatar ----------

    fun setAvatar(uri: Uri) {
        thread {
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                app.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                var s = 1
                while (minOf(o.outWidth, o.outHeight) / (s * 2) >= 512) s *= 2
                val bmp = app.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
                } ?: return@thread
                val side = minOf(bmp.width, bmp.height)
                val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
                val out = Bitmap.createScaledBitmap(sq, 512, 512, true)
                store.avatarFile("me").outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 80, it) }
                main.post {
                    avatarVersion++
                    sendAvatar(null)
                }
            } catch (_: Exception) {}
        }
    }

    /** The picture is sent as a file (about 512 px) so it can be shown large in the profile. */
    private fun sendAvatar(ep: String?) {
        val f = store.avatarFile("me")
        if (!f.exists()) return
        val targets = if (ep != null) listOf(ep) else userToEp.values.toList()
        if (targets.isEmpty()) return
        val pid = UUID.randomUUID().mostSignificantBits
        val meta = JSONObject().put("t", "f").put("pid", pid).put("kind", "avatar")
            .put("s", myId).put("name", "avatar.jpg")
        targets.forEach { t -> links[t]?.let { l -> l.sendJson(meta); l.sendFile(pid, f) } }
    }

    private fun sendInfo(ep: String) {
        val dev = try { Settings.Global.getString(app.contentResolver, "device_name") } catch (_: Exception) { null }
        val model = (Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + Build.MODEL).trim()
        val ver = try { app.packageManager.getPackageInfo(app.packageName, 0).versionName } catch (_: Exception) { null }
        send(listOf(ep), JSONObject().put("t", "i").put("model", model).put("dev", dev ?: "")
            .put("os", "Android ${Build.VERSION.RELEASE}").put("app", ver ?: "").put("phone", myPhone))
    }

    private fun onInfo(ep: String, j: JSONObject) {
        val uid = userOf(ep) ?: return
        infos[uid] = j.toString()
        indexPhone(uid, j.toString())
        prefs.edit().putString("info_$uid", j.toString()).apply()
    }

    private fun onAvatar(j: JSONObject) {
        try {
            store.avatarFile(j.getString("s")).writeBytes(Base64.decode(j.getString("b"), Base64.NO_WRAP))
            avatarVersion++
        } catch (_: Exception) {}
    }

    // ---------- notifications ----------

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = app.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_MSG, str(R.string.ch_messages), NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_CALL, str(R.string.ch_calls), NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, str(R.string.ch_service), NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_SMS, str(R.string.ch_sms), NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_INCALL, str(R.string.ch_incall), NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_MISSED, str(R.string.ch_missed), NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun openIntent(conv: String?, code: Int): PendingIntent {
        val i = Intent(app, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        if (conv != null) i.putExtra("conv", conv)
        return PendingIntent.getActivity(app, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun notifyMessage(conv: String, m: Msg) {
        if (!notifOn) return
        val nm = NotificationManagerCompat.from(app)
        if (!nm.areNotificationsEnabled()) return
        val g = isGroup(conv)
        val body = (if (g) "${m.senderName}: " else "") + m.preview()
        val n = NotificationCompat.Builder(app, CH_MSG)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(title(conv)).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(openIntent(conv, conv.hashCode())).build()
        try { nm.notify(conv.hashCode(), n) } catch (_: SecurityException) {}
    }

    private fun notifyRequest(f: Found) {
        if (!notifOn) return
        val nm = NotificationManagerCompat.from(app)
        if (!nm.areNotificationsEnabled()) return
        val n = NotificationCompat.Builder(app, CH_MSG)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(str(R.string.connect_request_title))
            .setContentText(str(R.string.wants_connect, f.name)).setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setContentIntent(openIntent(null, 55)).build()
        try { nm.notify(f.ep.hashCode(), n) } catch (_: SecurityException) {}
    }

    private fun notifyCall(uid: String) {
        val nm = NotificationManagerCompat.from(app)
        val pi = openIntent(uid, 7)
        val n = NotificationCompat.Builder(app, CH_CALL)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(str(R.string.incoming_call))
            .setContentText(title(uid)).setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL).setOngoing(true)
            .setContentIntent(pi).setFullScreenIntent(pi, true).build()
        try { nm.notify(777, n) } catch (_: SecurityException) {}
    }

    private fun cancelCallNotif() = NotificationManagerCompat.from(app).cancel(777)

    // ---------- calls ----------

    private var ringtone: Ringtone? = null
    private fun ring(on: Boolean) {
        try {
            if (on) {
                ringtone = RingtoneManager.getRingtone(app, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
                ringtone?.play()
            } else {
                ringtone?.stop(); ringtone = null
            }
        } catch (_: Exception) {}
    }

    private fun sig(uid: String, k: String) {
        userToEp[uid]?.let { send(listOf(it), JSONObject().put("t", "c").put("k", k)) }
    }

    fun startCall(uid: String) {
        if (callState != CallState.IDLE || userToEp[uid] == null) return
        callPeer = uid
        callState = CallState.OUTGOING
        sig(uid, "req")
    }

    fun acceptCall() {
        val uid = callPeer ?: return
        ring(false); cancelCallNotif()
        sig(uid, "acc")
        callState = CallState.ACTIVE
        startAudio(uid)
    }

    fun endCall(notify: Boolean = true) {
        val uid = callPeer
        if (notify && uid != null && callState != CallState.IDLE) sig(uid, "end")
        ring(false); cancelCallNotif()
        stopAudio()
        callPeer = null
        callState = CallState.IDLE
    }

    private fun handleCall(ep: String, k: String) {
        val uid = userOf(ep) ?: return
        when (k) {
            "req" -> if (callState == CallState.IDLE) {
                callPeer = uid
                callState = CallState.INCOMING
                ring(true)
                if (!appVisible) notifyCall(uid)
            } else sig(uid, "end")
            "acc" -> if (callState == CallState.OUTGOING && callPeer == uid) {
                callState = CallState.ACTIVE
                startAudio(uid)
            }
            "end" -> if (callPeer == uid) endCall(notify = false)
        }
    }

    @Volatile private var audioOn = false
    @Volatile private var track: AudioTrack? = null

    private fun startAudio(uid: String) {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        @Suppress("DEPRECATION")
        am.isSpeakerphoneOn = true
        audioOn = true
        try {
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(min, 12800))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            t.play()
            track = t
        } catch (_: Exception) {}
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val link = userToEp[uid]?.let { links[it] } ?: return
        thread {
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400))
            } catch (e: Exception) { null }
            if (rec == null) return@thread
            val buf = ByteArray(1600)
            try {
                rec.startRecording()
                while (audioOn && link.open) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) link.sendAudio(buf, n)
                }
            } catch (_: Exception) {
            } finally {
                try { rec.stop() } catch (_: Exception) {}
                rec.release()
            }
        }
    }

    private fun playAudio(d: ByteArray) {
        val t = track ?: return
        if (!audioOn) return
        try { t.write(d, 0, d.size, AudioTrack.WRITE_NON_BLOCKING) } catch (_: Exception) {}
    }

    private fun stopAudio() {
        audioOn = false
        val t = track
        track = null
        try { t?.stop() } catch (_: Exception) {}
        try { t?.release() } catch (_: Exception) {}
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_NORMAL
        @Suppress("DEPRECATION")
        am.isSpeakerphoneOn = false
    }
}

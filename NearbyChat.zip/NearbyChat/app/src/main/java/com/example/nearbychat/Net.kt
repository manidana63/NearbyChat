package com.example.nearbychat

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import java.io.File
import kotlin.concurrent.thread

data class Peer(val id: String, val name: String)

data class Msg(
    val mine: Boolean,
    val text: String? = null,
    val fileName: String? = null,
    val file: File? = null,
    val time: Long = System.currentTimeMillis()
)

enum class CallState { IDLE, OUTGOING, INCOMING, ACTIVE }

/**
 * All networking lives here. Uses Google Nearby Connections, which automatically
 * picks Bluetooth / BLE / Wi-Fi (LAN, Direct, Hotspot) — no internet needed.
 */
class Net(private val app: Context) {
    private val client: ConnectionsClient = Nearby.getConnectionsClient(app)
    private val main = Handler(Looper.getMainLooper())
    private val service = "com.example.nearbychat.SERVICE"
    private val strategy = Strategy.P2P_CLUSTER
    private val rate = 16000

    var myName by mutableStateOf("")
    var running by mutableStateOf(false)
    val discovered = mutableStateListOf<Peer>()
    val connected = mutableStateListOf<Peer>()
    val chats = mutableStateMapOf<String, SnapshotStateList<Msg>>()
    var callState by mutableStateOf(CallState.IDLE)
    var callPeer by mutableStateOf<String?>(null)

    private val names = mutableMapOf<String, String>()
    private val fileNames = mutableMapOf<Long, String>()
    private val filePayloads = mutableMapOf<Long, Payload>()

    fun nameOf(id: String?): String = connected.find { it.id == id }?.name ?: names[id] ?: ""

    private fun add(id: String, m: Msg) {
        chats.getOrPut(id) { mutableStateListOf() }.add(m)
    }

    private fun toast(r: Int) = Toast.makeText(app, r, Toast.LENGTH_SHORT).show()

    // ---------- connection ----------

    fun start(name: String) {
        if (running) return
        myName = name
        client.startAdvertising(
            name, service, connCb,
            AdvertisingOptions.Builder().setStrategy(strategy).build()
        )
        client.startDiscovery(
            service, discCb,
            DiscoveryOptions.Builder().setStrategy(strategy).build()
        )
        running = true
    }

    fun stop() {
        endCall(notify = true)
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        discovered.clear()
        connected.clear()
        running = false
    }

    fun connect(id: String) {
        client.requestConnection(myName, id, connCb)
            .addOnFailureListener { toast(R.string.connect_failed) }
    }

    private val discCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            names[id] = info.endpointName
            if (connected.none { it.id == id } && discovered.none { it.id == id })
                discovered.add(Peer(id, info.endpointName))
        }

        override fun onEndpointLost(id: String) {
            discovered.removeAll { it.id == id }
        }
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            names[id] = info.endpointName
            client.acceptConnection(id, payloadCb)
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                discovered.removeAll { it.id == id }
                if (connected.none { it.id == id }) connected.add(Peer(id, names[id] ?: id))
                chats.getOrPut(id) { mutableStateListOf() }
            } else {
                toast(R.string.connect_failed)
            }
        }

        override fun onDisconnected(id: String) {
            connected.removeAll { it.id == id }
            if (callPeer == id) endCall(notify = false)
        }
    }

    // ---------- payloads ----------

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            when (p.type) {
                Payload.Type.BYTES -> handleBytes(id, String(p.asBytes() ?: return, Charsets.UTF_8))
                Payload.Type.FILE -> filePayloads[p.id] = p
                Payload.Type.STREAM -> {
                    incoming = p
                    tryPlay()
                }
            }
        }

        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {
            if (u.status == PayloadTransferUpdate.Status.SUCCESS) {
                filePayloads.remove(u.payloadId)?.let { saveFile(id, it) }
            }
        }
    }

    private fun handleBytes(id: String, s: String) {
        when {
            s.startsWith("T:") -> add(id, Msg(mine = false, text = s.substring(2)))
            s.startsWith("F:") -> {
                val rest = s.substring(2)
                val i = rest.indexOf(':')
                if (i > 0) rest.substring(0, i).toLongOrNull()?.let { fileNames[it] = rest.substring(i + 1) }
            }
            s.startsWith("C:") -> handleCall(id, s.substring(2))
        }
    }

    fun sendText(id: String, text: String) {
        if (text.isBlank()) return
        client.sendPayload(id, Payload.fromBytes("T:$text".toByteArray(Charsets.UTF_8)))
        add(id, Msg(mine = true, text = text))
    }

    fun sendFile(id: String, uri: Uri) {
        try {
            var name = "file"
            app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
            }
            val pfd = app.contentResolver.openFileDescriptor(uri, "r") ?: return
            val payload = Payload.fromFile(pfd)
            client.sendPayload(id, Payload.fromBytes("F:${payload.id}:$name".toByteArray(Charsets.UTF_8)))
            client.sendPayload(id, payload)
            add(id, Msg(mine = true, fileName = name))
        } catch (e: Exception) {
            toast(R.string.connect_failed)
        }
    }

    private fun saveFile(from: String, p: Payload) {
        val name = (fileNames.remove(p.id) ?: "file_${p.id}").replace('/', '_')
        val dir = File(app.getExternalFilesDir(null), "Received").apply { mkdirs() }
        var dest = File(dir, name)
        if (dest.exists()) dest = File(dir, "${System.currentTimeMillis()}_$name")
        val target = dest
        thread {
            try {
                val pfd = p.asFile()?.asParcelFileDescriptor() ?: return@thread
                ParcelFileDescriptor.AutoCloseInputStream(pfd).use { i ->
                    target.outputStream().use { o -> i.copyTo(o) }
                }
                main.post { add(from, Msg(mine = false, fileName = name, file = target)) }
            } catch (e: Exception) {
            }
        }
    }

    // ---------- calls ----------

    private fun sig(id: String, s: String) =
        client.sendPayload(id, Payload.fromBytes("C:$s".toByteArray()))

    fun startCall(id: String) {
        if (callState != CallState.IDLE) return
        callPeer = id
        callState = CallState.OUTGOING
        sig(id, "req")
    }

    fun acceptCall() {
        val id = callPeer ?: return
        sig(id, "acc")
        callState = CallState.ACTIVE
        startAudio(id)
    }

    fun endCall(notify: Boolean = true) {
        val id = callPeer
        if (notify && id != null && callState != CallState.IDLE) sig(id, "end")
        stopAudio()
        callPeer = null
        callState = CallState.IDLE
    }

    private fun handleCall(id: String, s: String) {
        when (s) {
            "req" -> if (callState == CallState.IDLE) {
                callPeer = id
                callState = CallState.INCOMING
            } else sig(id, "end")
            "acc" -> if (callState == CallState.OUTGOING && callPeer == id) {
                callState = CallState.ACTIVE
                startAudio(id)
            }
            "end" -> if (callPeer == id) endCall(notify = false)
        }
    }

    @Volatile private var audioOn = false
    @Volatile private var playing = false
    private var incoming: Payload? = null

    private fun startAudio(peer: String) {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        @Suppress("DEPRECATION")
        am.isSpeakerphoneOn = true
        audioOn = true
        tryPlay()

        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val pipe = ParcelFileDescriptor.createPipe()
        client.sendPayload(peer, Payload.fromStream(pipe[0]))
        val out = ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
        thread {
            val min = AudioRecord.getMinBufferSize(
                rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(min, 6400)
                )
            } catch (e: Exception) {
                null
            }
            if (rec == null) {
                try { out.close() } catch (_: Exception) {}
                return@thread
            }
            val buf = ByteArray(1600)
            try {
                rec.startRecording()
                while (audioOn) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) out.write(buf, 0, n)
                }
            } catch (_: Exception) {
            } finally {
                try { rec.stop() } catch (_: Exception) {}
                rec.release()
                try { out.close() } catch (_: Exception) {}
            }
        }
    }

    private fun tryPlay() {
        val p = incoming ?: return
        if (!audioOn || playing) return
        val stream = p.asStream() ?: return
        playing = true
        thread {
            val min = AudioTrack.getMinBufferSize(
                rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(maxOf(min, 6400))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            val buf = ByteArray(1600)
            try {
                track.play()
                val ins = stream.asInputStream()
                while (audioOn) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    if (n > 0) track.write(buf, 0, n)
                }
            } catch (_: Exception) {
            } finally {
                try { track.stop() } catch (_: Exception) {}
                track.release()
                playing = false
            }
        }
    }

    private fun stopAudio() {
        audioOn = false
        try { incoming?.close() } catch (_: Exception) {}
        incoming = null
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_NORMAL
        @Suppress("DEPRECATION")
        am.isSpeakerphoneOn = false
    }
}

package com.example.nearbychat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

data class Contact(val id: String, val name: String)
data class Member(val id: String, val name: String)
data class Group(val id: String, val name: String, val members: List<Member>, val owner: String = "") {
    val creator: String get() = owner.ifEmpty { members.firstOrNull()?.id ?: "" }
}

data class Msg(
    val id: String,
    val sender: String,
    val senderName: String,
    val mine: Boolean,
    val text: String? = null,
    val fileName: String? = null,
    val filePath: String? = null,
    val time: Long = System.currentTimeMillis(),
    val st: Int = 0,          // mine: 0 queued, 1 sent, 2 seen | received: 0 new, 1 viewed, 2 receipt sent
    val lst: String? = null   // shopping list JSON
) {
    val pending: Boolean get() = mine && st == 0
}

fun Msg.preview(): String =
    text ?: lst?.let { try { "🛒 " + JSONObject(it).optString("title") } catch (_: Exception) { "🛒" } } ?: "📎 $fileName"

/** Persistent storage: small JSON files in the app's private folder. */
class Store(ctx: Context) {
    val prefs = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    private val io = Executors.newSingleThreadExecutor()
    private val dir = File(ctx.filesDir, "data").apply { mkdirs() }
    val filesDir = File(ctx.filesDir, "files").apply { mkdirs() }
    private val avatarDir = File(ctx.filesDir, "avatars").apply { mkdirs() }

    /** Wait until all queued writes are on disk. */
    fun flush() {
        try { io.submit {}.get(3, TimeUnit.SECONDS) } catch (_: Exception) {}
    }

    fun avatarFile(id: String) = File(avatarDir, "$id.jpg")

    private fun write(name: String, text: String) {
        io.execute { try { File(dir, name).writeText(text) } catch (_: Exception) {} }
    }

    private fun read(name: String): JSONArray = try {
        val f = File(dir, name)
        if (f.exists()) JSONArray(f.readText()) else JSONArray()
    } catch (_: Exception) {
        JSONArray()
    }

    fun loadContacts(): List<Contact> = read("contacts.json").let { a ->
        (0 until a.length()).map { a.getJSONObject(it).let { o -> Contact(o.getString("i"), o.getString("n")) } }
    }

    fun saveContacts(l: List<Contact>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("i", it.id).put("n", it.name)) }
        write("contacts.json", a.toString())
    }

    fun loadGroups(): List<Group> = read("groups.json").let { a ->
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val m = o.getJSONArray("m")
            Group(o.getString("i"), o.getString("n"),
                (0 until m.length()).map { k -> m.getJSONObject(k).let { x -> Member(x.getString("i"), x.getString("n")) } },
                o.optString("o"))
        }
    }

    fun saveGroups(l: List<Group>) {
        val a = JSONArray()
        l.forEach { g ->
            val m = JSONArray()
            g.members.forEach { m.put(JSONObject().put("i", it.id).put("n", it.name)) }
            a.put(JSONObject().put("i", g.id).put("n", g.name).put("m", m).put("o", g.owner))
        }
        write("groups.json", a.toString())
    }

    fun deleteChat(conv: String) {
        io.execute { try { File(dir, "chat_$conv.json").delete() } catch (_: Exception) {} }
    }

    fun chatIds(): List<String> =
        dir.listFiles()?.map { it.name }?.filter { it.startsWith("chat_") && it.endsWith(".json") }
            ?.map { it.removePrefix("chat_").removeSuffix(".json") } ?: emptyList()

    fun loadChat(conv: String): List<Msg> = read("chat_$conv.json").let { a ->
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Msg(
                id = o.getString("i"), sender = o.getString("s"), senderName = o.optString("n"),
                mine = o.getBoolean("m"), text = o.optString("x").ifEmpty { null },
                fileName = o.optString("fn").ifEmpty { null },
                filePath = o.optString("fp").ifEmpty { null }?.let { p ->
                    if (File(p).exists()) p else File(filesDir, File(p).name).absolutePath
                },
                time = o.getLong("t"),
                st = if (o.has("st")) o.getInt("st") else if (o.getBoolean("m")) (if (o.optBoolean("p")) 0 else 1) else 2,
                lst = o.optString("l").ifEmpty { null }
            )
        }
    }

    fun saveChat(conv: String, l: List<Msg>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("i", it.id).put("s", it.sender).put("n", it.senderName).put("m", it.mine)
                .put("x", it.text ?: "").put("fn", it.fileName ?: "").put("fp", it.filePath ?: "")
                .put("t", it.time).put("st", it.st).put("l", it.lst ?: ""))
        }
        write("chat_$conv.json", a.toString())
    }
}

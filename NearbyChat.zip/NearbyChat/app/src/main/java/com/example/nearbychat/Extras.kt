package com.example.nearbychat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil

// ---------------------------------------------------------------- links and numbers inside messages

/** kind: 0 = web link, 1 = number with 4 or more digits */
data class LinkSpan(val start: Int, val end: Int, val kind: Int)

private val URL_RE = Regex("""(?i)\b((?:https?://|www\.)[^\s]+|[a-z0-9][a-z0-9-]*(?:\.[a-z0-9-]+)*\.(?:com|ir|org|net|io|app|me|co|info|dev|edu|gov)(?:/[^\s]*)?)""")
private val NUM_RE = Regex("[0-9\u06F0-\u06F9\u0660-\u0669]{4,}")

private fun trimTail(s: String): String {
    var e = s.length
    while (e > 0 && s[e - 1] in ".,;:!?)]}»\"'،؛") e--
    return s.substring(0, e)
}

fun findSpans(text: String): List<LinkSpan> {
    val out = ArrayList<LinkSpan>()
    for (m in URL_RE.findAll(text)) {
        val start = m.range.first
        if (start > 0 && text[start - 1] == '@') continue
        val t = trimTail(m.value)
        if (t.length >= 4) out.add(LinkSpan(start, start + t.length, 0))
    }
    for (m in NUM_RE.findAll(text)) {
        val s = m.range.first
        val e = m.range.last + 1
        if (out.none { it.kind == 0 && s < it.end && e > it.start }) out.add(LinkSpan(s, e, 1))
    }
    return out.sortedBy { it.start }
}

/**
 * Message text where links and long numbers can be tapped. Taps elsewhere and long presses are
 * handed back to the bubble so selecting messages still works.
 */
@Composable
fun LinkText(
    text: String, fontSize: TextUnit, color: Color, linkColor: Color, selecting: Boolean,
    onPlainTap: () -> Unit, onLong: () -> Unit, onLink: (Int, String) -> Unit
) {
    val spans = remember(text) { findSpans(text) }
    val annotated = remember(text, linkColor) {
        buildAnnotatedString {
            append(text)
            spans.forEach { addStyle(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline), it.start, it.end) }
        }
    }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val tap by rememberUpdatedState(onPlainTap)
    val long by rememberUpdatedState(onLong)
    val link by rememberUpdatedState(onLink)
    val sel by rememberUpdatedState(selecting)
    Text(
        annotated, fontSize = fontSize, color = color, onTextLayout = { layout = it },
        modifier = Modifier.pointerInput(spans) {
            detectTapGestures(
                onTap = { pos ->
                    val off = layout?.getOffsetForPosition(pos)
                    val sp = if (off != null && !sel) spans.firstOrNull { off >= it.start && off < it.end } else null
                    if (sp != null) link(sp.kind, text.substring(sp.start, sp.end)) else tap()
                },
                onLongPress = { long() }
            )
        }
    )
}

@Composable
fun LinkActionDialog(kind: Int, value: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    fun copy() {
        try { ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("text", value)) } catch (_: Exception) {}
        Toast.makeText(ctx, R.string.copied, Toast.LENGTH_SHORT).show()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(value, maxLines = 3, overflow = TextOverflow.Ellipsis, fontSize = 17.sp) },
        text = {
            Column {
                if (kind == 0) TextButton(onClick = {
                    onDismiss()
                    val u = if (value.startsWith("http", true)) value else "https://$value"
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                }) { Text("🌐  " + stringResource(R.string.open)) }
                TextButton(onClick = { onDismiss(); copy() }) { Text("📋  " + stringResource(R.string.copy)) }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

// ---------------------------------------------------------------- send timer (undo send)

@Composable
fun SendCountdown(net: Net, p: PendingSend, onCancel: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val anim = remember(p.id) {
        Animatable(((System.currentTimeMillis() - p.startedAt).toFloat() / p.ms).coerceIn(0f, 1f))
    }
    LaunchedEffect(p.id) {
        anim.animateTo(1f, tween(((1f - anim.value) * p.ms).toInt().coerceAtLeast(1), easing = LinearEasing))
    }
    val left = ceil((1f - anim.value) * p.ms / 1000f).toInt().coerceAtLeast(0)
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "⏱  " + stringResource(R.string.sending_in, net.numStr("$left")) + "  ·  " + p.text.take(24),
                Modifier.weight(1f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            TextButton(onClick = onCancel) { Text(stringResource(R.string.cancel_send), color = Color(0xFFD32F2F)) }
        }
        Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(cs.surfaceVariant)) {
            Box(Modifier.fillMaxWidth(anim.value).fillMaxHeight().background(cs.primary))
        }
    }
}

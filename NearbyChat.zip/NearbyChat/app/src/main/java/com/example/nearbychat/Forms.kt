package com.example.nearbychat

import android.Manifest
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class PhoneRow(val type: Int, val num: String)

private fun typeLabel(t: Int): Int = when (t) {
    1 -> R.string.ph_home
    3 -> R.string.ph_work
    7 -> R.string.ph_other
    else -> R.string.ph_mobile
}

private fun nextType(t: Int): Int = when (t) { 2 -> 1; 1 -> 3; 3 -> 7; else -> 2 }

@Composable
private fun FormCard(emoji: String, title: String, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = RoundedCornerShape(20.dp), color = cs.surface, shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(emoji, fontSize = 18.sp)
                Spacer(Modifier.width(8.dp))
                Text(title, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            content()
        }
    }
}

// ---------------------------------------------------------------- add / edit contact

@Composable
fun ContactFormScreen(net: Net, editId: Long, number: String, onBack: () -> Unit, onDone: (Long) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val perm = rememberPerm(Manifest.permission.WRITE_CONTACTS, Manifest.permission.READ_CONTACTS)
    var first by remember { mutableStateOf("") }
    var last by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val phones = remember { mutableStateListOf<PhoneRow>() }
    val emails = remember { mutableStateListOf<String>() }
    var photo by remember { mutableStateOf<Uri?>(null) }
    var saving by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val existingPhoto = remember(editId) { PhoneRepo.contacts.firstOrNull { it.id == editId }?.let { it.photoFull ?: it.photo } }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) photo = u }

    LaunchedEffect(editId) {
        if (editId >= 0) {
            val d = withContext(Dispatchers.IO) { PhoneRepo.loadDetail(ctx, editId) }
            if (d != null) {
                first = d.first; last = d.last; note = d.note
                phones.clear(); d.phones.forEach { phones.add(PhoneRow(it.first, it.second)) }
                emails.clear(); emails.addAll(d.emails)
            }
        }
        if (phones.isEmpty()) phones.add(PhoneRow(2, PhoneRepo.ascii(number)))
        if (emails.isEmpty()) emails.add("")
    }

    val pickedBmp = photo?.let { rememberUriBitmap(it, 300) }
    val oldBmp = if (photo == null && existingPhoto != null) rememberUriBitmap(Uri.parse(existingPhoto), 300) else null
    val bmp = pickedBmp ?: oldBmp
    val canSave = !saving && (first.isNotBlank() || last.isNotBlank() || phones.any { it.num.isNotBlank() })

    fun save() {
        if (!perm.granted) { perm.request(); return }
        saving = true
        scope.launch {
            val bytes = photo?.let { u -> withContext(Dispatchers.IO) { PhoneRepo.photoBytes(ctx, u) } }
            val form = ContactForm(
                first.trim(), last.trim(),
                phones.filter { it.num.isNotBlank() }.map { it.type to PhoneRepo.ascii(it.num).trim() },
                emails.filter { it.isNotBlank() }.map { it.trim() }, note.trim()
            )
            val res = withContext(Dispatchers.IO) { PhoneRepo.saveContact(ctx, if (editId >= 0) editId else null, form, bytes) }
            saving = false
            if (res >= 0) {
                PhoneRepo.bump()
                Toast.makeText(ctx, R.string.contact_saved, Toast.LENGTH_SHORT).show()
                onDone(res)
            } else Toast.makeText(ctx, R.string.contact_failed, Toast.LENGTH_LONG).show()
        }
    }

    Column(Modifier.fillMaxSize().background(cs.background)) {
        TopBar(stringResource(if (editId >= 0) R.string.edit_contact else R.string.new_contact), onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(116.dp).clip(CircleShape).background(cs.primaryContainer).clickable { picker.launch("image/*") },
                    contentAlignment = Alignment.Center) {
                    if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Text(first.trim().take(1).uppercase().ifEmpty { "📷" }, fontSize = 44.sp, color = cs.onPrimaryContainer)
                }
                TextButton(onClick = { picker.launch("image/*") }) { Text("📷  " + stringResource(R.string.set_photo)) }
            }

            FormCard("👤", stringResource(R.string.name_section)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = first, onValueChange = { first = it }, singleLine = true,
                        label = { Text(stringResource(R.string.first_name)) }, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = last, onValueChange = { last = it }, singleLine = true,
                        label = { Text(stringResource(R.string.last_name)) }, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f))
                }
            }

            FormCard("📞", stringResource(R.string.phones_section)) {
                phones.forEachIndexed { i, p ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.clip(RoundedCornerShape(12.dp)).background(cs.primaryContainer)
                            .clickable { phones[i] = p.copy(type = nextType(p.type)) }.padding(horizontal = 10.dp, vertical = 10.dp)) {
                            Text(stringResource(typeLabel(p.type)), fontSize = 13.sp, color = cs.onPrimaryContainer)
                        }
                        OutlinedTextField(value = p.num, onValueChange = { phones[i] = p.copy(num = it) }, singleLine = true,
                            placeholder = { Text(stringResource(R.string.number)) }, shape = RoundedCornerShape(14.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.weight(1f))
                        IconButton(onClick = { if (phones.size > 1) phones.removeAt(i) else phones[0] = PhoneRow(p.type, "") }) {
                            Icon(Icons.Filled.Close, null)
                        }
                    }
                }
                TextButton(onClick = { phones.add(PhoneRow(2, "")) }) { Text("＋  " + stringResource(R.string.add_number)) }
            }

            FormCard("✉️", stringResource(R.string.email_section)) {
                emails.forEachIndexed { i, e ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = e, onValueChange = { emails[i] = it }, singleLine = true,
                            placeholder = { Text(stringResource(R.string.email_label)) }, shape = RoundedCornerShape(14.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.weight(1f))
                        IconButton(onClick = { if (emails.size > 1) emails.removeAt(i) else emails[0] = "" }) { Icon(Icons.Filled.Close, null) }
                    }
                }
                TextButton(onClick = { emails.add("") }) { Text("＋  " + stringResource(R.string.add_email)) }
            }

            FormCard("📝", stringResource(R.string.note_section)) {
                OutlinedTextField(value = note, onValueChange = { note = it }, shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp))
            }

            if (editId >= 0) OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                Text("🗑  " + stringResource(R.string.delete_contact), color = Color(0xFFD32F2F))
            }
            Spacer(Modifier.height(8.dp))
        }
        Surface(color = cs.surface, shadowElevation = 8.dp) {
            Button(onClick = { save() }, enabled = canSave, shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(12.dp).height(52.dp)) {
                Text(stringResource(R.string.save), fontSize = 16.sp)
            }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        text = { Text(stringResource(R.string.confirm_delete_contact)) },
        confirmButton = {
            TextButton(onClick = {
                confirmDelete = false
                scope.launch {
                    val ok = withContext(Dispatchers.IO) { PhoneRepo.deleteContact(ctx, editId) }
                    PhoneRepo.bump()
                    if (ok) onDone(0L) else Toast.makeText(ctx, R.string.contact_failed, Toast.LENGTH_LONG).show()
                }
            }) { Text(stringResource(R.string.delete), color = Color(0xFFD32F2F)) }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } }
    )
}

// ---------------------------------------------------------------- contact picker

@Composable
fun ContactPickerDialog(net: Net, onPick: (String, String) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var q by remember { mutableStateOf("") }
    var list by remember { mutableStateOf(PhoneRepo.contacts) }
    LaunchedEffect(Unit) {
        if (list.isEmpty()) list = withContext(Dispatchers.IO) { PhoneRepo.loadContacts(ctx) }
    }
    val qn = PhoneRepo.norm(q)
    val shown = remember(list, q) {
        if (q.isBlank()) list else list.filter { c ->
            c.name.contains(q, true) || (qn.isNotEmpty() && c.numbers.any { PhoneRepo.norm(it).contains(qn) })
        }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.8f), shape = RoundedCornerShape(24.dp), color = cs.surface) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.pick_contact), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, shape = RoundedCornerShape(24.dp),
                    placeholder = { Text(stringResource(R.string.search)) }, modifier = Modifier.fillMaxWidth())
                LazyColumn(Modifier.weight(1f)) {
                    items(shown, key = { it.id }) { c ->
                        c.numbers.forEach { n ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onPick(c.name, n) }.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                GenericAvatar(c.name, 40.dp, c.photo)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(c.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(net.numStr(n), fontSize = 13.sp, color = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text(stringResource(R.string.cancel)) }
            }
        }
    }
}

// ---------------------------------------------------------------- new message

@Composable
fun NewSmsScreen(net: Net, to0: String, onBack: () -> Unit, nav: PhoneNav) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var to by remember { mutableStateOf(to0) }
    var picked by remember { mutableStateOf<Pair<String, String>?>(null) }
    var body by remember { mutableStateOf("") }
    var showPicker by remember { mutableStateOf(false) }
    val sims = remember { PhoneRepo.sims(ctx) }
    var slot by remember { mutableIntStateOf(if (net.simSms >= 0) net.simSms else -1) }
    val perm = rememberPerm(Manifest.permission.READ_CONTACTS)
    LaunchedEffect(perm.granted) {
        if (perm.granted && PhoneRepo.contacts.isEmpty()) withContext(Dispatchers.IO) { PhoneRepo.loadContacts(ctx) }
    }
    val target = picked?.second ?: PhoneRepo.ascii(to).trim()
    val sug = remember(to, picked, PhoneRepo.version) {
        if (picked != null || to.length < 2) emptyList<PhoneContact>() else PhoneRepo.contacts.filter { c ->
            c.name.contains(to, true) || (PhoneRepo.norm(to).isNotEmpty() && c.numbers.any { PhoneRepo.norm(it).contains(PhoneRepo.norm(to)) })
        }.take(4)
    }
    val unicode = body.any { it.code > 127 }
    val per = if (unicode) 70 else 160
    val multi = if (unicode) 67 else 153
    val parts = if (body.length <= per) 1 else (body.length + multi - 1) / multi
    val templates = listOf(R.string.tpl1, R.string.tpl2, R.string.tpl3, R.string.tpl4).map { stringResource(it) }

    fun send() {
        val subId = sims.firstOrNull { it.slot == slot }?.subId ?: -1
        if (PhoneRepo.sendSms(ctx, target, body.trim(), subId)) nav.sms(PhoneRepo.keyOf(target), target)
        else Toast.makeText(ctx, R.string.sms_failed, Toast.LENGTH_SHORT).show()
    }

    Column(Modifier.fillMaxSize().background(cs.background)) {
        TopBar(stringResource(R.string.new_message), onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            FormCard("👤", stringResource(R.string.recipient)) {
                val p = picked
                if (p != null) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(cs.primaryContainer).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        GenericAvatar(p.first, 40.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.first, fontWeight = FontWeight.Medium, color = cs.onPrimaryContainer)
                            Text(net.numStr(p.second), fontSize = 13.sp, color = cs.onPrimaryContainer.copy(alpha = 0.75f))
                        }
                        IconButton(onClick = { picked = null; to = "" }) { Icon(Icons.Filled.Close, null, tint = cs.onPrimaryContainer) }
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = to, onValueChange = { to = it }, singleLine = true, shape = RoundedCornerShape(14.dp),
                            placeholder = { Text(stringResource(R.string.to_label)) }, modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                        FilledTonalButton(onClick = { showPicker = true }, shape = RoundedCornerShape(14.dp)) { Text("👥") }
                    }
                    sug.forEach { c ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { picked = c.name to c.numbers.first() }.padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            GenericAvatar(c.name, 34.dp, c.photo)
                            Spacer(Modifier.width(10.dp))
                            Text(c.name, Modifier.weight(1f), maxLines = 1)
                            Text(net.numStr(c.numbers.first()), color = cs.onSurfaceVariant, fontSize = 13.sp)
                        }
                    }
                }
            }

            FormCard("💬", stringResource(R.string.message_section)) {
                OutlinedTextField(value = body, onValueChange = { body = it }, shape = RoundedCornerShape(14.dp),
                    placeholder = { Text(stringResource(R.string.type_message)) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp))
                Text(stringResource(R.string.chars_count, net.numStr("${body.length}"), net.numStr("$parts")),
                    fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.align(Alignment.End))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    templates.forEach { t ->
                        AssistChip(onClick = { body = (body + " " + t).trim() }, label = { Text(t) })
                    }
                }
            }

            if (sims.size >= 2) FormCard("📶", stringResource(R.string.sim_section)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    val cards = listOf(Triple(-1, stringResource(R.string.sim_default), "")) +
                        sims.map { Triple(it.slot, it.short.ifEmpty { "SIM ${it.slot + 1}" }, it.label.substringAfter(" · ", "")) }
                    cards.forEach { (sl, name, carrier) ->
                        val sel = slot == sl
                        Column(
                            Modifier.clip(RoundedCornerShape(14.dp)).background(if (sel) cs.primaryContainer else cs.surfaceVariant)
                                .clickable { slot = sl }.padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(name, fontWeight = FontWeight.Bold, color = if (sel) cs.onPrimaryContainer else cs.onSurface)
                            if (carrier.isNotBlank()) Text(carrier, fontSize = 11.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        Surface(color = cs.surface, shadowElevation = 8.dp) {
            Button(onClick = { send() }, enabled = target.isNotBlank() && body.isNotBlank(), shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(12.dp).height(52.dp)) {
                Icon(Icons.AutoMirrored.Filled.Send, null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.send), fontSize = 16.sp)
            }
        }
    }

    if (showPicker) ContactPickerDialog(net, { name, num -> picked = name to num; showPicker = false }, { showPicker = false })
}

package com.example.nearbychat

import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.provider.Telephony
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.CallScreeningService
import android.telecom.DisconnectCause
import android.telecom.InCallService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/** State shared between the in-call service (system side) and the in-call screen (UI side). */
object CallStore {
    var service: InCallService? = null
    val calls = mutableStateListOf<Call>()
    var version by mutableIntStateOf(0)
    var muted by mutableStateOf(false)
    var route by mutableIntStateOf(CallAudioState.ROUTE_EARPIECE)

    fun bump() { version++ }

    @Suppress("DEPRECATION")
    fun primary(): Call? =
        calls.firstOrNull { it.state == Call.STATE_RINGING } ?: calls.firstOrNull { it.state == Call.STATE_ACTIVE } ?: calls.firstOrNull()

    fun numberOf(c: Call): String = try { c.details.handle?.schemeSpecificPart ?: "" } catch (_: Exception) { "" }
}

/** Runs the phone calls when this app is the default phone app. */
class PhoneInCallService : InCallService() {
    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            CallStore.bump()
            if (state != Call.STATE_RINGING) NotificationManagerCompat.from(this@PhoneInCallService).cancel(RINGING_ID)
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) { CallStore.bump() }
    }

    companion object { const val RINGING_ID = 901 }

    @Suppress("DEPRECATION")
    override fun onCallAdded(call: Call) {
        CallStore.service = this
        val num = CallStore.numberOf(call)
        if (call.state == Call.STATE_RINGING && PhoneRepo.isBlockedCall(this, num)) {
            call.reject(false, null)
            PhoneRepo.logBlock(this, "call", num, "")
            return
        }
        CallStore.calls.add(call)
        call.registerCallback(cb)
        CallStore.bump()
        val ui = Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        try { startActivity(ui) } catch (_: Exception) {}
        if (call.state == Call.STATE_RINGING) {
            val net = (application as App).net
            val pi = PendingIntent.getActivity(this, 5, ui, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(this, Net.CH_INCALL).setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(net.str(R.string.incoming_call))
                .setContentText(PhoneRepo.nameFor(num) ?: num.ifBlank { net.str(R.string.unknown) })
                .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_CALL)
                .setOngoing(true).setContentIntent(pi).setFullScreenIntent(pi, true).build()
            try { NotificationManagerCompat.from(this).notify(RINGING_ID, n) } catch (_: SecurityException) {}
        }
    }

    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(cb)
        val missed = try { call.details.disconnectCause?.code == DisconnectCause.MISSED } catch (_: Exception) { false }
        val num = CallStore.numberOf(call)
        CallStore.calls.remove(call)
        CallStore.bump()
        PhoneRepo.bump()
        NotificationManagerCompat.from(this).cancel(RINGING_ID)
        if (missed) {
            val net = (application as App).net
            val pi = PendingIntent.getActivity(this, 6, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val who = PhoneRepo.nameFor(num) ?: num.ifBlank { net.str(R.string.unknown) }
            val n = NotificationCompat.Builder(this, Net.CH_MISSED).setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(net.str(R.string.missed_call)).setContentText(who)
                .setAutoCancel(true).setContentIntent(pi).setCategory(NotificationCompat.CATEGORY_MISSED_CALL).build()
            try { NotificationManagerCompat.from(this).notify(("missed" + num).hashCode(), n) } catch (_: SecurityException) {}
        }
        if (CallStore.calls.isEmpty()) CallStore.service = null
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        CallStore.muted = audioState.isMuted
        CallStore.route = audioState.route
    }
}

/** Rejects blocked callers (used when the app holds the call-screening role). */
class PhoneScreeningService : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        val num = callDetails.handle?.schemeSpecificPart ?: ""
        if (PhoneRepo.isBlockedCall(this, num)) {
            PhoneRepo.logBlock(this, "call", num, "")
            respondToCall(callDetails, CallResponse.Builder().setDisallowCall(true).setRejectCall(true).setSkipNotification(true).build())
        } else respondToCall(callDetails, CallResponse.Builder().build())
    }
}

private fun readSms(i: Intent): Map<String, String> {
    val out = LinkedHashMap<String, StringBuilder>()
    val msgs = try { Telephony.Sms.Intents.getMessagesFromIntent(i) } catch (_: Exception) { null } ?: return emptyMap()
    for (m in msgs) {
        val a = m.originatingAddress ?: continue
        out.getOrPut(a) { StringBuilder() }.append(m.messageBody ?: "")
    }
    return out.mapValues { it.value.toString() }
}

/** Incoming SMS when this app is the default SMS app: we store them ourselves. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        for ((addr, body) in readSms(i)) {
            if (PhoneRepo.isBlockedSms(c, addr)) { PhoneRepo.logBlock(c, "sms", addr, body); continue }
            try {
                val v = ContentValues()
                v.put("address", addr); v.put("body", body); v.put("date", System.currentTimeMillis()); v.put("read", 0)
                c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v)
            } catch (_: Exception) {}
            PhoneRepo.notifySms(c, addr, body)
        }
        PhoneRepo.bump()
    }
}

/** Incoming SMS when another app is the default one: only notify / hide blocked senders. */
class SmsPlainReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (PhoneRepo.isDefaultSms(c)) return
        for ((addr, body) in readSms(i)) {
            if (PhoneRepo.isBlockedSms(c, addr)) { PhoneRepo.logBlock(c, "sms", addr, body); continue }
            PhoneRepo.notifySms(c, addr, body)
        }
        PhoneRepo.bump()
    }
}

/** Required by the SMS role; MMS is not supported. */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {}
}

class RespondService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}

package com.example.nearbychat

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

sealed class Screen {
    object Setup : Screen()
    object Home : Screen()
    object Settings : Screen()
    object NewGroup : Screen()
    data class Chat(val id: String) : Screen()
}

val Accents = listOf(0xFF075E54, 0xFF1565C0, 0xFF6A1B9A, 0xFFE65100, 0xFFC2185B).map { Color(it) }

// ---------------- theme ----------------

@Composable
fun AppTheme(net: Net, content: @Composable () -> Unit) {
    val dark = when (net.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val acc = Accents[net.accent.coerceIn(0, Accents.lastIndex)]
    val cs = if (dark) darkColorScheme(
        primary = lerp(acc, Color.White, 0.45f), onPrimary = Color.Black,
        primaryContainer = lerp(acc, Color.Black, 0.3f), onPrimaryContainer = Color.White,
        background = Color(0xFF0B141A), onBackground = Color(0xFFE9EDEF),
        surface = Color(0xFF1F2C34), onSurface = Color(0xFFE9EDEF),
        surfaceVariant = Color(0xFF2A3942), onSurfaceVariant = Color(0xFFAEBAC1)
    ) else lightColorScheme(
        primary = acc, onPrimary = Color.White,
        primaryContainer = lerp(acc, Color.White, 0.8f), onPrimaryContainer = Color(0xFF111111),
        background = lerp(acc, Color.White, 0.94f), onBackground = Color(0xFF111111),
        surface = Color.White, onSurface = Color(0xFF111111),
        surfaceVariant = Color(0xFFEEEEEE), onSurfaceVariant = Color(0xFF666666)
    )
    val view = LocalView.current
    val bar = if (dark) cs.surface else cs.primary
    SideEffect {
        val w = (view.context as Activity).window
        w.statusBarColor = bar.toArgb()
        w.navigationBarColor = cs.background.toArgb()
        WindowCompat.getInsetsController(w, view).isAppearanceLightStatusBars = false
    }
    MaterialTheme(colorScheme = cs) {
        Surface(Modifier.fillMaxSize(), color = cs.background) { content() }
    }
}

@Composable
fun barColor(): Color {
    val cs = MaterialTheme.colorScheme
    return if (cs.background.luminance() < 0.5f) cs.surface else cs.primary
}

// ---------------- helpers ----------------

private val ImgExt = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")
fun isImage(name: String) = name.substringAfterLast('.', "").lowercase() in ImgExt

private fun decodeSampled(path: String, max: Int): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    var s = 1
    while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= max) s *= 2
    BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
} catch (_: Throwable) { null }

@Composable
fun rememberBitmap(path: String?, key: Int, max: Int): ImageBitmap? =
    produceState<ImageBitmap?>(null, path, key) {
        value = withContext(Dispatchers.IO) { path?.let { decodeSampled(it, max)?.asImageBitmap() } }
    }.value

@Composable
fun rememberUriBitmap(uri: Uri, max: Int): ImageBitmap? {
    val ctx = LocalContext.current
    return produceState<ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                var s = 1
                while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= max) s *= 2
                ctx.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
                }?.asImageBitmap()
            } catch (_: Throwable) { null }
        }
    }.value
}

fun openFile(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {}
}

// ---------------- shared components ----------------

@Composable
fun TopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    subtitle: String? = null,
    lead: (@Composable () -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth().background(barColor()).statusBarsPadding().height(60.dp).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
        } else Spacer(Modifier.width(12.dp))
        if (lead != null) { lead(); Spacer(Modifier.width(10.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, color = Color(0xCCFFFFFF), fontSize = 12.sp, maxLines = 1)
        }
        actions()
    }
}

@Composable
fun Avatar(net: Net, id: String, name: String, size: Dp, group: Boolean = false, online: Boolean = false) {
    val f = net.store.avatarFile(id)
    val path = if (!group && f.exists()) f.absolutePath else null
    val bmp = rememberBitmap(path, net.avatarVersion, 256)
    val bg = Color.hsv((abs(id.hashCode()) % 360).toFloat(), 0.45f, 0.72f)
    Box(Modifier.size(size)) {
        Box(Modifier.fillMaxSize().clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
            if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Text(name.trim().take(1).uppercase(), color = Color.White,
                fontSize = (size.value / 2.2f).sp, fontWeight = FontWeight.Bold)
        }
        if (online) Box(
            Modifier.size(size / 4).align(Alignment.BottomEnd).clip(CircleShape)
                .background(MaterialTheme.colorScheme.background).padding(2.dp)
                .clip(CircleShape).background(Color(0xFF25D366))
        )
    }
}

// ---------------- root / navigation ----------------

private fun depth(s: Screen) = if (s == Screen.Home || s == Screen.Setup) 0 else 1

@Composable
fun Root(
    net: Net,
    lang: String,
    onLang: (String) -> Unit,
    onProfileDone: () -> Unit,
    onCall: (String) -> Unit,
    onAccept: () -> Unit,
    onBg: (Boolean) -> Unit,
    onExit: () -> Unit,
    onRestored: () -> Unit
) {
    var screen by remember { mutableStateOf<Screen>(if (net.myName.isBlank()) Screen.Setup else Screen.Home) }
    val req = net.openRequest
    LaunchedEffect(req) {
        if (req != null && net.myName.isNotBlank()) {
            val valid = if (net.isGroup(req)) net.groups.any { it.id == req } else true
            screen = if (valid) Screen.Chat(req) else Screen.Home
            net.openRequest = null
        }
    }
    BackHandler(screen != Screen.Home && screen != Screen.Setup) { screen = Screen.Home }

    Box(Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                if (depth(targetState) > depth(initialState))
                    (slideInHorizontally { it / 3 } + fadeIn(tween(220))) togetherWith
                        (slideOutHorizontally { -it / 6 } + fadeOut(tween(160)))
                else
                    (slideInHorizontally { -it / 6 } + fadeIn(tween(220))) togetherWith
                        (slideOutHorizontally { it / 3 } + fadeOut(tween(160)))
            },
            label = "screen"
        ) { s ->
            when (s) {
                Screen.Setup -> SetupScreen(net) { screen = Screen.Home; onProfileDone() }
                Screen.Home -> Home(net,
                    onOpen = { screen = Screen.Chat(it) },
                    onSettings = { screen = Screen.Settings },
                    onNewGroup = { screen = Screen.NewGroup },
                    onExit = onExit)
                Screen.Settings -> SettingsScreen(net, lang, onLang, onBg, onExit, onRestored) { screen = Screen.Home }
                Screen.NewGroup -> NewGroupScreen(net, { screen = Screen.Home }) { screen = Screen.Chat(it) }
                is Screen.Chat -> ChatScreen(net, s.id, { screen = Screen.Home }, onCall)
            }
        }

        net.requests.firstOrNull()?.let { f ->
            AlertDialog(
                onDismissRequest = {},
                title = { Text(stringResource(R.string.app_name)) },
                text = { Text(stringResource(R.string.wants_connect, f.name)) },
                confirmButton = { TextButton(onClick = { net.acceptRequest(f) }) { Text(stringResource(R.string.accept)) } },
                dismissButton = { TextButton(onClick = { net.rejectRequest(f) }) { Text(stringResource(R.string.reject)) } }
            )
        }

        AnimatedVisibility(
            visible = net.callState != CallState.IDLE,
            enter = fadeIn() + scaleIn(initialScale = 0.92f),
            exit = fadeOut()
        ) { CallScreen(net, onAccept) }
    }
}

// ---------------- home ----------------

@Composable
fun Home(net: Net, onOpen: (String) -> Unit, onSettings: () -> Unit, onNewGroup: () -> Unit, onExit: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val cs = MaterialTheme.colorScheme
    val frac by animateFloatAsState(tab.toFloat(), tween(250), label = "tab")
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TopBar(stringResource(R.string.app_name)) {
                TextButton(onClick = onExit) { Text(stringResource(R.string.exit), color = Color.White) }
                IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, stringResource(R.string.settings), tint = Color.White) }
            }
            Row(Modifier.fillMaxWidth().background(barColor())) {
                val labels = listOf(
                    stringResource(R.string.chats),
                    stringResource(R.string.nearby) + if (net.nearby.isNotEmpty()) " (${net.nearby.size})" else ""
                )
                labels.forEachIndexed { i, l ->
                    Box(Modifier.weight(1f).clickable { tab = i }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                        Text(l, color = Color.White.copy(alpha = if (tab == i) 1f else 0.65f), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Box(Modifier.fillMaxWidth().height(3.dp).background(barColor())) {
                Box(Modifier.fillMaxWidth(0.5f).fillMaxHeight()
                    .align(BiasAlignment(-1f + 2f * frac, 0f)).background(Color.White))
            }
            if (tab == 0) ChatList(net, onOpen) else NearbyList(net)
        }
        if (tab == 0) {
            FloatingActionButton(
                onClick = onNewGroup, containerColor = cs.primary, contentColor = cs.onPrimary,
                modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
            ) { Icon(Icons.Filled.Add, stringResource(R.string.new_group)) }
        }
    }
}

@Composable
fun ChatList(net: Net, onOpen: (String) -> Unit) {
    val ids = (net.contacts.map { it.id } + net.groups.map { it.id })
        .sortedByDescending { net.chats[it]?.lastOrNull()?.time ?: 0L }
    if (ids.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Text(stringResource(R.string.no_chats), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
            items(ids, key = { it }) { id -> ConvRow(net, id) { onOpen(id) } }
        }
    }
}

@Composable
fun ConvRow(net: Net, id: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val group = net.isGroup(id)
    val last = net.chats[id]?.lastOrNull()
    val unread = net.unread[id] ?: 0
    val title = net.title(id)
    val preview = last?.let { (if (group && !it.mine) "${it.senderName}: " else "") + it.preview() } ?: ""
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(net, id, title, 52.dp, group = group, online = !group && net.online.contains(id))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontWeight = if (unread > 0) FontWeight.Bold else FontWeight.Medium)
                if (last != null) Text(fmtShort(last.time, net.calendar), fontSize = 12.sp,
                    color = if (unread > 0) cs.primary else cs.onSurfaceVariant)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(preview, Modifier.weight(1f), fontSize = 14.sp, color = cs.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (unread > 0) {
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.defaultMinSize(minWidth = 22.dp, minHeight = 22.dp).clip(CircleShape).background(cs.primary),
                        contentAlignment = Alignment.Center) {
                        Text("$unread", color = cs.onPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun NearbyList(net: Net) {
    val cs = MaterialTheme.colorScheme
    LazyColumn(Modifier.fillMaxSize()) {
        item { LinkStatus() }
        if (net.nearby.isEmpty()) item {
            Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)) {
                CircularProgressIndicator(Modifier.size(36.dp), color = cs.primary)
                Text(stringResource(R.string.searching), color = cs.onSurfaceVariant)
                Text(stringResource(R.string.hint), color = cs.onSurfaceVariant, fontSize = 13.sp)
            }
        }
        items(net.nearby, key = { it.ep }) { f ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(net, f.userId, f.name, 48.dp)
                Spacer(Modifier.width(14.dp))
                Text(f.name, Modifier.weight(1f), fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Button(onClick = { net.connect(f) }) { Text(stringResource(R.string.connect)) }
            }
        }
    }
}

@Composable
fun LinkStatus() {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var bt by remember { mutableStateOf(false) }
    var wf by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            bt = try { android.bluetooth.BluetoothAdapter.getDefaultAdapter()?.isEnabled == true } catch (_: Throwable) { false }
            wf = try {
                (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager).isWifiEnabled
            } catch (_: Throwable) { false }
            kotlinx.coroutines.delay(3000)
        }
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Bluetooth" to bt, "Wi-Fi" to wf).forEach { (n, on) ->
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp), color = cs.surfaceVariant) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).clip(CircleShape).background(if (on) Color(0xFF25D366) else Color(0xFFB0B0B0)))
                        Spacer(Modifier.width(8.dp))
                        Text(n, fontSize = 13.sp)
                    }
                }
            }
        }
        Text(stringResource(R.string.conn_hint), fontSize = 12.sp, color = cs.onSurfaceVariant)
    }
}

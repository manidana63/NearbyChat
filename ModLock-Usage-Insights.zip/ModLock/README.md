# ویترین (Vitrin) — ModLock

صفحه‌ی قفل و لانچر ماژولار برای اندروید. فارسی (راست‌چین، ارقام فارسی، تقویم شمسی) و انگلیسی.

A modular Android lock screen and launcher. Persian (RTL, Persian digits, Jalali calendar) and English.

## ساخت / Build

```bash
cd ModLock
gradle assembleDebug      # app/build/outputs/apk/debug/app-debug.apk
gradle assembleRelease    # سریع‌تر (R8)  /  faster (R8)
```

- Gradle 8.9، JDK 17، AGP 8.5.2، Kotlin 1.9.24، Compose BOM 2024.06.00
- `minSdk 26`، `targetSdk 34`
- همه‌ی بیلدها با یک کلید ثابت (`app/vitrin.keystore`) امضا می‌شن تا آپدیت روی نسخه‌ی قبلی نصب بشه و تنظیمات حفظ بشه.
  این کلید فقط برای استفاده‌ی شخصی است؛ برای انتشار عمومی کلید جدید و محرمانه بسازید و مخزن را عمومی نکنید.
- Every build is signed with the same key, so updates keep your settings. It is a personal-use key.

## ساختار / Structure (`app/src/main/java/app/modlock/`)

| بخش | فایل‌ها |
|---|---|
| هسته / core | `Modules.kt`, `Layout.kt`, `LockHost.kt`, `PageNav.kt`, `SettingsStore.kt`, `Util.kt` |
| ظاهر / look | `Appearance.kt`, `Background.kt`, `Editor.kt`, `Editors.kt`, `LaunchAnim.kt` |
| صفحه‌ها / screens | `MainActivity.kt`, `LockActivity.kt`, `HomeActivity.kt`, `HostActivity.kt`, `AnimDemoActivity.kt`, `SetBackgroundActivity.kt` |
| سرویس‌ها / services | `LockService.kt`, `BootReceiver.kt`, `MediaListener.kt`, `WidgetSupport.kt` |
| کش و پشتیبان / cache, backup | `AppCache.kt`, `Backup.kt`, `Helpers.kt` |
| ماژول‌ها / modules | `ClockModule`, `TimeModules`, `CalendarModule`+`Occasions`, `InfoModules`, `AccessModules`, `ShortcutsModule`, `AppsModule`, `AllAppsModule`, `LauncherModules`, `ContactsModule`, `NotificationsModule`, `WidgetModule`, `ToolsModules`, `PersonalModules`, `VpnModule`, `SlideUnlockModule`, `PinModule` |

ماژول‌های ثبت‌شده / registered modules (id): clock, analog, calendar, weather, battery, quick, flash, music, apps, allapps, appicon, folder, dock, contacts, notifs, widget, note, todo, alarm, timer, calc, photo, world, quote, countdown, network, vpn, slide, pin.

## افزودن ماژول / Add a module

1. فایلی بسازید و `object MyModule : LockModule { ... }` بنویسید (نمونه: `ClockModule.kt`).
2. آن را در `ModuleRegistry.all` (فایل `Modules.kt`) ثبت کنید.
3. نام و متن‌ها را در `res/values/strings.xml` و `res/values-fa/strings.xml` اضافه کنید.

راهنمای کامل در فایل‌های مستندات (Markdown / PDF) هست. توجه: مستندات قدیمی‌تر از ماژول‌ها و ویژگی‌های اخیر است (آیکن، پوشه، داک، داک روی همه‌ی صفحه‌ها، انیمیشن باز شدن، پشتیبان‌گیری، امضای ثابت).

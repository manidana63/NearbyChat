package app.modlock

import android.content.Context
import android.content.ContextWrapper
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/** Converts 0-9 to Persian digits when the language is Persian. */
fun String.localizeDigits(lang: String): String =
    if (lang != "fa") this
    else map { if (it in '0'..'9') '\u06F0' + (it - '0') else it }.joinToString("")

/** Converts Persian/Arabic digits back to ASCII digits. */
fun String.asciiDigits(): String = map { c ->
    when (c) {
        in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')
        in '\u0660'..'\u0669' -> '0' + (c - '\u0660')
        else -> c
    }
}.joinToString("")

fun hexColor(hex: String, fallback: Color = Color.White): Color =
    try {
        Color(android.graphics.Color.parseColor("#$hex"))
    } catch (e: Exception) {
        fallback
    }

private class LocalizedContext(base: Context, private val res: Resources) : ContextWrapper(base) {
    override fun getResources(): Resources = res
}

fun localizedContext(base: Context, lang: String): Context {
    val locale = Locale(lang)
    val conf = Configuration(base.resources.configuration)
    conf.setLocale(locale)
    conf.setLayoutDirection(locale)
    return LocalizedContext(base, base.createConfigurationContext(conf).resources)
}

/** Text color that follows the phone's dark/light theme. */
@Composable
fun themeFg(): Color = LocalAutoFg.current ?: if (isSystemInDarkTheme()) Color.White else Color(0xFF1B1B1F)

/** Wraps content with the app-selected language, layout direction and the phone's theme. */
@Composable
fun LocalizedTheme(store: SettingsStore, content: @Composable () -> Unit) {
    val base = LocalContext.current
    val lang = store.lang
    val dark = isSystemInDarkTheme()
    val ctx = remember(base, lang) { localizedContext(base, lang) }
    val scheme = if (Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(base) else dynamicLightColorScheme(base)
    } else {
        if (dark) darkColorScheme() else lightColorScheme()
    }
    CompositionLocalProvider(
        LocalContext provides ctx,
        LocalLayoutDirection provides if (lang == "fa") LayoutDirection.Rtl else LayoutDirection.Ltr
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

fun Drawable.toImageBitmapSafe(maxSize: Int): ImageBitmap? = try {
    var w = intrinsicWidth
    var h = intrinsicHeight
    if (w <= 0 || h <= 0) {
        w = maxSize
        h = maxSize
    }
    val scale = minOf(1f, maxSize.toFloat() / maxOf(w, h))
    toBitmap(maxOf(1, (w * scale).toInt()), maxOf(1, (h * scale).toInt())).asImageBitmap()
} catch (e: Exception) {
    null
}

/** Loads a drawable off the main thread and shows it. */
@Composable
fun AsyncIcon(
    key: Any,
    size: Int,
    modifier: Modifier,
    contentScale: ContentScale = ContentScale.Fit,
    load: () -> Drawable?
) {
    val bmp by produceState<ImageBitmap?>(null, key) {
        value = withContext(Dispatchers.IO) {
            try { load()?.toImageBitmapSafe(size) } catch (e: Exception) { null }
        }
    }
    bmp?.let { Image(it, contentDescription = null, modifier = modifier, contentScale = contentScale) }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun ChoiceRow(
    label: String,
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Column(Modifier.padding(vertical = 4.dp)) {
        if (label.isNotEmpty()) Text(label)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { (value, title) ->
                FilterChip(
                    selected = value == selected,
                    onClick = { onSelect(value) },
                    label = { Text(title) }
                )
            }
        }
    }
}

@Composable
fun PillButton(text: String, danger: Boolean = false, primary: Boolean = false, onClick: () -> Unit) {
    val bg = when {
        danger -> Color(0xFFC62828)
        primary -> Color(0xFF1E88E5)
        else -> Color(0xFF3A3F47)
    }
    Box(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}


/**
 * A Dialog that keeps the app's language and layout direction. (A plain Dialog opens a new window
 * whose context is the phone's, so its texts came out in the phone language.)
 */
@Composable
fun LocalizedDialog(
    onDismissRequest: () -> Unit,
    properties: androidx.compose.ui.window.DialogProperties = androidx.compose.ui.window.DialogProperties(),
    content: @Composable () -> Unit
) {
    val ctx = LocalContext.current
    val dir = LocalLayoutDirection.current
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismissRequest, properties = properties) {
        CompositionLocalProvider(LocalContext provides ctx, LocalLayoutDirection provides dir) { content() }
    }
}

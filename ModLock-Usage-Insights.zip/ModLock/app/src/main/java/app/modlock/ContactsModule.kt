package app.modlock

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private class ContactInfo(val id: String, val name: String, val photo: String?)

/** Favorite contacts, as a grid or carousel. Tapping can open the dialer, messages or the contact card. */
object ContactsModule : LockModule {
    override val id = "contacts"
    override val nameRes = R.string.mod_contacts
    override val category = R.string.cat_access
    override val defaultW = 0.9f
    override val defaultH = 0.2f
    override val settings: List<Setting> = shortcutSettings(
        50f,
        extra = listOf(
            ChoiceSetting(
                "tap", R.string.contacts_tap,
                listOf(
                    "dial" to R.string.tap_dial,
                    "sms" to R.string.tap_sms,
                    "card" to R.string.tap_card
                ),
                "dial"
            )
        )
    )

    private fun parse(raw: String): List<ContactInfo> = try {
        val a = JSONArray(raw)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            ContactInfo(o.getString("id"), o.getString("name"), o.optString("photo", "").ifEmpty { null })
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun serialize(list: List<ContactInfo>): String {
        val a = JSONArray()
        for (c in list) {
            a.put(JSONObject().put("id", c.id).put("name", c.name).put("photo", c.photo ?: ""))
        }
        return a.toString()
    }

    private fun queryContacts(ctx: Context): List<ContactInfo> {
        val out = mutableListOf<ContactInfo>()
        try {
            ctx.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(
                    ContactsContract.Contacts._ID,
                    ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
                    ContactsContract.Contacts.PHOTO_THUMBNAIL_URI
                ),
                null, null,
                ContactsContract.Contacts.DISPLAY_NAME_PRIMARY + " COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    out.add(ContactInfo(c.getString(0), c.getString(1) ?: "", c.getString(2)))
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun firstNumber(ctx: Context, id: String): String? = try {
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?",
            arrayOf(id), null
        )?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) {
        null
    }

    private fun intentFor(ctx: Context, id: String, tap: String): Intent {
        val card = Intent(Intent.ACTION_VIEW, Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, id))
        if (tap == "card") return card
        val number = firstNumber(ctx, id) ?: return card
        return if (tap == "sms") {
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))
        } else {
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
        }
    }

    private fun loadPhoto(ctx: Context, uri: String?): ImageBitmap? {
        if (uri == null) return null
        return try {
            ctx.contentResolver.openInputStream(Uri.parse(uri))?.use {
                BitmapFactory.decodeStream(it)?.asImageBitmap()
            }
        } catch (e: Exception) {
            null
        }
    }

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val tap = inst.s("tap", "dial")
        val raw = inst.s("items", "[]")
        val list = remember(raw, tap) {
            parse(raw).map { c ->
                ShortcutItem(
                    key = c.id,
                    label = c.name,
                    onClick = { inst.launch(intentFor(ctx, c.id, tap)) },
                    loadIcon = { loadPhoto(ctx, c.photo) },
                    cacheKey = "contact:${c.id}"
                )
            }
        }
        val shown = if (list.isEmpty() && inst.isPreview) {
            listOf(R.string.sample_p1, R.string.sample_p2, R.string.sample_p3, R.string.sample_p4)
                .map { ShortcutItem("s$it", stringResource(it), { }, { null }) }
        } else list
        ShortcutView(inst, shown, 50f)
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        val ctx = LocalContext.current
        var tick by remember { mutableIntStateOf(0) }
        val granted = remember(tick) {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) ==
                PackageManager.PERMISSION_GRANTED
        }
        if (!granted) {
            Button(onClick = { inst.host.requestContacts { tick++ } }) {
                Text(stringResource(R.string.contacts_perm))
            }
            return
        }
        var query by remember { mutableStateOf("") }
        val all = remember { queryContacts(ctx) }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text(stringResource(R.string.contacts_search)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        val selected = parse(inst.s("items", "[]"))
        val shown = all.filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }.take(60)
        for (c in shown) {
            val on = selected.any { it.id == c.id }
            val toggle = {
                val next = if (on) selected.filter { it.id != c.id } else selected + c
                inst.put("items", serialize(next))
            }
            val photo by produceState<ImageBitmap?>(null, c.id) {
                value = withContext(Dispatchers.IO) { loadPhoto(ctx, c.photo) }
            }
            Row(
                Modifier.fillMaxWidth().clickable { toggle() }.padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    val p = photo
                    if (p != null) {
                        Image(p, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } else {
                        Text(c.name.take(1))
                    }
                }
                Text(c.name, Modifier.weight(1f).padding(horizontal = 12.dp))
                Checkbox(checked = on, onCheckedChange = { toggle() })
            }
        }
    }
}

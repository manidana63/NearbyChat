package app.modlock

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

/**
 * Receives "Set as..." from the gallery and other apps (ACTION_ATTACH_DATA) and makes the image
 * or video the Vitrin background. It has no screen of its own.
 */
class SetBackgroundActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri: Uri? = intent?.data
        if (uri == null) {
            finish()
            return
        }
        val store = SettingsStore(this)
        MainScope().launch {
            importBackground(this@SetBackgroundActivity, store, uri)
            store.put("bg_source", "own")
            val msg = localizedContext(this@SetBackgroundActivity, store.lang).getString(R.string.bg_set_ok)
            Toast.makeText(this@SetBackgroundActivity, msg, Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}

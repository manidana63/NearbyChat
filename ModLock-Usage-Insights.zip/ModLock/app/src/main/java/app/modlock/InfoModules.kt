package app.modlock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.URLEncoder
import java.time.LocalDate
import kotlin.math.roundToInt

private fun percent(n: Int, lang: String): String =
    n.toString().localizeDigits(lang) + (if (lang == "fa") "\u066A" else "%")

/** Battery level and charging state. */
object BatteryModule : LockModule {
    override val id = "battery"
    override val nameRes = R.string.mod_battery
    override val category = R.string.cat_time
    override val defaultW = 0.5f
    override val defaultH = 0.08f
    override val settings: List<Setting> = listOf(
        ChoiceSetting(
            "style", R.string.batt_style,
            listOf("bar" to R.string.batt_bar, "ring" to R.string.batt_ring, "text" to R.string.batt_text),
            "bar"
        ),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val color = inst.color("color")
        val style = inst.s("style", "bar")
        val lang = inst.lang
        var level by remember { mutableIntStateOf(-1) }
        var charging by remember { mutableStateOf(false) }

        DisposableEffect(Unit) {
            val update = { i: Intent? ->
                if (i != null) {
                    val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                    if (l >= 0 && sc > 0) level = l * 100 / sc
                    val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
                        st == BatteryManager.BATTERY_STATUS_FULL
                }
            }
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context?, i: Intent?) {
                    update(i)
                }
            }
            val sticky = ContextCompat.registerReceiver(
                ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED
            )
            update(sticky)
            onDispose {
                try { ctx.unregisterReceiver(receiver) } catch (e: Exception) { }
            }
        }

        val lv = if (inst.isPreview) 76 else level.coerceAtLeast(0)
        val chg = inst.isPreview || charging
        val fill = when {
            chg -> Color(0xFF43A047)
            lv <= 15 -> Color(0xFFE53935)
            else -> color
        }
        val statusText = if (chg) stringResource(R.string.batt_charging) else ""

        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val boxW = maxWidth
            val boxH = maxHeight
            when (style) {
                "ring" -> {
                    val side = minOf(boxW, boxH)
                    Box(Modifier.size(side), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize().padding(4.dp)) {
                            val w = size.minDimension * 0.1f
                            drawArc(color.copy(alpha = 0.2f), 0f, 360f, false, style = Stroke(w))
                            drawArc(fill, -90f, 360f * lv / 100f, false, style = Stroke(w, cap = StrokeCap.Round))
                        }
                        Text(percent(lv, lang), color = color, fontSize = (side.value * 0.26f).sp, fontWeight = FontWeight.Medium)
                    }
                }

                "text" -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(percent(lv, lang), color = color, fontSize = (boxH.value * 0.5f).coerceAtLeast(12f).sp, fontWeight = FontWeight.Light)
                    if (statusText.isNotEmpty()) Text(statusText, color = fill, fontSize = (boxH.value * 0.18f).coerceAtLeast(9f).sp)
                }

                else -> Row(verticalAlignment = Alignment.CenterVertically) {
                    val fs = (boxH.value * 0.45f).coerceIn(10f, 24f).sp
                    Text(percent(lv, lang), color = color, fontSize = fs, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier
                            .weight(1f)
                            .height((boxH.value * 0.32f).coerceIn(6f, 18f).dp)
                            .clip(RoundedCornerShape(50))
                            .background(color.copy(alpha = 0.2f))
                    ) {
                        Box(
                            Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(lv / 100f)
                                .clip(RoundedCornerShape(50))
                                .background(fill)
                        )
                    }
                    if (chg) {
                        Spacer(Modifier.width(8.dp))
                        Text("\u26A1", fontSize = fs)
                    }
                }
            }
        }
    }
}

/** Connection type, Wi-Fi strength and whether the internet is reachable. */
object NetworkModule : LockModule {
    override val id = "network"
    override val nameRes = R.string.mod_network
    override val category = R.string.cat_fun
    override val defaultW = 0.5f
    override val defaultH = 0.09f
    override val settings: List<Setting> = listOf(
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val color = inst.color("color")
        var kind by remember { mutableStateOf("none") }
        var level by remember { mutableIntStateOf(0) }
        var online by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            if (inst.isPreview) {
                kind = "wifi"; level = 3; online = true
                return@LaunchedEffect
            }
            while (true) {
                try {
                    val cm = ctx.getSystemService(ConnectivityManager::class.java)
                    val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
                    kind = when {
                        caps == null -> "none"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                        else -> "other"
                    }
                    online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
                    level = if (kind == "wifi") {
                        val wm = ctx.applicationContext.getSystemService(WifiManager::class.java)
                        WifiManager.calculateSignalLevel(wm.connectionInfo.rssi, 5).coerceIn(0, 4)
                    } else 0
                } catch (e: Exception) {
                    kind = "none"
                }
                delay(2000)
            }
        }

        val label = stringResource(
            when (kind) {
                "wifi" -> R.string.net_wifi
                "mobile" -> R.string.net_mobile
                "ethernet" -> R.string.net_ethernet
                "other" -> R.string.net_other
                else -> R.string.net_none
            }
        )
        val sub = if (kind == "none") "" else stringResource(if (online) R.string.net_online else R.string.net_offline)

        BoxWithConstraints(
            Modifier.fillMaxSize().clickable(enabled = !inst.editing && !inst.isPreview) {
                inst.host.launch(
                    if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                    else Intent(Settings.ACTION_WIFI_SETTINGS)
                )
            },
            contentAlignment = Alignment.Center
        ) {
            val boxW = maxWidth
            val boxH = maxHeight
            val s = minOf(boxW.value / 200f, boxH.value / 50f).coerceIn(0.5f, 3f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (kind == "wifi") {
                    Canvas(Modifier.size((26 * s).dp)) {
                        val barW = size.width / 7f
                        for (i in 0..3) {
                            val h = size.height * (0.3f + 0.23f * i)
                            drawRoundRect(
                                if (i < level) color else color.copy(alpha = 0.25f),
                                topLeft = Offset(i * barW * 1.75f, size.height - h),
                                size = Size(barW, h),
                                cornerRadius = CornerRadius(barW / 2f)
                            )
                        }
                    }
                } else {
                    Text(if (kind == "none") "\uD83D\uDEAB" else "\uD83D\uDCF6", fontSize = (22 * s).sp)
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(label, color = color, fontSize = (16 * s).sp, fontWeight = FontWeight.Medium, maxLines = 1)
                    if (sub.isNotEmpty()) Text(sub, color = color.copy(alpha = 0.7f), fontSize = (11 * s).sp, maxLines = 1)
                }
            }
        }
    }
}

// ---------------- Weather (Open-Meteo, no key needed) ----------------

private class WxDay(val date: String, val code: Int, val max: Double, val min: Double)
private class Wx(val temp: Double, val code: Int, val humidity: Int, val days: List<WxDay>)
private class GeoHit(val name: String, val region: String, val lat: Double, val lon: Double)

private fun parseWx(raw: String): Wx? = try {
    val o = JSONObject(raw)
    val cur = o.getJSONObject("current")
    val d = o.getJSONObject("daily")
    val times = d.getJSONArray("time")
    val codes = d.getJSONArray("weather_code")
    val mx = d.getJSONArray("temperature_2m_max")
    val mn = d.getJSONArray("temperature_2m_min")
    val days = (0 until times.length()).map {
        WxDay(times.getString(it), codes.getInt(it), mx.getDouble(it), mn.getDouble(it))
    }
    Wx(cur.getDouble("temperature_2m"), cur.getInt("weather_code"), cur.getInt("relative_humidity_2m"), days)
} catch (e: Exception) {
    null
}

private fun wxLook(code: Int): Pair<String, Int> = when (code) {
    0 -> "\u2600\uFE0F" to R.string.w_clear
    1, 2 -> "\uD83C\uDF24\uFE0F" to R.string.w_partly
    45, 48 -> "\uD83C\uDF2B\uFE0F" to R.string.w_fog
    in 51..57 -> "\uD83C\uDF26\uFE0F" to R.string.w_drizzle
    in 61..67, in 80..82 -> "\uD83C\uDF27\uFE0F" to R.string.w_rain
    in 71..77, 85, 86 -> "\u2744\uFE0F" to R.string.w_snow
    in 95..99 -> "\u26C8\uFE0F" to R.string.w_storm
    else -> "\u2601\uFE0F" to R.string.w_cloudy
}

private suspend fun searchCity(q: String, lang: String): List<GeoHit> {
    val body = httpGet(
        "https://geocoding-api.open-meteo.com/v1/search?name=" +
            URLEncoder.encode(q, "UTF-8") + "&count=6&language=$lang&format=json"
    ) ?: return emptyList()
    return try {
        val arr = JSONObject(body).optJSONArray("results") ?: return emptyList()
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val region = listOf(o.optString("admin1", ""), o.optString("country", ""))
                .filter { s -> s.isNotEmpty() }.joinToString("، ")
            GeoHit(o.getString("name"), region, o.getDouble("latitude"), o.getDouble("longitude"))
        }
    } catch (e: Exception) {
        emptyList()
    }
}

/** Current weather and a short forecast for a city you pick. */
object WeatherModule : LockModule {
    override val id = "weather"
    override val nameRes = R.string.mod_weather
    override val category = R.string.cat_time
    override val defaultW = 0.88f
    override val defaultH = 0.2f
    override val settings: List<Setting> = listOf(
        ChoiceSetting("unit", R.string.w_unit, listOf("c" to R.string.w_c, "f" to R.string.w_f), "c"),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val color = inst.color("color")
        val lang = inst.lang
        val lat = inst.s("lat", "")
        val lon = inst.s("lon", "")
        val city = inst.s("city", "")
        val raw = inst.s("cache", "")
        val fahrenheit = inst.s("unit", "c") == "f"

        LaunchedEffect(lat, lon) {
            if (inst.isPreview || lat.isEmpty() || lon.isEmpty()) return@LaunchedEffect
            val age = System.currentTimeMillis() - (inst.s("cache_t", "0").toLongOrNull() ?: 0L)
            if (raw.isEmpty() || age > 30 * 60 * 1000L) {
                val body = httpGet(
                    "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                        "&current=temperature_2m,relative_humidity_2m,weather_code" +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=4"
                )
                if (body != null && parseWx(body) != null) {
                    inst.put("cache", body)
                    inst.put("cache_t", System.currentTimeMillis().toString())
                }
            }
        }

        var data = parseWx(raw)
        var shownCity = city
        if (data == null && inst.isPreview) {
            data = Wx(
                24.0, 1, 40,
                listOf(
                    WxDay(LocalDate.now().toString(), 1, 27.0, 15.0),
                    WxDay(LocalDate.now().plusDays(1).toString(), 61, 22.0, 13.0),
                    WxDay(LocalDate.now().plusDays(2).toString(), 0, 28.0, 16.0),
                    WxDay(LocalDate.now().plusDays(3).toString(), 3, 25.0, 14.0)
                )
            )
            shownCity = stringResource(R.string.w_sample_city)
        }
        val wx = data
        val weekdays = stringArrayResource(R.array.weekdays)

        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val boxW = maxWidth
            val boxH = maxHeight
            val s = minOf(boxW.value / 300f, boxH.value / 130f).coerceIn(0.5f, 3f)
            if (wx == null) {
                Text(stringResource(R.string.w_none), color = color, fontSize = (14 * s).sp)
            } else {
                fun t(c: Double): String {
                    val v = if (fahrenheit) c * 9.0 / 5.0 + 32.0 else c
                    return v.roundToInt().toString().localizeDigits(lang) + "\u00B0"
                }
                val (emoji, descRes) = wxLook(wx.code)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(emoji, fontSize = (38 * s).sp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(t(wx.temp), color = color, fontSize = (36 * s).sp, fontWeight = FontWeight.Light)
                            Text(
                                stringResource(descRes) + " \u00B7 " + stringResource(R.string.w_humidity) + " " +
                                    percent(wx.humidity, lang),
                                color = color.copy(alpha = 0.8f), fontSize = (11 * s).sp, maxLines = 1
                            )
                        }
                    }
                    if (shownCity.isNotEmpty()) {
                        Text(shownCity, color = color.copy(alpha = 0.7f), fontSize = (12 * s).sp, maxLines = 1)
                    }
                    if (boxH.value > 110f) {
                        Spacer(Modifier.height((6 * s).dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            for (d in wx.days.drop(1).take(3)) {
                                val dow = try { LocalDate.parse(d.date).dayOfWeek.value % 7 } catch (e: Exception) { 0 }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(weekdays[dow], color = color.copy(alpha = 0.7f), fontSize = (10 * s).sp, maxLines = 1)
                                    Text(wxLook(d.code).first, fontSize = (18 * s).sp)
                                    Text(t(d.max) + " / " + t(d.min), color = color, fontSize = (10 * s).sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        var q by remember { mutableStateOf("") }
        var results by remember { mutableStateOf<List<GeoHit>>(emptyList()) }
        val scope = rememberCoroutineScope()
        val current = inst.s("city", "")
        if (current.isNotEmpty()) Text(stringResource(R.string.w_selected) + ": " + current)
        OutlinedTextField(
            value = q, onValueChange = { q = it },
            label = { Text(stringResource(R.string.w_city)) },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = {
            scope.launch { results = searchCity(q.trim(), inst.lang) }
        }) { Text(stringResource(R.string.w_search)) }
        for (r in results) {
            Column(
                Modifier.fillMaxWidth().clickable {
                    inst.put("lat", r.lat.toString())
                    inst.put("lon", r.lon.toString())
                    inst.put("city", r.name)
                    inst.put("cache", "")
                    inst.put("cache_t", "0")
                    results = emptyList()
                }.padding(vertical = 8.dp)
            ) {
                Text(r.name)
                if (r.region.isNotEmpty()) Text(r.region, fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}

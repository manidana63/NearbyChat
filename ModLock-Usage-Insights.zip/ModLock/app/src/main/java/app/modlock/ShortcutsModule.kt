package app.modlock

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** One tappable entry (an app or a contact) shown by [ShortcutView]. */
class ShortcutItem(
    val key: String,
    val label: String,
    val onClick: () -> Unit,
    val loadIcon: () -> ImageBitmap?,
    val onLongClick: (() -> Unit)? = null,
    /** When set, the decoded icon is kept in [IconCache] under this key. */
    val cacheKey: String? = null,
    /** Recolors the icon (grayscale x tint) when not null. */
    val tint: Color? = null,
)

/** Grayscale image multiplied by a color: keeps the icon's detail but in one hue. */
fun tintMatrix(c: Color): ColorMatrix = ColorMatrix(
    floatArrayOf(
        0.299f * c.red, 0.587f * c.red, 0.114f * c.red, 0f, 0f,
        0.299f * c.green, 0.587f * c.green, 0.114f * c.green, 0f, 0f,
        0.299f * c.blue, 0.587f * c.blue, 0.114f * c.blue, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    )
)

/** Common settings of grid / carousel shortcut modules. */
fun shortcutSettings(defaultRadius: Float, extra: List<Setting> = emptyList()): List<Setting> =
    extra + listOf(
        ChoiceSetting(
            "layout", R.string.sc_style,
            listOf("grid" to R.string.sc_grid, "carousel" to R.string.sc_carousel), "grid"
        ),
        StepSetting("cols", R.string.sc_columns, 1, 6, 4),
        StepSetting("rows", R.string.sc_rows, 1, 6, 2),
        SliderSetting("radius", R.string.setting_radius, 0f, 50f, defaultRadius),
        SwitchSetting("labels", R.string.sc_labels, true),
        ColorSetting("color", R.string.setting_color, "auto"),
        AnimSetting,
    )

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ShortcutView(inst: ModuleInstance, list: List<ShortcutItem>, defaultRadius: Float) {
    val layout = inst.s("layout", "grid")
    val cols = (inst.s("cols", "4").toIntOrNull() ?: 4).coerceIn(1, 6)
    val rows = (inst.s("rows", "2").toIntOrNull() ?: 2).coerceIn(1, 6)
    val radius = inst.f("radius", defaultRadius).roundToInt().coerceIn(0, 50)
    val labels = inst.b("labels", true)
    val color = inst.color("color")

    if (list.isEmpty()) {
        Box(
            Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(16.dp))
                .background(color.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Text(stringResource(R.string.sc_empty), color = color, fontSize = 14.sp)
        }
        return
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        if (layout == "carousel") {
            val itemW = maxWidth / cols
            LazyRow(Modifier.fillMaxSize()) {
                items(list, key = { it.key }) { item ->
                    ShortcutCell(item, itemW, maxHeight, radius, labels, color)
                }
            }
        } else {
            val perPage = cols * rows
            val pages = (list.size + perPage - 1) / perPage
            val cellW = maxWidth / cols
            val cellH = maxHeight / rows
            val pager = rememberPagerState(pageCount = { pages })
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                Column(Modifier.fillMaxSize()) {
                    for (r in 0 until rows) {
                        Row(Modifier.fillMaxWidth().weight(1f)) {
                            for (c in 0 until cols) {
                                val idx = page * perPage + r * cols + c
                                if (idx < list.size) {
                                    ShortcutCell(list[idx], cellW, cellH, radius, labels, color)
                                } else {
                                    Spacer(Modifier.width(cellW))
                                }
                            }
                        }
                    }
                }
            }
            if (pages > 1) {
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    repeat(pages) { i ->
                        Box(
                            Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(color.copy(alpha = if (i == pager.currentPage) 0.9f else 0.35f))
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ShortcutCell(item: ShortcutItem, w: Dp, h: Dp, radius: Int, labels: Boolean, color: Color) {
    val labelH = if (labels) 16.dp else 0.dp
    val iconSize = (minOf(w, h - labelH - 6.dp) * 0.85f).coerceAtLeast(16.dp)
    val bmp by produceState<ImageBitmap?>(item.cacheKey?.let { IconCache.get(it) }, item.key) {
        if (value == null) {
            val b = withContext(Dispatchers.IO) { item.loadIcon() }
            val ck = item.cacheKey
            if (b != null && ck != null) IconCache.put(ck, b)
            value = b
        }
    }
    Column(
        Modifier.size(w, h).pointerInput(item.key) {
            detectTapGestures(onTap = { item.onClick() }, onLongPress = { item.onLongClick?.invoke() })
        },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(iconSize).clip(RoundedCornerShape(radius)),
            contentAlignment = Alignment.Center
        ) {
            val b = bmp
            if (b != null) {
                Image(
                    b, contentDescription = null, modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    colorFilter = item.tint?.let { ColorFilter.colorMatrix(tintMatrix(it)) }
                )
            } else {
                Box(
                    Modifier.fillMaxSize().background(color.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(item.label.take(1), color = color, fontSize = (iconSize.value * 0.45f).sp)
                }
            }
        }
        if (labels) {
            Text(
                item.label, color = color, fontSize = 11.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

package app.modlock

import android.net.Uri
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate

/** A photo frame that slowly changes between the photos you pick. */
object PhotoFrameModule : LockModule {
    override val id = "photo"
    override val nameRes = R.string.mod_photo
    override val category = R.string.cat_fun
    override val defaultW = 0.6f
    override val defaultH = 0.25f
    override val settings: List<Setting> = listOf(
        StepSetting("secs", R.string.pf_secs, 3, 60, 8),
        ChoiceSetting(
            "scale", R.string.pf_scale,
            listOf("crop" to R.string.pf_crop, "fit" to R.string.pf_fit), "crop"
        ),
        SliderSetting("radius", R.string.setting_radius, 0f, 40f, 14f),
    )

    private fun paths(inst: ModuleInstance): List<String> =
        inst.s("items", "").split("|").filter { it.isNotBlank() && File(it).exists() }

    @Composable
    override fun Content(inst: ModuleInstance) {
        val list = paths(inst)
        val secs = (inst.s("secs", "8").toIntOrNull() ?: 8).coerceIn(3, 60)
        val crop = inst.s("scale", "crop") == "crop"
        val radius = inst.f("radius", 14f)
        var index by remember { mutableIntStateOf(0) }
        LaunchedEffect(list.size, secs) {
            while (list.size > 1) {
                delay(secs * 1000L)
                index = (index + 1) % list.size
            }
        }
        val shape = RoundedCornerShape(radius.dp)
        if (list.isEmpty()) {
            Box(
                Modifier.fillMaxSize().clip(shape).background(
                    Brush.linearGradient(listOf(Color(0xFFFFC857), Color(0xFF7AB8FF), Color(0xFFB78CFF)))
                ),
                contentAlignment = Alignment.Center
            ) {
                Text(stringResource(R.string.pf_empty), color = Color(0xFF1B1B1F), fontSize = 13.sp)
            }
        } else {
            Crossfade(
                targetState = list[index % list.size],
                animationSpec = tween(800), label = "frame"
            ) { p ->
                val bmp by produceState<ImageBitmap?>(null, p) {
                    value = withContext(Dispatchers.IO) { decodeScaled(p, 1280) }
                }
                Box(Modifier.fillMaxSize().clip(shape)) {
                    bmp?.let {
                        Image(
                            it, null, Modifier.fillMaxSize(),
                            contentScale = if (crop) ContentScale.Crop else ContentScale.Fit
                        )
                    }
                }
            }
        }
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val scope = rememberCoroutineScope()
        val count = paths(inst).size
        Text("$count".localizeDigits(inst.lang))
        Button(onClick = {
            inst.host.pickPhotos { uris: List<Uri> ->
                scope.launch {
                    val copied = withContext(Dispatchers.IO) {
                        uris.mapNotNull { u ->
                            try {
                                val f = File(ctx.filesDir, "frame_${inst.uid}_${System.nanoTime()}.jpg")
                                ctx.contentResolver.openInputStream(u)?.use { input ->
                                    f.outputStream().use { out -> input.copyTo(out) }
                                }
                                f.absolutePath
                            } catch (e: Exception) {
                                null
                            }
                        }
                    }
                    inst.put("items", (paths(inst) + copied).joinToString("|"))
                }
            }
        }) { Text(stringResource(R.string.pf_choose)) }
        if (count > 0) {
            OutlinedButton(onClick = {
                paths(inst).forEach { File(it).delete() }
                inst.put("items", "")
            }) { Text(stringResource(R.string.pf_clear)) }
        }
    }

    override fun onRemoved(inst: ModuleInstance) {
        paths(inst).forEach { File(it).delete() }
    }
}

private val quotesFa = listOf(
    "هر روز، فرصتی تازه برای شروعی دوباره است.",
    "قدم‌های کوچک، اگر هر روز برداشته شوند، تو را به جاهای بزرگ می‌رسانند.",
    "آرامش، انتخابِ لحظه‌ی حال است.",
    "کاری را که امروز می‌توانی انجام دهی، به فردا نینداز.",
    "مهربانی، ارزان‌ترین هدیه‌ای است که می‌توانی بدهی.",
    "اشتباه کردن یعنی در حال یاد گرفتن هستی.",
    "امروز را جوری بساز که فردا از آن قدردانی کنی.",
    "یک نفس عمیق بکش؛ همه‌چیز قدم‌به‌قدم درست می‌شود.",
    "با صبر و پشتکار، کوه هم جابه‌جا می‌شود.",
    "شکرگزاری، کلید شادی است.",
    "به خودت ایمان داشته باش؛ از آنچه فکر می‌کنی تواناتری.",
    "هر پایان، آغازی دیگر است.",
    "لبخند بزن؛ دنیا را کمی روشن‌تر می‌کند.",
    "موفقیت، مجموع تلاش‌های کوچکِ روزانه است.",
    "امروز بهترین زمان برای شروع است.",
    "دل‌خوش به همین لحظه‌های ساده باش.",
)

private val quotesEn = listOf(
    "Every day is a fresh chance to begin again.",
    "Small steps, taken every day, lead to big places.",
    "Peace is choosing the present moment.",
    "Do not leave for tomorrow what you can do today.",
    "Kindness is the cheapest gift you can give.",
    "Making a mistake means you are learning.",
    "Build today so that tomorrow you will be thankful for it.",
    "Take a deep breath; things work out one step at a time.",
    "With patience and persistence, even mountains move.",
    "Gratitude is the key to happiness.",
    "Believe in yourself; you are more capable than you think.",
    "Every ending is another beginning.",
    "Smile; it makes the world a little brighter.",
    "Success is the sum of small efforts repeated daily.",
    "Today is the best day to start.",
    "Find joy in these simple moments.",
)

/** A sentence for the day. Use the built-in ones or write your own. */
object QuoteModule : LockModule {
    override val id = "quote"
    override val nameRes = R.string.mod_quote
    override val category = R.string.cat_fun
    override val defaultW = 0.84f
    override val defaultH = 0.12f
    override val settings: List<Setting> = listOf(
        ChoiceSetting(
            "mode", R.string.quote_mode,
            listOf("daily" to R.string.quote_daily, "random" to R.string.quote_random), "daily"
        ),
        SliderSetting("size", R.string.note_size, 12f, 28f, 16f),
        TextSetting("custom", R.string.quote_custom, "", multiline = true),
        TextSetting("url", R.string.quote_url, ""),
        SwitchSetting("mix", R.string.quote_mix, true),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val color = inst.color("color")
        val size = inst.f("size", 16f)
        val own = inst.s("custom", "").lines().map { it.trim() }.filter { it.isNotEmpty() }
        val url = inst.s("url", "").trim()
        val net = inst.s("net_lines", "").lines().map { it.trim() }.filter { it.isNotEmpty() }
        val mix = inst.b("mix", true)
        val builtin = if (inst.lang == "fa") quotesFa else quotesEn
        val extra = own + net
        val pool = when {
            extra.isEmpty() -> builtin
            mix -> extra + builtin
            else -> extra
        }
        // Optional online source: a text file (one sentence per line) or a JSON list. Cached for 12 hours.
        LaunchedEffect(url) {
            if (inst.isPreview || url.isEmpty()) return@LaunchedEffect
            val age = System.currentTimeMillis() - (inst.s("net_t", "0").toLongOrNull() ?: 0L)
            if (inst.s("net_lines", "").isEmpty() || age > 12 * 3600 * 1000L) {
                val body = httpGet(url)
                val lines = body?.let { parseQuoteLines(it) } ?: emptyList()
                if (lines.isNotEmpty()) {
                    inst.put("net_lines", lines.joinToString("\n"))
                    inst.put("net_t", System.currentTimeMillis().toString())
                }
            }
        }
        val daily = inst.s("mode", "daily") == "daily"
        val randomPick = remember { (0..999).random() }
        val idx = if (daily) LocalDate.now().dayOfYear else randomPick
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                pool[idx % pool.size],
                color = color, fontSize = size.sp, fontStyle = if (inst.lang == "fa") FontStyle.Normal else FontStyle.Italic,
                textAlign = TextAlign.Center
            )
        }
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        if (inst.s("url", "").isNotBlank()) {
            val n = inst.s("net_lines", "").lines().count { it.isNotBlank() }
            Text(stringResource(R.string.quote_online_count, n.toString().localizeDigits(inst.lang)))
            OutlinedButton(onClick = {
                inst.put("net_lines", "")
                inst.put("net_t", "0")
            }) { Text(stringResource(R.string.quote_refresh)) }
        }
    }
}

/** Reads sentences from plain text (one per line) or JSON (a list, or {"quotes": [...]}). */
private fun parseQuoteLines(body: String): List<String> {
    val t = body.trim()
    val out = mutableListOf<String>()
    fun fromObj(o: org.json.JSONObject) {
        for (k in listOf("quote", "q", "text", "content", "sentence", "message")) {
            val v = o.optString(k, "")
            if (v.isNotBlank()) {
                out.add(v)
                return
            }
        }
    }
    try {
        if (t.startsWith("[")) {
            val a = org.json.JSONArray(t)
            for (i in 0 until a.length()) {
                val x = a.get(i)
                if (x is String) out.add(x) else if (x is org.json.JSONObject) fromObj(x)
            }
        } else if (t.startsWith("{")) {
            val o = org.json.JSONObject(t)
            var arr: org.json.JSONArray? = null
            for (k in listOf("quotes", "data", "results", "items")) {
                arr = o.optJSONArray(k)
                if (arr != null) break
            }
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val x = arr.get(i)
                    if (x is String) out.add(x) else if (x is org.json.JSONObject) fromObj(x)
                }
            } else {
                fromObj(o)
            }
        } else {
            t.lines().forEach { out.add(it) }
        }
    } catch (e: Exception) {
        return emptyList()
    }
    return out.map { it.trim() }.filter { it.isNotEmpty() && it.length <= 220 }.take(300)
}

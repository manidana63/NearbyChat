package app.modlock

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.graphics.drawable.Drawable
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/** Lets the lock screen host Android home-screen widgets. Create it before the activity starts. */
class WidgetSupport(private val activity: ComponentActivity) {
    val manager: AppWidgetManager = AppWidgetManager.getInstance(activity)
    val host = AppWidgetHost(activity, 4242)

    private var pending: ((Boolean) -> Unit)? = null
    private val launcher = activity.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        val cb = pending
        pending = null
        cb?.invoke(r.resultCode == Activity.RESULT_OK)
    }

    fun start() {
        try { host.startListening() } catch (e: Exception) { }
    }

    fun stop() {
        try { host.stopListening() } catch (e: Exception) { }
    }

    fun providers(): List<AppWidgetProviderInfo> =
        try { manager.installedProviders } catch (e: Exception) { emptyList() }

    fun label(p: AppWidgetProviderInfo): String =
        try {
            p.loadLabel(activity.packageManager) ?: p.provider.packageName
        } catch (e: Exception) {
            p.provider.packageName
        }

    fun appLabel(p: AppWidgetProviderInfo): String =
        try {
            val pm = activity.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString()
        } catch (e: Exception) {
            p.provider.packageName
        }

    fun appIcon(p: AppWidgetProviderInfo): Drawable? =
        try {
            activity.packageManager.getApplicationIcon(p.provider.packageName)
        } catch (e: Exception) {
            try { p.loadIcon(activity, 0) } catch (e2: Exception) { null }
        }

    fun preview(p: AppWidgetProviderInfo): Drawable? =
        try { p.loadPreviewImage(activity, 0) } catch (e: Exception) { null }

    /** Allocates, binds (asking the user if needed) and configures a widget. onResult gets the id or null. */
    fun bind(provider: AppWidgetProviderInfo, onResult: (Int?) -> Unit) {
        val id = host.allocateAppWidgetId()
        if (manager.bindAppWidgetIdIfAllowed(id, provider.provider)) {
            configure(id, provider, onResult)
            return
        }
        pending = { ok ->
            if (ok) configure(id, provider, onResult) else {
                host.deleteAppWidgetId(id)
                onResult(null)
            }
        }
        val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, provider.provider)
        try {
            launcher.launch(i)
        } catch (e: Exception) {
            pending = null
            host.deleteAppWidgetId(id)
            onResult(null)
        }
    }

    private fun configure(id: Int, provider: AppWidgetProviderInfo, onResult: (Int?) -> Unit) {
        val cfg = provider.configure
        if (cfg == null) {
            onResult(id)
            return
        }
        pending = { ok ->
            if (ok) onResult(id) else {
                host.deleteAppWidgetId(id)
                onResult(null)
            }
        }
        val i = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
            .setComponent(cfg)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        try {
            launcher.launch(i)
        } catch (e: Exception) {
            pending = null
            onResult(id)
        }
    }

    fun view(id: Int): AppWidgetHostView? {
        val info = manager.getAppWidgetInfo(id) ?: return null
        return try { host.createView(activity, id, info) } catch (e: Exception) { null }
    }

    fun delete(id: Int) {
        try { host.deleteAppWidgetId(id) } catch (e: Exception) { }
    }
}

package app.modlock

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Flashlight shared by the Flashlight and Quick settings modules. */
object Torch {
    val isOn = mutableStateOf(false)
    private var registered = false
    private var cameraId: String? = null

    fun init(ctx: Context) {
        if (registered) return
        try {
            val cm = ctx.applicationContext.getSystemService(CameraManager::class.java)
            cameraId = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(id: String, enabled: Boolean) {
                    if (id == cameraId) isOn.value = enabled
                }
            }, null)
            registered = true
        } catch (e: Exception) {
        }
    }

    fun toggle(ctx: Context) {
        init(ctx)
        val id = cameraId ?: return
        try {
            ctx.applicationContext.getSystemService(CameraManager::class.java)
                .setTorchMode(id, !isOn.value)
        } catch (e: Exception) {
        }
    }
}

/** Plain HTTP GET returning the body, or null on any problem. */
suspend fun httpGet(url: String): String? = withContext(Dispatchers.IO) {
    try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.requestMethod = "GET"
        if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
    } catch (e: Exception) {
        null
    }
}

/** HH:mm for an instant, in a given time zone (24h). */
fun formatClock(millis: Long, zoneId: String? = null, h24: Boolean = true): String {
    val f = SimpleDateFormat(if (h24) "HH:mm" else "hh:mm", Locale.ENGLISH)
    if (zoneId != null) f.timeZone = java.util.TimeZone.getTimeZone(zoneId)
    return f.format(Date(millis))
}

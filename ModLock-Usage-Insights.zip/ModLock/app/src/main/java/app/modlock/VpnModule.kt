package app.modlock

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * Takes the VPN slot for a moment and gives it back, which makes Android drop whatever VPN is
 * connected. (Android allows only one VPN at a time, and an app cannot switch another app's VPN off
 * directly.)
 */
class NullVpnService : VpnService() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val pfd = Builder()
                .setSession("Vitrin")
                .addAddress("10.77.77.1", 32)
                .addRoute("10.77.77.0", 24)
                .establish()
            pfd?.close()
        } catch (e: Exception) {
        }
        stopSelf()
        return START_NOT_STICKY
    }
}

private const val WIREGUARD = "com.wireguard.android"

private fun vpnActive(ctx: Context): Boolean = try {
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
} catch (e: Exception) {
    false
}

/** One tap: switch the current VPN off, or bring your chosen VPN app back. Hold: system VPN settings. */
object VpnModule : LockModule {
    override val id = "vpn"
    override val nameRes = R.string.mod_vpn
    override val category = R.string.cat_access
    override val defaultW = 0.44f
    override val defaultH = 0.08f
    override val settings: List<Setting> = listOf(
        ColorSetting("color", R.string.setting_color, "auto"),
        AnimSetting,
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val pm = ctx.packageManager
        val color = inst.color("color")
        val pkg = inst.s("pkg", "")
        val tunnel = inst.s("wg_tunnel", "").trim()
        var active by remember { mutableStateOf(inst.isPreview) }
        val canUse = !inst.editing && !inst.isPreview

        LaunchedEffect(Unit) {
            if (inst.isPreview) return@LaunchedEffect
            while (true) {
                active = vpnActive(ctx)
                delay(1500)
            }
        }

        fun connect() {
            when {
                pkg.isBlank() -> Toast.makeText(ctx, ctx.getString(R.string.vpn_pick), Toast.LENGTH_LONG).show()
                pkg == WIREGUARD && tunnel.isNotEmpty() ->
                    ctx.sendBroadcast(
                        Intent("com.wireguard.android.action.SET_TUNNEL_UP")
                            .setPackage(WIREGUARD).putExtra("tunnel", tunnel)
                    )
                else -> pm.getLaunchIntentForPackage(pkg)?.let { inst.launch(it) }
            }
        }

        fun disconnect() {
            if (pkg == WIREGUARD && tunnel.isNotEmpty()) {
                ctx.sendBroadcast(
                    Intent("com.wireguard.android.action.SET_TUNNEL_DOWN")
                        .setPackage(WIREGUARD).putExtra("tunnel", tunnel)
                )
                return
            }
            val consent = VpnService.prepare(ctx)
            if (consent == null) {
                ctx.startService(Intent(ctx, NullVpnService::class.java))
            } else {
                Toast.makeText(ctx, ctx.getString(R.string.vpn_consent), Toast.LENGTH_LONG).show()
                inst.host.runAfterUnlock {
                    try { ctx.startActivity(consent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
                }
            }
        }

        BoxWithConstraints(
            Modifier.fillMaxSize().pointerInput(canUse, active, pkg, tunnel) {
                if (canUse) {
                    detectTapGestures(
                        onTap = { if (active) disconnect() else connect() },
                        onLongPress = { inst.host.launch(Intent(Settings.ACTION_VPN_SETTINGS)) }
                    )
                }
            },
            contentAlignment = Alignment.Center
        ) {
            val boxH = maxHeight
            val fs = (boxH.value * 0.28f).coerceIn(11f, 22f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size((boxH.value * 0.3f).coerceIn(10f, 24f).dp)
                        .clip(CircleShape)
                        .background(if (active) Color(0xFF43A047) else Color(0xFFE53935))
                )
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        stringResource(if (active) R.string.vpn_on else R.string.vpn_off),
                        color = color, fontSize = fs.sp, fontWeight = FontWeight.Medium, maxLines = 1
                    )
                    if (boxH.value > 44f) {
                        Text(
                            if (pkg.isBlank()) stringResource(R.string.vpn_pick)
                            else try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg },
                            color = color.copy(alpha = 0.7f), fontSize = (fs * 0.65f).sp, maxLines = 1
                        )
                    }
                }
            }
        }
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        var picker by remember { mutableStateOf(false) }
        Button(onClick = { picker = true }) { Text(stringResource(R.string.vpn_change)) }
        OutlinedTextField(
            value = inst.s("wg_tunnel", ""),
            onValueChange = { inst.put("wg_tunnel", it) },
            label = { Text(stringResource(R.string.vpn_wg)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text(stringResource(R.string.vpn_note), fontSize = 12.sp)
        if (picker) {
            AppPickerDialog(
                initial = setOf(inst.s("pkg", "")).filter { it.isNotBlank() }.toSet(),
                single = true,
                onDone = { inst.put("pkg", it.first()); picker = false },
                onDismiss = { picker = false }
            )
        }
    }
}

package app.modlock

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay

@Composable
private fun EditorHeader(title: String, subtitle: String, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(cs.primary, cs.tertiary))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Edit, contentDescription = null, tint = cs.onPrimary, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            if (subtitle.isNotEmpty()) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = null) }
    }
}

/** A roomy card with a big text area and a live character count. Everything is saved as you type. */
@Composable
fun NoteEditorDialog(title: String, lang: String, text: String, onText: (String) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var value by remember { mutableStateOf(text) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(200)
        try { focus.requestFocus() } catch (e: Exception) { }
    }
    LocalizedDialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.fillMaxWidth().padding(16.dp),
            shape = RoundedCornerShape(30.dp), color = cs.surface, tonalElevation = 8.dp
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                EditorHeader(
                    title,
                    stringResource(R.string.note_chars, value.length.toString().localizeDigits(lang)),
                    onDismiss
                )
                Box(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp, max = 340.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(cs.surfaceVariant.copy(alpha = 0.55f))
                        .padding(18.dp)
                ) {
                    if (value.isEmpty()) {
                        Text(
                            stringResource(R.string.note_placeholder),
                            color = cs.onSurfaceVariant.copy(alpha = 0.6f), fontSize = 18.sp
                        )
                    }
                    BasicTextField(
                        value = value,
                        onValueChange = {
                            value = it
                            onText(it)
                        },
                        textStyle = TextStyle(color = cs.onSurface, fontSize = 18.sp, lineHeight = 28.sp),
                        cursorBrush = SolidColor(cs.primary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focus)
                            .verticalScroll(rememberScrollState())
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        value = ""
                        onText("")
                    }) { Text(stringResource(R.string.note_clear)) }
                    Spacer(Modifier.weight(1f))
                    Button(onClick = onDismiss) { Text(stringResource(R.string.editor_done)) }
                }
            }
        }
    }
}

/** Add, tick and remove tasks, with a progress bar. Saved immediately. */
@Composable
fun TodoEditorDialog(
    title: String, lang: String, items: List<TodoItem>,
    onItems: (List<TodoItem>) -> Unit, onDismiss: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var draft by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(200)
        try { focus.requestFocus() } catch (e: Exception) { }
    }
    val done = items.count { it.d }
    val frac = if (items.isEmpty()) 0f else done.toFloat() / items.size

    fun add() {
        val t = draft.trim()
        if (t.isNotEmpty()) {
            onItems(items + TodoItem(t, false))
            draft = ""
        }
    }

    LocalizedDialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.fillMaxWidth().padding(16.dp),
            shape = RoundedCornerShape(30.dp), color = cs.surface, tonalElevation = 8.dp
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                EditorHeader(
                    title,
                    stringResource(
                        R.string.todo_progress,
                        done.toString().localizeDigits(lang), items.size.toString().localizeDigits(lang)
                    ),
                    onDismiss
                )
                Box(
                    Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(cs.surfaceVariant)
                ) {
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(frac)
                            .clip(RoundedCornerShape(50))
                            .background(Brush.horizontalGradient(listOf(cs.primary, cs.tertiary)))
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .background(cs.surfaceVariant.copy(alpha = 0.55f))
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                    ) {
                        if (draft.isEmpty()) {
                            Text(
                                stringResource(R.string.todo_add_hint),
                                color = cs.onSurfaceVariant.copy(alpha = 0.6f), fontSize = 16.sp
                            )
                        }
                        BasicTextField(
                            value = draft,
                            onValueChange = { draft = it },
                            singleLine = true,
                            textStyle = TextStyle(color = cs.onSurface, fontSize = 16.sp),
                            cursorBrush = SolidColor(cs.primary),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { add() }),
                            modifier = Modifier.fillMaxWidth().focusRequester(focus)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier.size(50.dp).clip(CircleShape).background(cs.primary).clickable { add() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, tint = cs.onPrimary)
                    }
                }
                Column(
                    Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (items.isEmpty()) {
                        Text(
                            stringResource(R.string.todo_empty),
                            color = cs.onSurfaceVariant, modifier = Modifier.padding(8.dp)
                        )
                    }
                    items.forEachIndexed { idx, item ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(cs.surfaceVariant.copy(alpha = 0.35f))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, cs.primary, CircleShape)
                                    .background(if (item.d) cs.primary else Color.Transparent)
                                    .clickable {
                                        onItems(items.mapIndexed { i, x -> if (i == idx) TodoItem(x.t, !x.d) else x })
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (item.d) {
                                    Icon(
                                        Icons.Filled.Check, contentDescription = null,
                                        tint = cs.onPrimary, modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Text(
                                item.t,
                                Modifier.weight(1f),
                                color = if (item.d) cs.onSurface.copy(alpha = 0.5f) else cs.onSurface,
                                textDecoration = if (item.d) TextDecoration.LineThrough else null
                            )
                            IconButton(onClick = { onItems(items.filterIndexed { i, _ -> i != idx }) }) {
                                Icon(Icons.Filled.Close, contentDescription = null, tint = cs.onSurfaceVariant)
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (done > 0) {
                        TextButton(onClick = { onItems(items.filter { !it.d }) }) {
                            Text(stringResource(R.string.todo_clear))
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Button(onClick = onDismiss) { Text(stringResource(R.string.editor_done)) }
                }
            }
        }
    }
}

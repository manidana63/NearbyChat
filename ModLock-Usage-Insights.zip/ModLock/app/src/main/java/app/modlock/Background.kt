package app.modlock

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.TileMode
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Gradient colors the user can pick for a custom gradient. */
val GradPalette = listOf(
    "1B2735", "0F2027", "2C5364", "5B2A86", "7F7FD5", "86A8E7",
    "91EAE4", "FF6B6B", "FFB347", "134E5E", "71B280", "F5F5F5"
)

private fun presetColors(name: String, dark: Boolean): List<Color> = when (name) {
    "ocean" -> if (dark) listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364))
    else listOf(Color(0xFFE0F7FA), Color(0xFFB2EBF2), Color(0xFF80DEEA))
    "sunset" -> if (dark) listOf(Color(0xFF2D1B3D), Color(0xFF8E3B5B), Color(0xFFE0794F))
    else listOf(Color(0xFFFFE0B2), Color(0xFFFFAB91), Color(0xFFF48FB1))
    "purple" -> if (dark) listOf(Color(0xFF1A1033), Color(0xFF3B2A74), Color(0xFF5B3FA8))
    else listOf(Color(0xFFEDE7F6), Color(0xFFD1C4E9), Color(0xFFB39DDB))
    "forest" -> if (dark) listOf(Color(0xFF0B1F17), Color(0xFF134E4A), Color(0xFF1F6F4A))
    else listOf(Color(0xFFE8F5E9), Color(0xFFC8E6C9), Color(0xFFA5D6A7))
    "rose" -> if (dark) listOf(Color(0xFF2A0F1A), Color(0xFF6B2142), Color(0xFFA8456B))
    else listOf(Color(0xFFFCE4EC), Color(0xFFF8BBD0), Color(0xFFF48FB1))
    else -> if (dark) listOf(Color(0xFF0A0A0A), Color(0xFF1A1A1A), Color(0xFF2A2A2A))
    else listOf(Color(0xFFFAFAFA), Color(0xFFEEEEEE), Color(0xFFE0E0E0))
}

@Composable
fun BackgroundLayer(store: SettingsStore) {
    val type = store.get("bg_type", "none")
    val path = store.get("bg_path", "")
    val exists = path.isNotEmpty() && File(path).exists()
    val dark = isSystemInDarkTheme()
    if (store.get("bg_source", "own") == "system") {
        // The real wallpaper (set by any wallpaper app) shows through the transparent window;
        // just dim it a little so text stays readable.
        Box(
            Modifier.fillMaxSize().background(
                if (dark) Color.Black.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.15f)
            )
        )
        return
    }
    Box(Modifier.fillMaxSize()) {
        if (exists && type == "image") {
            ImageBg(path)
        } else if (exists && type == "video") {
            key(path) { VideoBg(path) }
        } else {
            GradientBg(store)
        }
        if (exists && (type == "image" || type == "video")) {
            // Dim (or lighten) so text stays readable on photos and videos.
            Box(
                Modifier.fillMaxSize().background(
                    if (dark) Color.Black.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.2f)
                )
            )
        }
    }
}

@Composable
private fun GradientBg(store: SettingsStore) {
    val dark = isSystemInDarkTheme()
    val cs = MaterialTheme.colorScheme
    val style = store.get("bg_style", "vertical")
    val palette = store.get("bg_palette", "theme")
    val animate = store.getBool("bg_anim", false)
    val colors: List<Color> = when (palette) {
        "theme" -> if (dark) listOf(cs.secondaryContainer, cs.primaryContainer, cs.background)
        else listOf(cs.background, cs.primaryContainer, cs.secondaryContainer)
        "custom" -> listOf(
            hexColor(store.get("bg_c1", "5B2A86"), Color.DarkGray),
            hexColor(store.get("bg_c2", "2C5364"), Color.Black)
        )
        else -> presetColors(palette, dark)
    }
    val transition = rememberInfiniteTransition(label = "bg")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(20000, easing = LinearEasing), RepeatMode.Reverse),
        label = "phase"
    )
    Box(
        Modifier.fillMaxSize().drawBehind {
            // phase is only read when animating, so a static gradient never redraws.
            val t = if (animate) phase else 0f
            val w = size.width
            val h = size.height
            val brush = when (style) {
                "horizontal" -> Brush.horizontalGradient(
                    colors, startX = -w * 0.25f + t * w * 0.5f, endX = w + t * w * 0.5f,
                    tileMode = TileMode.Mirror
                )
                "diagonal" -> Brush.linearGradient(
                    colors,
                    start = Offset(t * w * 0.4f, t * h * 0.4f),
                    end = Offset(w + t * w * 0.4f, h + t * h * 0.4f),
                    tileMode = TileMode.Mirror
                )
                "radial" -> Brush.radialGradient(
                    colors,
                    center = Offset(w * (0.25f + 0.5f * t), h * (0.3f + 0.3f * t)),
                    radius = maxOf(w, h) * 0.9f
                )
                else -> Brush.verticalGradient(
                    colors, startY = -h * 0.2f + t * h * 0.4f, endY = h + t * h * 0.4f,
                    tileMode = TileMode.Mirror
                )
            }
            drawRect(brush)
        }
    )
}

@Composable
private fun ImageBg(path: String) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { decodeScaled(path, 1440) }
    }
    bmp?.let {
        Image(it, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

fun decodeScaled(path: String, target: Int): ImageBitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0) return null
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= target) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    return BitmapFactory.decodeFile(path, opts)?.asImageBitmap()
}

/** Video size after rotation, or null if unknown. */
private fun videoSize(path: String): Pair<Float, Float>? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(path)
        val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toFloatOrNull()
        val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toFloatOrNull()
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        if (w == null || h == null) null
        else if (rot == 90 || rot == 270) Pair(h, w) else Pair(w, h)
    } catch (e: Exception) {
        null
    } finally {
        try { r.release() } catch (e: Exception) { }
    }
}

/** A muted, looping video that is center-cropped to fill the view (same in every language). */
private class VideoTextureView(
    ctx: Context,
    private val path: String,
    private val vw: Float,
    private val vh: Float
) : TextureView(ctx), TextureView.SurfaceTextureListener {

    private var player: MediaPlayer? = null

    init {
        surfaceTextureListener = this
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
        try {
            val p = MediaPlayer()
            p.setSurface(Surface(st))
            p.setDataSource(path)
            p.isLooping = true
            p.setVolume(0f, 0f)
            p.setOnPreparedListener { it.start() }
            p.prepareAsync()
            player = p
        } catch (e: Exception) {
        }
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        try { player?.release() } catch (e: Exception) { }
        player = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applyCrop(w, h)
    }

    private fun applyCrop(w: Int, h: Int) {
        if (vw <= 0f || vh <= 0f || w == 0 || h == 0) return
        val viewAspect = w.toFloat() / h
        val videoAspect = vw / vh
        val m = Matrix()
        if (videoAspect > viewAspect) {
            m.setScale(videoAspect / viewAspect, 1f, w / 2f, h / 2f)
        } else {
            m.setScale(1f, viewAspect / videoAspect, w / 2f, h / 2f)
        }
        setTransform(m)
    }
}

@Composable
private fun VideoBg(path: String) {
    val size = remember(path) { videoSize(path) }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx -> VideoTextureView(ctx, path, size?.first ?: 0f, size?.second ?: 0f) }
    )
}

/** Copies the picked image/video into app storage and makes it the background. Call from the main thread. */
suspend fun importBackground(ctx: Context, store: SettingsStore, uri: Uri) {
    val isVideo = (ctx.contentResolver.getType(uri) ?: "").startsWith("video")
    val dest = withContext(Dispatchers.IO) {
        val f = File(ctx.filesDir, "bg_${System.currentTimeMillis()}.${if (isVideo) "mp4" else "img"}")
        try {
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                f.outputStream().use { out -> input.copyTo(out) }
            }
            f
        } catch (e: Exception) {
            null
        }
    } ?: return
    val old = store.get("bg_path", "")
    if (old.isNotEmpty()) File(old).delete()
    store.put("bg_path", dest.absolutePath)
    store.put("bg_type", if (isVideo) "video" else "image")
}

fun removeBackground(store: SettingsStore) {
    val old = store.get("bg_path", "")
    if (old.isNotEmpty()) File(old).delete()
    store.put("bg_path", "")
    store.put("bg_type", "none")
}

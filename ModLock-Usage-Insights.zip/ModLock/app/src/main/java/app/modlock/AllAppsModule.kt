package app.modlock

import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private val IndexAccent = Color(0xFF7C6CFF)

class AppEntry(val pkg: String, val label: String, val letter: String)
private class ListRow(val letter: String, val app: AppEntry?)

// ---------- alphabet (Persian + English) ----------

private val faLetters = listOf(
    "ا", "ب", "پ", "ت", "ث", "ج", "چ", "ح", "خ", "د", "ذ", "ر", "ز", "ژ", "س", "ش",
    "ص", "ض", "ط", "ظ", "ع", "غ", "ف", "ق", "ک", "گ", "ل", "م", "ن", "و", "ه", "ی"
)
private val latinLetters = ('A'..'Z').map { it.toString() }

private fun letterOf(label: String): String {
    val c = label.trim().firstOrNull() ?: return "#"
    return when {
        c in 'A'..'Z' || c in 'a'..'z' -> c.uppercaseChar().toString()
        c == '\u0622' || c == '\u0623' || c == '\u0625' -> "ا"
        c == '\u0643' -> "ک"
        c == '\u064A' || c == '\u0649' -> "ی"
        c in '\u0600'..'\u06FF' -> if (c.toString() in faLetters) c.toString() else "#"
        else -> "#"
    }
}

/** Persian first when the app is in Persian, otherwise English first. */
private fun letterOrder(lang: String): List<String> =
    (if (lang == "fa") faLetters + latinLetters else latinLetters + faLetters) + "#"

// ---------- permissions ----------

private class PermGroup(val labelRes: Int, val emoji: String, val perms: List<String>)

private val permGroups = listOf(
    PermGroup(R.string.perm_g_camera, "\uD83D\uDCF7", listOf("android.permission.CAMERA")),
    PermGroup(R.string.perm_g_mic, "\uD83C\uDFA4", listOf("android.permission.RECORD_AUDIO")),
    PermGroup(
        R.string.perm_g_location, "\uD83D\uDCCD",
        listOf(
            "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_BACKGROUND_LOCATION"
        )
    ),
    PermGroup(
        R.string.perm_g_contacts, "\uD83D\uDC64",
        listOf("android.permission.READ_CONTACTS", "android.permission.WRITE_CONTACTS", "android.permission.GET_ACCOUNTS")
    ),
    PermGroup(
        R.string.perm_g_calendar, "\uD83D\uDCC5",
        listOf("android.permission.READ_CALENDAR", "android.permission.WRITE_CALENDAR")
    ),
    PermGroup(
        R.string.perm_g_sms, "\uD83D\uDCAC",
        listOf(
            "android.permission.READ_SMS", "android.permission.SEND_SMS", "android.permission.RECEIVE_SMS",
            "android.permission.RECEIVE_MMS", "android.permission.RECEIVE_WAP_PUSH"
        )
    ),
    PermGroup(
        R.string.perm_g_phone, "\uD83D\uDCDE",
        listOf(
            "android.permission.READ_PHONE_STATE", "android.permission.CALL_PHONE",
            "android.permission.READ_CALL_LOG", "android.permission.WRITE_CALL_LOG",
            "android.permission.ANSWER_PHONE_CALLS", "android.permission.READ_PHONE_NUMBERS"
        )
    ),
    PermGroup(
        R.string.perm_g_storage, "\uD83D\uDDC2\uFE0F",
        listOf(
            "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO",
            "android.permission.READ_MEDIA_AUDIO", "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"
        )
    ),
    PermGroup(
        R.string.perm_g_sensors, "\u2764\uFE0F",
        listOf("android.permission.BODY_SENSORS", "android.permission.ACTIVITY_RECOGNITION")
    ),
    PermGroup(R.string.perm_g_notif, "\uD83D\uDD14", listOf("android.permission.POST_NOTIFICATIONS")),
    PermGroup(
        R.string.perm_g_nearby, "\uD83D\uDCE1",
        listOf(
            "android.permission.BLUETOOTH_SCAN", "android.permission.BLUETOOTH_CONNECT",
            "android.permission.BLUETOOTH_ADVERTISE", "android.permission.NEARBY_WIFI_DEVICES"
        )
    ),
)

/** For each group the app asks for: 2 = all allowed, 1 = some allowed, 0 = denied. */
private fun permissionStates(pm: PackageManager, pkg: String): List<Pair<PermGroup, Int>> = try {
    val info = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
    val req: Array<String> = info.requestedPermissions ?: emptyArray()
    val flags: IntArray = info.requestedPermissionsFlags ?: IntArray(0)
    permGroups.mapNotNull { g ->
        val idx = g.perms.mapNotNull { p -> req.indexOf(p).takeIf { it >= 0 } }
        if (idx.isEmpty()) {
            null
        } else {
            val granted = idx.count { i ->
                i < flags.size && (flags[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
            }
            g to (if (granted == idx.size) 2 else if (granted == 0) 0 else 1)
        }
    }
} catch (e: Exception) {
    emptyList()
}

private fun detailsIntent(pkg: String) =
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))

private val IconTints = listOf("FFFFFF", "FFEB3B", "4DD0E1", "81C784", "FFB74D", "F48FB1", "B39DDB", "90CAF9", "000000")

/**
 * The app drawer: every app on the phone with search, three layouts (grid, rows, names only),
 * an A-Z / Persian alphabet index you can drag, a long-press menu per app, and page hand-off:
 * when the list reaches its end, dragging further changes the page.
 */
object AllAppsModule : LockModule {
    override val id = "allapps"
    override val nameRes = R.string.mod_allapps
    override val category = R.string.cat_access
    override val defaultW = 0.92f
    override val defaultH = 0.8f
    override val settings: List<Setting> = listOf(
        ChoiceSetting(
            "layout", R.string.apps_layout,
            listOf("grid" to R.string.sc_grid, "list" to R.string.lay_list, "names" to R.string.lay_names), "grid"
        ),
        StepSetting("cols", R.string.sc_columns, 2, 6, 4),
        SliderSetting("radius", R.string.setting_radius, 0f, 50f, 26f),
        SwitchSetting("labels", R.string.sc_labels, true),
        SwitchSetting("index", R.string.apps_index, true),
        SwitchSetting("headers", R.string.apps_headers, true),
        ChoiceSetting(
            "sort", R.string.apps_sort,
            listOf("alpha" to R.string.sort_alpha, "used" to R.string.sort_used), "alpha"
        ),
        SwitchSetting("tint_all", R.string.apps_tint_all, false),
        ColorSetting("tint_color", R.string.setting_color, "auto"),
        ColorSetting("color", R.string.setting_color, "auto"),
        AnimSetting,
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val pm = ctx.packageManager
        val host = inst.host
        val color = inst.color("color")
        val lang = inst.lang
        val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
        val layoutMode = inst.s("layout", "grid")
        val cols = (inst.s("cols", "4").toIntOrNull() ?: 4).coerceIn(2, 6)
        val radius = inst.f("radius", 26f).roundToInt().coerceIn(0, 50)
        val labels = inst.b("labels", true)
        val showIndex = inst.b("index", true)
        val headers = inst.b("headers", true)
        val sortUsed = inst.s("sort", "alpha") == "used"
        val tintAll = inst.b("tint_all", false)
        val tintAllColor = inst.color("tint_color")
        val spec = rememberPanelSpec(host.store, if (inst.grouped) "none" else inst.s("style", "global"))
        val searchRadius = minOf(spec.radius, 22f).dp
        val scope = rememberCoroutineScope()
        val actions = LocalLauncherActions.current

        var q by remember { mutableStateOf("") }
        var menuApp by remember { mutableStateOf<AppEntry?>(null) }
        var permApp by remember { mutableStateOf<AppEntry?>(null) }

        // Loaded once in the background and cached; the drawer opens at once the next time.
        val all by produceState(AppsCache.peek() ?: emptyList(), ctx) {
            value = withContext(Dispatchers.Default) { AppsCache.load(ctx) }
        }
        val hidden = inst.s("hidden", "").split("|").filter { it.isNotBlank() }.toSet()
        val order = remember(lang) { letterOrder(lang) }
        val collator = remember(lang) { Collator.getInstance(Locale(lang)) }
        val base = remember(all, hidden, lang) {
            all.filter { it.first !in hidden }
                .map { AppEntry(it.first, it.second, letterOf(it.second)) }
                .sortedWith(Comparator<AppEntry> { a, b ->
                    val ia = order.indexOf(a.letter)
                    val ib = order.indexOf(b.letter)
                    if (ia != ib) ia.compareTo(ib) else collator.compare(a.label, b.label)
                })
        }
        val searched = if (q.isBlank()) base else base.filter {
            it.label.contains(q, ignoreCase = true) || it.pkg.contains(q, ignoreCase = true)
        }
        val sorted = if (sortUsed) {
            searched.sortedByDescending { inst.s("use_${it.pkg}", "0").toIntOrNull() ?: 0 }
        } else {
            searched
        }
        val shown = if (inst.isPreview) sorted.take(14) else sorted
        val useIndex = showIndex && !sortUsed && q.isBlank()
        val useHeaders = headers && !sortUsed && layoutMode != "grid"
        val rows = remember(shown, useHeaders) {
            buildList {
                var last = ""
                for (e in shown) {
                    if (useHeaders && e.letter != last) {
                        add(ListRow(e.letter, null))
                        last = e.letter
                    }
                    add(ListRow(e.letter, e))
                }
            }
        }
        val indexOfLetter = remember(shown, rows, layoutMode) {
            val m = LinkedHashMap<String, Int>()
            if (layoutMode == "grid") {
                shown.forEachIndexed { i, e -> if (!m.containsKey(e.letter)) m[e.letter] = i }
            } else {
                rows.forEachIndexed { i, r -> if (!m.containsKey(r.letter)) m[r.letter] = i }
            }
            m
        }
        val indexLetters = indexOfLetter.keys.toList()

        val listState = rememberLazyListState()
        val gridState = rememberLazyGridState()
        val firstIdx by remember(layoutMode) {
            derivedStateOf {
                if (layoutMode == "grid") gridState.firstVisibleItemIndex else listState.firstVisibleItemIndex
            }
        }
        val currentLetter = if (layoutMode == "grid") shown.getOrNull(firstIdx)?.letter else rows.getOrNull(firstIdx)?.letter
        val pick: (String) -> Unit = { letter ->
            val i = indexOfLetter[letter]
            if (i != null) {
                scope.launch {
                    if (layoutMode == "grid") gridState.scrollToItem(i) else listState.scrollToItem(i)
                }
            }
        }

        fun openApp(e: AppEntry) {
            val intent = pm.getLaunchIntentForPackage(e.pkg) ?: return
            val n = (inst.s("use_${e.pkg}", "0").toIntOrNull() ?: 0) + 1
            inst.put("use_${e.pkg}", n.toString())
            inst.launch(intent)
        }

        fun tintFor(e: AppEntry): Color? {
            val v = inst.s("tint_${e.pkg}", "")
            return if (v.isNotEmpty()) hexColor(v) else if (tintAll) tintAllColor else null
        }

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val boxW = maxWidth
            Column(Modifier.fillMaxSize()) {
                SearchField(q, { q = it }, color, searchRadius, stringResource(R.string.apps_search))
                Spacer(Modifier.height(8.dp))
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    val endPad = if (useIndex && indexLetters.size > 1) 30.dp else 0.dp
                    when (layoutMode) {
                        "list" -> LazyColumn(
                            Modifier.fillMaxSize().edgePageDrag(true, { !listState.canScrollBackward }, { !listState.canScrollForward }),
                            state = listState,
                            contentPadding = PaddingValues(end = endPad)
                        ) {
                            items(rows, key = { it.app?.pkg ?: ("h" + it.letter) }) { r ->
                                val e = r.app
                                if (e == null) {
                                    Text(
                                        r.letter, color = IndexAccent, fontSize = 13.sp,
                                        modifier = Modifier.padding(start = 6.dp, top = 10.dp, bottom = 2.dp)
                                    )
                                } else {
                                    AppListRow(e, color, tintFor(e), radius, { openApp(e) }, { menuApp = e }, showIcon = true)
                                }
                            }
                        }

                        "names" -> LazyColumn(
                            Modifier.fillMaxSize().edgePageDrag(true, { !listState.canScrollBackward }, { !listState.canScrollForward }),
                            state = listState,
                            contentPadding = PaddingValues(end = endPad)
                        ) {
                            items(rows, key = { it.app?.pkg ?: ("h" + it.letter) }) { r ->
                                val e = r.app
                                if (e == null) {
                                    Text(
                                        r.letter, color = IndexAccent, fontSize = 13.sp,
                                        modifier = Modifier.padding(start = 8.dp, top = 12.dp, bottom = 2.dp)
                                    )
                                } else {
                                    AppListRow(e, color, null, radius, { openApp(e) }, { menuApp = e }, showIcon = false)
                                }
                            }
                        }

                        else -> {
                            val cellW = (boxW - endPad) / cols
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(cols), state = gridState,
                                modifier = Modifier.fillMaxSize()
                                    .edgePageDrag(true, { !gridState.canScrollBackward }, { !gridState.canScrollForward }),
                                contentPadding = PaddingValues(end = endPad)
                            ) {
                                items(shown, key = { it.pkg }) { e ->
                                    ShortcutCell(
                                        ShortcutItem(
                                            key = e.pkg,
                                            label = e.label,
                                            onClick = { openApp(e) },
                                            loadIcon = { IconCache.appIcon(pm, e.pkg) },
                                            cacheKey = "app:${e.pkg}",
                                            onLongClick = { menuApp = e },
                                            tint = tintFor(e)
                                        ),
                                        cellW, cellW * 1.1f, radius, labels, color
                                    )
                                }
                            }
                        }
                    }
                    if (useIndex && indexLetters.size > 1) {
                        LetterIndex(
                            indexLetters, currentLetter ?: "", color, rtl,
                            Modifier.align(Alignment.CenterEnd), pick
                        )
                    }
                }
            }
        }

        val m = menuApp
        if (m != null) {
            AppMenuDialog(
                app = m, inst = inst, tintNow = inst.s("tint_${m.pkg}", ""),
                onDismiss = { menuApp = null },
                onPermissions = { permApp = m; menuApp = null },
                onHide = {
                    inst.put("hidden", (hidden + m.pkg).joinToString("|"))
                    menuApp = null
                },
                onAddToMain = actions?.let { a -> { a.addIcon(m.pkg); menuApp = null } }
            )
        }
        val pa = permApp
        if (pa != null) {
            PermissionsDialog(pa, host) { permApp = null }
        }
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        val hiddenCount = inst.s("hidden", "").split("|").count { it.isNotBlank() }
        if (hiddenCount > 0) {
            OutlinedButton(onClick = { inst.put("hidden", "") }) {
                Text(stringResource(R.string.apps_unhide) + " (" + hiddenCount.toString().localizeDigits(inst.lang) + ")")
            }
        }
        OutlinedButton(onClick = { inst.host.store.removePrefix("i_${inst.uid}_tint_") }) {
            Text(stringResource(R.string.apps_reset_tints))
        }
    }
}

// ---------- pieces ----------

@Composable
fun AppIcon(pkg: String, size: Dp, radius: Int, tint: Color?) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(IconCache.get("app:$pkg"), pkg) {
        if (value == null) {
            value = withContext(Dispatchers.IO) { IconCache.appIcon(ctx.packageManager, pkg) }
        }
    }
    Box(Modifier.size(size).clip(RoundedCornerShape(radius))) {
        bmp?.let {
            Image(
                it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                colorFilter = tint?.let { t -> ColorFilter.colorMatrix(tintMatrix(t)) }
            )
        }
    }
}

@Composable
private fun AppListRow(
    e: AppEntry, color: Color, tint: Color?, radius: Int,
    onClick: () -> Unit, onLong: () -> Unit, showIcon: Boolean
) {
    Row(
        Modifier
            .fillMaxWidth()
            .pointerInput(e.pkg) { detectTapGestures(onTap = { onClick() }, onLongPress = { onLong() }) }
            .padding(vertical = if (showIcon) 6.dp else 9.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showIcon) {
            AppIcon(e.pkg, 42.dp, radius, tint)
            Spacer(Modifier.width(12.dp))
        }
        Text(
            e.label, color = color,
            fontSize = if (showIcon) 15.sp else 18.sp,
            maxLines = 1
        )
    }
}

/** A search box that follows the module: its color and corner roundness. */
@Composable
fun SearchField(value: String, onChange: (String) -> Unit, color: Color, radius: Dp, hint: String) {
    val shape = RoundedCornerShape(radius)
    Row(
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .clip(shape)
            .background(color.copy(alpha = 0.10f))
            .border(1.dp, color.copy(alpha = 0.18f), shape)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Canvas(Modifier.size(18.dp)) {
            val s = size.minDimension
            drawCircle(
                color.copy(alpha = 0.7f), radius = s * 0.34f,
                center = Offset(s * 0.42f, s * 0.42f), style = Stroke(s * 0.11f)
            )
            drawLine(
                color.copy(alpha = 0.7f), Offset(s * 0.68f, s * 0.68f), Offset(s * 0.92f, s * 0.92f),
                strokeWidth = s * 0.11f, cap = StrokeCap.Round
            )
        }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(hint, color = color.copy(alpha = 0.5f), fontSize = 14.sp, maxLines = 1)
            }
            BasicTextField(
                value = value, onValueChange = onChange, singleLine = true,
                textStyle = TextStyle(color = color, fontSize = 14.sp),
                cursorBrush = SolidColor(color),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (value.isNotEmpty()) {
            Canvas(
                Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .clickable { onChange("") }
                    .padding(7.dp)
            ) {
                val s = size.minDimension
                drawLine(color, Offset(0f, 0f), Offset(s, s), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                drawLine(color, Offset(s, 0f), Offset(0f, s), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
            }
        }
    }
}

/**
 * The letter strip. Dragging a finger on it scrolls the list; the letters near the finger swell
 * and slide out, and a bubble shows the current letter.
 */
@Composable
private fun LetterIndex(
    letters: List<String>, current: String, color: Color, rtl: Boolean,
    modifier: Modifier, onPick: (String) -> Unit
) {
    var stripH by remember { mutableFloatStateOf(1f) }
    var fingerY by remember { mutableFloatStateOf(-1f) }
    var dragging by remember { mutableStateOf(false) }
    var last by remember { mutableIntStateOf(-1) }
    val active by animateFloatAsState(if (dragging) 1f else 0f, tween(180), label = "idx")
    val n = letters.size.coerceAtLeast(1)
    val dens = LocalDensity.current.density

    fun pick(y: Float) {
        fingerY = y.coerceIn(0f, stripH)
        val i = ((fingerY / stripH) * n).toInt().coerceIn(0, n - 1)
        if (i != last) {
            last = i
            onPick(letters[i])
        }
    }

    Box(
        modifier
            .width(28.dp)
            .fillMaxHeight()
            .onSizeChanged { stripH = it.height.toFloat().coerceAtLeast(1f) }
            .pointerInput(letters) {
                detectTapGestures(onPress = { off ->
                    dragging = true
                    pick(off.y)
                    tryAwaitRelease()
                    dragging = false
                    last = -1
                })
            }
            .pointerInput(letters) {
                detectVerticalDragGestures(
                    onDragStart = { off -> dragging = true; pick(off.y) },
                    onDragEnd = { dragging = false; last = -1 },
                    onDragCancel = { dragging = false; last = -1 }
                ) { change, _ ->
                    change.consume()
                    pick(change.position.y)
                }
            }
    ) {
        val fs = ((stripH / n) / dens * 0.8f).coerceIn(6f, 12f).sp
        Column(Modifier.fillMaxSize()) {
            letters.forEachIndexed { i, letter ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .graphicsLayer {
                            val slot = stripH / n
                            val cy = (i + 0.5f) * slot
                            val d = if (fingerY < 0f) 9f else abs(cy - fingerY) / slot
                            val w = (1f - d / 3.2f).coerceAtLeast(0f)
                            val k = w * w * active
                            scaleX = 1f + 1.1f * k
                            scaleY = scaleX
                            translationX = (if (rtl) 1f else -1f) * 24f * density * k
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        letter,
                        color = if (letter == current) IndexAccent else color.copy(alpha = 0.75f),
                        fontSize = fs,
                        fontWeight = if (letter == current) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
        if (active > 0.01f && fingerY >= 0f) {
            val idx = ((fingerY / stripH) * n).toInt().coerceIn(0, n - 1)
            Box(
                Modifier
                    .requiredSize(46.dp)
                    .offset { IntOffset(-(60.dp.roundToPx()), (fingerY - 23.dp.toPx()).roundToInt()) }
                    .graphicsLayer {
                        alpha = active
                        scaleX = 0.7f + 0.3f * active
                        scaleY = scaleX
                    }
                    .clip(CircleShape)
                    .background(IndexAccent),
                contentAlignment = Alignment.Center
            ) {
                Text(letters[idx], color = Color.White, fontSize = 22.sp)
            }
        }
    }
}

@Composable
private fun MenuItem(text: String, danger: Boolean = false, onClick: () -> Unit) {
    Text(
        text,
        color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
        fontSize = 15.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 13.dp)
    )
}

@Composable
fun AppMenuDialog(
    app: AppEntry, inst: ModuleInstance, tintNow: String,
    onDismiss: () -> Unit, onPermissions: () -> Unit, onHide: () -> Unit,
    hideLabel: Int = R.string.apps_hide,
    onAddToMain: (() -> Unit)? = null
) {
    val ctx = LocalContext.current
    val host = inst.host
    var showColors by remember { mutableStateOf(false) }
    LocalizedDialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(app.pkg, 44.dp, 26, null)
                    Spacer(Modifier.width(12.dp))
                    Text(app.label, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                }
                MenuItem(stringResource(R.string.apps_info)) {
                    onDismiss()
                    host.launch(detailsIntent(app.pkg))
                }
                MenuItem(stringResource(R.string.apps_perms)) { onPermissions() }
                MenuItem(stringResource(R.string.apps_icon_color)) { showColors = !showColors }
                if (showColors) {
                    Column(Modifier.padding(horizontal = 12.dp)) {
                        ColorChips("", IconTints, tintNow) { inst.put("tint_${app.pkg}", it) }
                        OutlinedButton(onClick = { inst.put("tint_${app.pkg}", "") }) {
                            Text(stringResource(R.string.apps_icon_reset))
                        }
                    }
                }
                if (onAddToMain != null) MenuItem(stringResource(R.string.apps_add_main)) { onAddToMain() }
                MenuItem(stringResource(hideLabel)) { onHide() }
                MenuItem(stringResource(R.string.apps_uninstall), danger = true) {
                    onDismiss()
                    host.launch(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
                }
            }
        }
    }
}

@Composable
fun PermissionsDialog(app: AppEntry, host: HostApi, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            tick++
        }
    }
    val groups = remember(tick) { permissionStates(pm, app.pkg) }

    // Android does not let one app change another app's permissions; open the system screen.
    fun openPermissions() {
        host.runAfterUnlock {
            val perm = Intent("android.intent.action.MANAGE_APP_PERMISSIONS")
                .putExtra("android.intent.extra.PACKAGE_NAME", app.pkg)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(perm)
            } catch (e: Exception) {
                try {
                    ctx.startActivity(detailsIntent(app.pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e2: Exception) {
                }
            }
        }
    }

    LocalizedDialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(app.pkg, 40.dp, 26, null)
                    Spacer(Modifier.width(10.dp))
                    Text(app.label, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                }
                Text(
                    stringResource(R.string.perm_note),
                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Column(
                    Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    if (groups.isEmpty()) {
                        Text(stringResource(R.string.perm_none), fontSize = 14.sp, modifier = Modifier.padding(8.dp))
                    }
                    for ((g, st) in groups) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { openPermissions() }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(g.emoji, fontSize = 20.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(stringResource(g.labelRes), fontSize = 14.sp)
                                Text(
                                    stringResource(
                                        when (st) {
                                            2 -> R.string.perm_allowed
                                            1 -> R.string.perm_partial
                                            else -> R.string.perm_denied
                                        }
                                    ),
                                    fontSize = 11.sp,
                                    color = if (st == 0) MaterialTheme.colorScheme.error
                                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )
                            }
                            Switch(checked = st >= 1, onCheckedChange = { openPermissions() })
                        }
                    }
                }
                Button(onClick = { openPermissions() }) { Text(stringResource(R.string.perm_open_all)) }
            }
        }
    }
}

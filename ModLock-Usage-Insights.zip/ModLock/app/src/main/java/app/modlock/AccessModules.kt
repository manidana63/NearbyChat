package app.modlock

import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Intent
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val Accent = Color(0xFF7C6CFF)

private class Tile(
    val key: String,
    val emoji: String,
    val label: Int,
    val active: Boolean,
    val onClick: () -> Unit,
)

/**
 * Flashlight and sound work directly. Android no longer lets apps switch Wi-Fi, Bluetooth or
 * airplane mode, so those tiles show the state and open the system panel.
 */
object QuickSettingsModule : LockModule {
    override val id = "quick"
    override val nameRes = R.string.mod_quick
    override val category = R.string.cat_access
    override val defaultW = 0.88f
    override val defaultH = 0.1f
    override val settings: List<Setting> = listOf(
        SwitchSetting("t_flash", R.string.qs_flash, true),
        SwitchSetting("t_sound", R.string.qs_sound, true),
        SwitchSetting("t_wifi", R.string.qs_wifi, true),
        SwitchSetting("t_bt", R.string.qs_bt, true),
        SwitchSetting("t_air", R.string.qs_air, true),
        SliderSetting("radius", R.string.setting_radius, 0f, 50f, 30f),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val color = inst.color("color")
        val radius = inst.f("radius", 30f).roundToInt().coerceIn(0, 50)
        var tick by remember { mutableIntStateOf(0) }
        LaunchedEffect(Unit) {
            Torch.init(ctx)
            while (true) {
                delay(1500)
                tick++
            }
        }
        val refresh = tick // reading it re-checks the system state on every tick

        val audio = ctx.getSystemService(AudioManager::class.java)
        val ringer = if (inst.isPreview) AudioManager.RINGER_MODE_NORMAL else audio?.ringerMode ?: AudioManager.RINGER_MODE_NORMAL
        val wifiOn = inst.isPreview || try { ctx.applicationContext.getSystemService(WifiManager::class.java).isWifiEnabled } catch (e: Exception) { false }
        val btOn = inst.isPreview || try { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true } catch (e: Exception) { false }
        val airOn = !inst.isPreview && try { Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (e: Exception) { false }

        val tiles = mutableListOf<Tile>()
        if (inst.b("t_flash", true)) {
            tiles.add(Tile("flash", "\uD83D\uDD26", R.string.qs_flash, Torch.isOn.value) { Torch.toggle(ctx) })
        }
        if (inst.b("t_sound", true)) {
            val emoji = when (ringer) {
                AudioManager.RINGER_MODE_SILENT -> "\uD83D\uDD07"
                AudioManager.RINGER_MODE_VIBRATE -> "\uD83D\uDCF3"
                else -> "\uD83D\uDD14"
            }
            tiles.add(Tile("sound", emoji, R.string.qs_sound, ringer != AudioManager.RINGER_MODE_NORMAL) {
                val next = when (ringer) {
                    AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE
                    AudioManager.RINGER_MODE_VIBRATE -> AudioManager.RINGER_MODE_SILENT
                    else -> AudioManager.RINGER_MODE_NORMAL
                }
                try {
                    audio?.ringerMode = next
                } catch (e: Exception) {
                    inst.host.launch(Intent(Settings.ACTION_SOUND_SETTINGS))
                }
            })
        }
        if (inst.b("t_wifi", true)) {
            tiles.add(Tile("wifi", "\uD83D\uDCF6", R.string.qs_wifi, wifiOn) {
                inst.host.launch(
                    if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                    else Intent(Settings.ACTION_WIFI_SETTINGS)
                )
            })
        }
        if (inst.b("t_bt", true)) {
            tiles.add(Tile("bt", "\uD83D\uDD35", R.string.qs_bt, btOn) {
                inst.host.launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            })
        }
        if (inst.b("t_air", true)) {
            tiles.add(Tile("air", "\u2708\uFE0F", R.string.qs_air, airOn) {
                inst.host.launch(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
            })
        }

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val boxW = maxWidth
            val boxH = maxHeight
            val n = maxOf(tiles.size, 1)
            val side = minOf(boxW.value / n, boxH.value)
            Row(Modifier.fillMaxSize()) {
                for (t in tiles) {
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(3.dp)
                            .clip(RoundedCornerShape(radius))
                            .background(if (t.active) Accent.copy(alpha = 0.55f) else color.copy(alpha = 0.12f))
                            .clickable { t.onClick() },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(t.emoji, fontSize = (side * 0.38f).coerceIn(12f, 30f).sp)
                            if (boxH.value > 56f) {
                                Text(
                                    stringResource(t.label), color = color,
                                    fontSize = (side * 0.15f).coerceIn(8f, 11f).sp, maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/** One big flashlight button. */
object FlashlightModule : LockModule {
    override val id = "flash"
    override val nameRes = R.string.mod_flash
    override val category = R.string.cat_access
    override val defaultW = 0.3f
    override val defaultH = 0.14f
    override val settings: List<Setting> = listOf(
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val color = inst.color("color")
        LaunchedEffect(Unit) { Torch.init(ctx) }
        val on = Torch.isOn.value
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val boxW = maxWidth
            val boxH = maxHeight
            val side = minOf(boxW, boxH)
            Box(
                Modifier
                    .size(side)
                    .clip(CircleShape)
                    .background(if (on) Color(0xFFFFD54F) else color.copy(alpha = 0.15f))
                    .clickable { Torch.toggle(ctx) },
                contentAlignment = Alignment.Center
            ) {
                Text("\uD83D\uDD26", fontSize = (side.value * 0.5f).sp)
            }
        }
    }
}

private enum class MediaIcon { PREV, NEXT, PLAY, PAUSE }

@Composable
private fun MediaButton(kind: MediaIcon, btn: Dp, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(btn).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(btn * 0.5f)) {
            val w = size.width
            val h = size.height
            when (kind) {
                MediaIcon.PLAY -> drawPath(
                    Path().apply { moveTo(w * 0.2f, 0f); lineTo(w * 0.95f, h / 2f); lineTo(w * 0.2f, h); close() },
                    color
                )
                MediaIcon.PAUSE -> {
                    drawRect(color, Offset(w * 0.15f, 0f), Size(w * 0.25f, h))
                    drawRect(color, Offset(w * 0.6f, 0f), Size(w * 0.25f, h))
                }
                MediaIcon.NEXT -> {
                    drawPath(Path().apply { moveTo(0f, 0f); lineTo(w * 0.75f, h / 2f); lineTo(0f, h); close() }, color)
                    drawRect(color, Offset(w * 0.8f, 0f), Size(w * 0.2f, h))
                }
                MediaIcon.PREV -> {
                    drawPath(Path().apply { moveTo(w, 0f); lineTo(w * 0.25f, h / 2f); lineTo(w, h); close() }, color)
                    drawRect(color, Offset(0f, 0f), Size(w * 0.2f, h))
                }
            }
        }
    }
}

/**
 * Shows what is playing and lets you control it. Android requires "notification access"
 * for reading other apps' media sessions; the module asks for it when first added.
 */
object MusicModule : LockModule {
    override val id = "music"
    override val nameRes = R.string.mod_music
    override val category = R.string.cat_access
    override val defaultW = 0.88f
    override val defaultH = 0.13f
    override val settings: List<Setting> = listOf(
        SliderSetting("radius", R.string.setting_radius, 0f, 50f, 20f),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val color = inst.color("color")
        val radius = inst.f("radius", 20f).roundToInt().coerceIn(0, 50)
        var allowed by remember { mutableStateOf(true) }
        var title by remember { mutableStateOf("") }
        var artist by remember { mutableStateOf("") }
        var art by remember { mutableStateOf<ImageBitmap?>(null) }
        var playing by remember { mutableStateOf(false) }
        var ctrl by remember { mutableStateOf<android.media.session.MediaController?>(null) }

        LaunchedEffect(Unit) {
            if (inst.isPreview) return@LaunchedEffect
            while (true) {
                allowed = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
                if (allowed) {
                    try {
                        val msm = ctx.getSystemService(MediaSessionManager::class.java)
                        val list = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
                        val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                            ?: list.firstOrNull()
                        ctrl = c
                        val md = c?.metadata
                        title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
                        artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
                        val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                        art = bmp?.asImageBitmap()
                        playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
                    } catch (e: Exception) {
                        ctrl = null
                    }
                }
                delay(1000)
            }
        }

        val sampleTitle = stringResource(R.string.music_sample_title)
        val sampleArtist = stringResource(R.string.music_sample_artist)
        val shownTitle = if (inst.isPreview) sampleTitle else title
        val shownArtist = if (inst.isPreview) sampleArtist else artist
        val isPlaying = inst.isPreview || playing

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val boxW = maxWidth
            val boxH = maxHeight
            if (!allowed && !inst.isPreview) {
                Box(
                    Modifier.fillMaxSize().clickable {
                        inst.host.launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    },
                    contentAlignment = Alignment.Center
                ) {
                    Text(stringResource(R.string.music_allow), color = color, fontSize = 13.sp)
                }
            } else if (shownTitle.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.music_none), color = color, fontSize = 14.sp)
                }
            } else {
                val cover = boxH.coerceAtMost(96.dp)
                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(cover)
                            .clip(RoundedCornerShape(radius))
                            .background(color.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        val a = art
                        if (a != null) {
                            Image(a, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        } else {
                            Text("\u266B", color = color, fontSize = (cover.value * 0.5f).sp)
                        }
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text(shownTitle, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                        Text(shownArtist, color = color.copy(alpha = 0.7f), fontSize = 12.sp, maxLines = 1)
                    }
                    val b = (cover.value * 0.45f).coerceIn(30f, 44f).dp
                    MediaButton(MediaIcon.PREV, b, color) { ctrl?.transportControls?.skipToPrevious() }
                    MediaButton(if (isPlaying) MediaIcon.PAUSE else MediaIcon.PLAY, b, color) {
                        if (isPlaying) ctrl?.transportControls?.pause() else ctrl?.transportControls?.play()
                    }
                    MediaButton(MediaIcon.NEXT, b, color) { ctrl?.transportControls?.skipToNext() }
                }
            }
        }
    }
}

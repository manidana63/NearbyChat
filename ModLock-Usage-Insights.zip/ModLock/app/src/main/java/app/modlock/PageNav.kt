package app.modlock

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import kotlin.math.abs

/** Lets a module drive the page camera (swipe between pages) from its own gestures. */
class PageNav(
    /** Is there a page next to the current one in that direction? (dx, dy are -1, 0 or 1) */
    val canGo: (dx: Int, dy: Int) -> Boolean,
    val begin: () -> Unit,
    val pan: (Float, Float) -> Unit,
    val end: (Float, Float) -> Unit,
)

val LocalPageNav = compositionLocalOf<PageNav?> { null }

/**
 * For scrollable lists. When the list is already at its start or end in the direction you
 * drag (and a page exists that way), the drag goes straight to the page change, exactly like on
 * a non-scrolling area. Otherwise the list scrolls normally.
 */
@Composable
fun Modifier.edgePageDrag(vertical: Boolean, atStart: () -> Boolean, atEnd: () -> Boolean): Modifier {
    val nav = LocalPageNav.current ?: return this
    return this.pointerInput(nav, vertical) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val slop = viewConfiguration.touchSlop
            val tracker = VelocityTracker()
            tracker.addPosition(down.uptimeMillis, down.position)
            var total = Offset.Zero
            var pageMode = false
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                if (!change.pressed) {
                    if (pageMode) {
                        val v = tracker.calculateVelocity()
                        nav.end(v.x, v.y)
                    }
                    break
                }
                val delta = change.positionChange()
                if (!pageMode) {
                    total += delta
                    if (total.getDistance() > slop) {
                        val main = if (vertical) total.y else total.x
                        val cross = if (vertical) total.x else total.y
                        if (abs(main) <= abs(cross)) break
                        val towardStart = main > 0f
                        val atEdge = if (towardStart) atStart() else atEnd()
                        val canGo = if (vertical) {
                            nav.canGo(0, if (towardStart) -1 else 1)
                        } else {
                            nav.canGo(if (towardStart) -1 else 1, 0)
                        }
                        if (!atEdge || !canGo) break
                        pageMode = true
                        nav.begin()
                        nav.pan(total.x, total.y)
                        change.consume()
                    }
                } else {
                    tracker.addPosition(change.uptimeMillis, change.position)
                    nav.pan(delta.x, delta.y)
                    change.consume()
                }
            }
        }
    }
}

package app.modlock

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private var resumeTick = mutableIntStateOf(0)

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = SettingsStore(this)
        setContent {
            LocalizedTheme(store) {
                AppRoot(this@MainActivity, store, resumeTick.intValue)
            }
        }
    }
}

@Composable
private fun AppRoot(activity: ComponentActivity, store: SettingsStore, tick: Int) {
    var screen by remember { mutableStateOf("home") }
    if (screen == "settings") BackHandler { screen = "home" }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Crossfade(targetState = screen, label = "screen") { s ->
            if (s == "settings") {
                SettingsPage(activity, store, tick) { screen = "home" }
            } else {
                HomePage(activity, store, tick) { screen = "settings" }
            }
        }
    }
}

private fun openOverlaySettings(activity: ComponentActivity) {
    activity.startActivity(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}"))
    )
}

private fun isDefaultHome(activity: ComponentActivity): Boolean {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    val r = activity.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
    return r?.activityInfo?.packageName == activity.packageName
}

private fun setEnabled(
    activity: ComponentActivity, store: SettingsStore, on: Boolean,
    askNotifications: () -> Unit
) {
    store.putBool("service_enabled", on)
    val i = Intent(activity, LockService::class.java)
    if (on) {
        if (Build.VERSION.SDK_INT >= 33) askNotifications()
        ContextCompat.startForegroundService(activity, i)
    } else {
        activity.stopService(i)
    }
}

// ------------------------------------------------------------------------------------------
// First screen: two clear sections, "Lock screen" and "Home (launcher)"
// ------------------------------------------------------------------------------------------

@Composable
private fun HomePage(activity: ComponentActivity, store: SettingsStore, tick: Int, onSettings: () -> Unit) {
    var tab by remember { mutableStateOf(store.get("main_tab", "lock")) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(
            Modifier.padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                stringResource(R.string.settings_title),
                Modifier.weight(1f),
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onSettings) {
                Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.settings_page))
            }
        }
        ModeTabs(tab) {
            tab = it
            store.put("main_tab", it)
        }
        Spacer(Modifier.height(14.dp))
        Crossfade(targetState = tab, modifier = Modifier.weight(1f), label = "tab") { t ->
            if (t == "home") LauncherTab(activity, tick) else LockTab(activity, store, tick)
        }
    }
}

@Composable
private fun ModeTabs(selected: String, onSelect: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(cs.surfaceVariant)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        ModeTab(Modifier.weight(1f), selected == "lock", Icons.Filled.Lock, stringResource(R.string.tab_lock)) { onSelect("lock") }
        ModeTab(Modifier.weight(1f), selected == "home", Icons.Filled.Home, stringResource(R.string.tab_home)) { onSelect("home") }
    }
}

@Composable
private fun ModeTab(modifier: Modifier, selected: Boolean, icon: ImageVector, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) cs.primary else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 13.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val fg = if (selected) cs.onPrimary else cs.onSurfaceVariant
        Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = fg, fontSize = 14.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun StatusCard(title: String, sub: String, trailing: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(cs.primaryContainer, cs.tertiaryContainer)))
            .padding(22.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    title, style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold, color = cs.onPrimaryContainer
                )
                Spacer(Modifier.height(4.dp))
                Text(sub, style = MaterialTheme.typography.bodyMedium, color = cs.onPrimaryContainer)
            }
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

@Composable
private fun BigButton(icon: ImageVector, text: String, primary: Boolean, onClick: () -> Unit) {
    val content: @Composable () -> Unit = {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.titleMedium)
    }
    if (primary) {
        Button(
            onClick = onClick, modifier = Modifier.fillMaxWidth().height(60.dp),
            shape = RoundedCornerShape(20.dp)
        ) { content() }
    } else {
        FilledTonalButton(
            onClick = onClick, modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(20.dp)
        ) { content() }
    }
}

@Composable
private fun CheckRow(ok: Boolean, optional: Boolean, title: String, actionLabel: String, onAction: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (ok) Icons.Filled.Check else Icons.Filled.Warning,
            contentDescription = null,
            tint = if (ok) Color(0xFF43A047) else if (optional) cs.onSurfaceVariant else cs.error
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp)
            Text(
                stringResource(
                    when {
                        ok -> R.string.chk_ok
                        optional -> R.string.chk_optional
                        else -> R.string.chk_needed
                    }
                ),
                fontSize = 11.sp, color = cs.onSurfaceVariant
            )
        }
        if (!ok) {
            OutlinedButton(
                onClick = onAction,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
            ) { Text(actionLabel, fontSize = 12.sp) }
        }
    }
}

@Composable
private fun LockTab(activity: ComponentActivity, store: SettingsStore, tick: Int) {
    val overlayOk = remember(tick) { Settings.canDrawOverlays(activity) }
    val batteryOk = remember(tick) {
        activity.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(activity.packageName) == true
    }
    val notifAccess = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(activity).contains(activity.packageName)
    }
    val enabled = store.getBool("service_enabled", false)
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        StatusCard(
            title = stringResource(if (enabled) R.string.lock_on else R.string.lock_off),
            sub = stringResource(if (enabled) R.string.lock_on_sub else R.string.lock_off_sub)
        ) {
            androidx.compose.material3.Switch(
                checked = enabled,
                onCheckedChange = { on ->
                    setEnabled(activity, store, on) {
                        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            )
        }
        BigButton(Icons.Filled.Edit, stringResource(R.string.edit_lockscreen), true) {
            activity.startActivity(Intent(activity, LockActivity::class.java).putExtra("edit", true))
        }
        BigButton(Icons.Filled.PlayArrow, stringResource(R.string.preview), false) {
            activity.startActivity(Intent(activity, LockActivity::class.java))
        }
        BigButton(Icons.Filled.Settings, stringResource(R.string.usage_insights), false) {
            activity.startActivity(Intent(activity, UsageInsightsActivity::class.java))
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    stringResource(R.string.chk_title),
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold
                )
                CheckRow(overlayOk, false, stringResource(R.string.chk_overlay), stringResource(R.string.btn_allow)) {
                    openOverlaySettings(activity)
                }
                CheckRow(batteryOk, true, stringResource(R.string.chk_battery), stringResource(R.string.btn_open)) {
                    activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
                CheckRow(notifAccess, true, stringResource(R.string.chk_notif_access), stringResource(R.string.btn_allow)) {
                    activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
            }
        }
        Text(
            stringResource(R.string.lock_security_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun LauncherTab(activity: ComponentActivity, tick: Int) {
    val isHome = remember(tick) { isDefaultHome(activity) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        StatusCard(
            title = stringResource(if (isHome) R.string.lau_is else R.string.lau_not),
            sub = stringResource(if (isHome) R.string.lau_is_sub else R.string.lau_not_sub)
        ) {
            if (isHome) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            } else {
                Button(onClick = { activity.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }) {
                    Text(stringResource(R.string.home_app_btn), fontSize = 12.sp)
                }
            }
        }
        BigButton(Icons.Filled.Edit, stringResource(R.string.edit_home), true) {
            activity.startActivity(Intent(activity, HomeActivity::class.java).putExtra("edit", true))
        }
        BigButton(Icons.Filled.Home, stringResource(R.string.open_home), false) {
            activity.startActivity(Intent(activity, HomeActivity::class.java))
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    stringResource(R.string.lau_tips),
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold
                )
                Text(stringResource(R.string.lau_tip1), style = MaterialTheme.typography.bodyMedium)
                Text(stringResource(R.string.lau_tip2), style = MaterialTheme.typography.bodyMedium)
                Text(stringResource(R.string.lau_tip3), style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

// ------------------------------------------------------------------------------------------
// Settings
// ------------------------------------------------------------------------------------------

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

/** Settings: language, gestures, look of the modules, notification and permissions. */
@Composable
private fun SettingsPage(activity: ComponentActivity, store: SettingsStore, tick: Int, onBack: () -> Unit) {
    val overlayOk = remember(tick) { Settings.canDrawOverlays(activity) }
    fun tr(id: Int): String = localizedContext(activity, store.lang).getString(id)
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            val ok = try {
                activity.contentResolver.openOutputStream(uri)?.use { it.write(Backup.export(store).toByteArray()) }
                true
            } catch (e: Exception) {
                false
            }
            Toast.makeText(activity, tr(if (ok) R.string.backup_done else R.string.backup_bad), Toast.LENGTH_SHORT).show()
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val n = try {
                activity.contentResolver.openInputStream(uri)?.use { Backup.import(store, it.readBytes().toString(Charsets.UTF_8)) } ?: -1
            } catch (e: Exception) {
                -1
            }
            if (n >= 0) HostActivity.applyAll(activity)
            Toast.makeText(activity, tr(if (n >= 0) R.string.backup_restored else R.string.backup_bad), Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
            }
            Text(
                stringResource(R.string.settings_page),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard(stringResource(R.string.section_backup)) {
                Text(stringResource(R.string.apply_note), style = MaterialTheme.typography.bodySmall)
                Button(onClick = {
                    HostActivity.applyAll(activity)
                    Toast.makeText(activity, tr(R.string.applied), Toast.LENGTH_SHORT).show()
                }) { Text(stringResource(R.string.apply_now)) }
                OutlinedButton(onClick = { exportLauncher.launch("vitrin-backup.json") }) {
                    Text(stringResource(R.string.backup_export))
                }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }) {
                    Text(stringResource(R.string.backup_import))
                }
                Text(stringResource(R.string.backup_note), style = MaterialTheme.typography.bodySmall)
            }

            SectionCard(stringResource(R.string.section_language)) {
                ChoiceRow(
                    label = "",
                    options = listOf("fa" to "فارسی", "en" to "English"),
                    selected = store.lang
                ) {
                    store.put("lang", it)
                    LockService.refresh(activity)
                }
            }

            SectionCard(stringResource(R.string.section_gestures)) {
                val sens = store.getFloat("page_sens", 1.8f)
                Text(stringResource(R.string.g_sens))
                Slider(
                    value = sens,
                    onValueChange = { store.putFloat("page_sens", it) },
                    valueRange = 1f..3.5f
                )
                Text(stringResource(R.string.g_sens_hint), style = MaterialTheme.typography.bodySmall)

                val hold = store.getFloat("hold_ms", 900f)
                var secs = "%.1f".format(java.util.Locale.ENGLISH, hold / 1000f)
                if (store.lang == "fa") secs = secs.replace('.', '\u066B')
                Text(stringResource(R.string.g_hold) + ": " + secs.localizeDigits(store.lang) + " " + stringResource(R.string.g_sec))
                Slider(
                    value = hold,
                    onValueChange = { store.putFloat("hold_ms", it) },
                    valueRange = 400f..2000f
                )
                SwitchRow(stringResource(R.string.g_edit_btn), store.getBool("home_edit_btn", true)) {
                    store.putBool("home_edit_btn", it)
                }
            }

            SectionCard(stringResource(R.string.section_rotation)) {
                SwitchRow(stringResource(R.string.rot_lock_label), store.getBool("rot_lock", true)) {
                    store.putBool("rot_lock", it)
                    HostActivity.refreshAllOrientation()
                }
                SwitchRow(stringResource(R.string.rot_home_label), store.getBool("rot_home", true)) {
                    store.putBool("rot_home", it)
                    HostActivity.refreshAllOrientation()
                }
                Text(stringResource(R.string.rot_note), style = MaterialTheme.typography.bodySmall)
            }

            SectionCard(stringResource(R.string.anim_title)) {
                Text(stringResource(R.string.anim_note), style = MaterialTheme.typography.bodySmall)
                ChoiceRow(
                    label = "",
                    options = AnimStyles.map { it.first to stringResource(it.second) },
                    selected = store.get("launch_anim", "default")
                ) { store.put("launch_anim", it) }
                OutlinedButton(onClick = {
                    val opts = LaunchAnim.options(activity, store, "global")
                    val i = Intent(activity, AnimDemoActivity::class.java)
                    if (opts != null) activity.startActivity(i, opts) else activity.startActivity(i)
                }) { Text(stringResource(R.string.anim_try)) }
            }

            SectionCard(stringResource(R.string.section_appearance)) {
                AppearanceSettings(store)
            }

            SectionCard(stringResource(R.string.section_notification)) {
                SwitchRow(stringResource(R.string.notif_show), store.getBool("notif_on", true)) { on ->
                    store.putBool("notif_on", on)
                    LockService.refresh(activity)
                }
                Text(stringResource(R.string.notif_hint), style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = {
                    activity.startActivity(
                        Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName)
                            .putExtra(Settings.EXTRA_CHANNEL_ID, LockService.channelId(activity))
                    )
                }) { Text(stringResource(R.string.notif_system)) }
            }

            SectionCard(stringResource(R.string.section_permissions)) {
                Text(stringResource(if (overlayOk) R.string.overlay_ok else R.string.overlay_missing))
                if (!overlayOk) {
                    Button(onClick = { openOverlaySettings(activity) }) {
                        Text(stringResource(R.string.grant_overlay))
                    }
                }
                Text(stringResource(R.string.battery_hint), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = {
                    activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }) { Text(stringResource(R.string.battery_btn)) }
            }
        }
    }
}

package app.modlock

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** A glass slider. Its track is the panel, so it draws that itself. */
object SlideUnlockModule : LockModule {
    override val id = "slide"
    override val nameRes = R.string.mod_slide
    override val category = R.string.cat_entry
    override val defaultW = 0.84f
    override val defaultH = 0.09f
    override val singleton = true
    override val unlocks = true
    override val ownsPanel = true
    override val settings: List<Setting> = listOf(
        TextSetting("text", R.string.slide_label, ""),
        SliderSetting("radius", R.string.setting_radius, 0f, 50f, 50f),
        SwitchSetting("anim", R.string.slide_anim, true),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val density = LocalDensity.current
        val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
        val fg = themeFg()
        val pct = inst.f("radius", 50f).roundToInt().coerceIn(0, 50)
        val animated = inst.b("anim", true)
        val shape = RoundedCornerShape(pct)
        val pad = 4.dp
        val label = inst.s("text", "").ifBlank { stringResource(R.string.slide_text) }
        val spec = rememberPanelSpec(inst.host.store, if (inst.grouped) "none" else inst.s("style", "global"))
        val scope = rememberCoroutineScope()
        var releaseJob by remember { mutableStateOf<Job?>(null) }

        val transition = rememberInfiniteTransition(label = "slide")
        val shift by transition.animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(5000, easing = LinearEasing), RepeatMode.Restart),
            label = "shift"
        )
        val pulse by transition.animateFloat(
            initialValue = 0.65f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "pulse"
        )
        // Soft purple / blue wash; first and last colors match so the loop is seamless.
        val wash = listOf(Color(0xFF8A6CFF), Color(0xFF4C8DFF), Color(0xFF8A6CFF))

        BoxWithConstraints(Modifier.fillMaxSize().panel(spec, shape)) {
            val thumb = (maxHeight - pad * 2).coerceAtLeast(24.dp)
            val thumbPx = with(density) { (thumb + pad * 2).toPx() }
            val maxPx = with(density) { (maxWidth - thumb - pad * 2).toPx() }
            var dragX by remember { mutableFloatStateOf(0f) }
            val progress = if (maxPx > 0f) (dragX / maxPx).coerceIn(0f, 1f) else 0f

            Box(Modifier.fillMaxSize().clip(shape)) {
                // Animated purple/blue wash inside the glass.
                Box(
                    Modifier.fillMaxSize().drawBehind {
                        val off = if (animated) shift * size.width else 0f
                        drawRect(
                            Brush.horizontalGradient(
                                wash.map { it.copy(alpha = 0.32f) },
                                startX = off, endX = off + size.width, tileMode = TileMode.Repeated
                            )
                        )
                    }
                )

                // Red -> green fill that follows the thumb.
                if (dragX > 1f) {
                    val fillW = with(density) { (dragX + thumbPx).toDp() }
                    Box(
                        Modifier
                            .align(Alignment.CenterStart)
                            .fillMaxHeight()
                            .width(fillW)
                            .clip(shape)
                            .background(
                                lerp(Color(0xFFE53935), Color(0xFF43A047), progress).copy(alpha = 0.85f)
                            )
                    )
                }

                // Chevrons + label; fade out as you slide.
                Row(
                    Modifier
                        .align(Alignment.Center)
                        .padding(start = thumb + pad * 2)
                        .graphicsLayer {
                            alpha = (1f - progress) * (if (animated) pulse else 1f)
                        },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Chevrons(thumb, rtl, fg, animated) { shift }
                    Text(label, color = fg, fontSize = 16.sp)
                }

                // Glossy blue thumb with a lock.
                Box(
                    Modifier
                        .align(Alignment.CenterStart)
                        .padding(pad)
                        // offset{} is mirrored automatically in RTL, so a positive value
                        // always moves the thumb toward the end side.
                        .offset { IntOffset(dragX.roundToInt(), 0) }
                        .size(thumb)
                        .clip(shape)
                        .drawBehind {
                            drawRect(
                                Brush.radialGradient(
                                    listOf(Color(0xFF5CE1FF), Color(0xFF1F6BFF), Color(0xFF0A3FCF)),
                                    center = Offset(size.width * 0.4f, size.height * 0.3f),
                                    radius = maxOf(size.width, size.height) * 0.95f
                                )
                            )
                            drawRect(
                                Brush.verticalGradient(
                                    listOf(Color.White.copy(alpha = 0.55f), Color.Transparent),
                                    startY = 0f, endY = size.height * 0.5f
                                )
                            )
                        }
                        .border(1.5.dp, Color.White.copy(alpha = 0.7f), shape)
                        .pointerInput(maxPx, rtl) {
                            detectHorizontalDragGestures(
                                onDragStart = { releaseJob?.cancel() },
                                onDragEnd = {
                                    if (!inst.editing && dragX >= maxPx * 0.85f) inst.host.unlock()
                                    releaseJob = scope.launch {
                                        animate(dragX, 0f, animationSpec = spring()) { v, _ -> dragX = v }
                                    }
                                },
                                onDragCancel = {
                                    releaseJob = scope.launch {
                                        animate(dragX, 0f, animationSpec = spring()) { v, _ -> dragX = v }
                                    }
                                },
                                onHorizontalDrag = { change, amount ->
                                    change.consume()
                                    val delta = if (rtl) -amount else amount
                                    dragX = (dragX + delta).coerceIn(0f, maxPx)
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    LockGlyph(thumb * 0.5f)
                }
            }
        }
    }

    /** Three chevrons that light up one after another, pointing the way you slide. */
    @Composable
    private fun Chevrons(h: Dp, rtl: Boolean, color: Color, animated: Boolean, shift: () -> Float) {
        Row {
            for (i in 0..2) {
                Canvas(Modifier.size(h * 0.28f, h * 0.4f)) {
                    val d = (((shift() * 3f - i) % 3f) + 3f) % 3f
                    val a = if (animated) 0.3f + 0.7f * (if (d < 1f) 1f - d else 0f) else 0.8f
                    val w = size.width
                    val hh = size.height
                    val path = Path().apply {
                        if (rtl) {
                            moveTo(w * 0.8f, hh * 0.1f)
                            lineTo(w * 0.2f, hh * 0.5f)
                            lineTo(w * 0.8f, hh * 0.9f)
                        } else {
                            moveTo(w * 0.2f, hh * 0.1f)
                            lineTo(w * 0.8f, hh * 0.5f)
                            lineTo(w * 0.2f, hh * 0.9f)
                        }
                    }
                    drawPath(
                        path, color.copy(alpha = a),
                        style = Stroke(width = w * 0.28f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
            }
        }
    }

    @Composable
    private fun LockGlyph(sz: Dp) {
        Canvas(Modifier.size(sz)) {
            val w = size.width
            val h = size.height
            val blue = Color(0xFF1F6BFF)
            drawArc(
                Color.White, startAngle = 180f, sweepAngle = 180f, useCenter = false,
                topLeft = Offset(w * 0.22f, h * 0.04f), size = Size(w * 0.56f, h * 0.56f),
                style = Stroke(w * 0.13f, cap = StrokeCap.Round)
            )
            drawRoundRect(
                Color.White, topLeft = Offset(w * 0.1f, h * 0.42f),
                size = Size(w * 0.8f, h * 0.54f), cornerRadius = CornerRadius(w * 0.14f)
            )
            drawCircle(blue, radius = w * 0.075f, center = Offset(w * 0.5f, h * 0.65f))
            drawRect(blue, topLeft = Offset(w * 0.47f, h * 0.65f), size = Size(w * 0.06f, h * 0.17f))
        }
    }
}

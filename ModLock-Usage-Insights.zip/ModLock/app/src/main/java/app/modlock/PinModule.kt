package app.modlock

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.security.MessageDigest

/**
 * A PIN keypad (4 to 12 digits, confirmed with the check key). Note: this is a visual layer
 * on top of the system lock; real device security is still Android's own PIN / fingerprint.
 * The keypad stretches to fill whatever size the module is given.
 */
object PinModule : LockModule {
    override val id = "pin"
    override val nameRes = R.string.mod_pin
    override val category = R.string.cat_entry
    override val defaultW = 0.7f
    override val defaultH = 0.45f
    override val singleton = true
    override val unlocks = true
    override val settings: List<Setting> = listOf(
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    private const val MIN_LEN = 4
    private const val MAX_LEN = 12

    private fun hash(uid: String, pin: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest("modlock:$uid:$pin".toByteArray())
            .joinToString("") { "%02x".format(it) }

    @Composable
    override fun Content(inst: ModuleInstance) {
        val stored = inst.s("hash", "")
        val color = inst.color("color")
        var entered by remember { mutableStateOf("") }
        var error by remember { mutableStateOf(false) }

        LaunchedEffect(error) {
            if (error) {
                delay(500)
                entered = ""
                error = false
            }
        }

        fun press(k: String) {
            if (error || inst.editing) return
            when (k) {
                "<" -> if (entered.isNotEmpty()) entered = entered.dropLast(1)
                "ok" -> {
                    if (entered.length >= MIN_LEN && stored.isNotEmpty() && hash(inst.uid, entered) == stored) {
                        entered = ""
                        inst.host.unlock()
                    } else {
                        error = true
                    }
                }
                else -> if (entered.length < MAX_LEN) entered += k
            }
        }

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val dotsH = 24.dp
            val cellW = maxWidth / 3
            val cellH = (maxHeight - dotsH) / 4
            val fontSize = (minOf(cellW.value, cellH.value) * 0.38f).coerceAtLeast(10f).sp

            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.height(dotsH).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    if (stored.isEmpty()) {
                        Text(stringResource(R.string.pin_not_set), color = color, fontSize = 11.sp)
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            repeat(maxOf(MIN_LEN, entered.length)) { i ->
                                Box(
                                    Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                error -> Color(0xFFEF5350)
                                                i < entered.length -> color
                                                else -> color.copy(alpha = 0.3f)
                                            }
                                        )
                                )
                            }
                        }
                    }
                }
                // Keypads read left-to-right in every language.
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    val keys = listOf(
                        listOf("1", "2", "3"), listOf("4", "5", "6"),
                        listOf("7", "8", "9"), listOf("<", "0", "ok")
                    )
                    for (row in keys) {
                        Row(Modifier.fillMaxWidth().weight(1f)) {
                            for (k in row) Key(k, color, inst.lang, fontSize) { press(k) }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun RowScope.Key(key: String, color: Color, lang: String, fontSize: TextUnit, onClick: () -> Unit) {
        Box(
            Modifier.weight(1f).fillMaxHeight().padding(3.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(50))
                    .background(color.copy(alpha = 0.15f))
                    .clickable(onClick = onClick),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    when (key) {
                        "<" -> "\u232B"
                        "ok" -> "\u2713"
                        else -> key.localizeDigits(lang)
                    },
                    color = color, fontSize = fontSize
                )
            }
        }
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        var p1 by remember { mutableStateOf("") }
        var p2 by remember { mutableStateOf("") }
        var msg by remember { mutableStateOf<Int?>(null) }
        val isSet = inst.s("hash", "").isNotEmpty()

        Text(stringResource(if (isSet) R.string.pin_status_set else R.string.pin_status_unset))
        OutlinedTextField(
            value = p1,
            onValueChange = { p1 = it.asciiDigits().filter { c -> c in '0'..'9' }.take(MAX_LEN) },
            label = { Text(stringResource(R.string.pin_new)) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = p2,
            onValueChange = { p2 = it.asciiDigits().filter { c -> c in '0'..'9' }.take(MAX_LEN) },
            label = { Text(stringResource(R.string.pin_confirm)) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = {
            if (p1.length >= MIN_LEN && p1 == p2) {
                inst.put("hash", hash(inst.uid, p1))
                p1 = ""
                p2 = ""
                msg = R.string.pin_saved
            } else {
                msg = R.string.pin_mismatch
            }
        }) { Text(stringResource(R.string.pin_save)) }
        msg?.let { Text(stringResource(it)) }
    }
}

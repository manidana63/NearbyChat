package app.modlock

import android.app.KeyguardManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/** Hosts a normal Android home-screen widget inside the lock screen. */
object WidgetModule : LockModule {
    override val id = "widget"
    override val nameRes = R.string.mod_widget
    override val category = R.string.cat_access
    override val defaultW = 0.88f
    override val defaultH = 0.2f
    override val settings: List<Setting> = listOf(
        SwitchSetting("hide_locked", R.string.widget_hide_locked, false),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ws = inst.host.widgets
        val id = inst.s("wid", "-1").toIntOrNull() ?: -1
        val ctx = LocalContext.current
        val locked = remember {
            ctx.getSystemService(KeyguardManager::class.java)?.isKeyguardLocked == true
        }
        val valid = ws != null && id >= 0 &&
            runCatching { ws.manager.getAppWidgetInfo(id) != null }.getOrDefault(false)

        when {
            !valid -> Placeholder(stringResource(R.string.widget_none))
            inst.b("hide_locked", false) && locked && !inst.editing ->
                Placeholder(stringResource(R.string.widget_hidden))
            else -> WidgetView(ws!!, id)
        }
    }

    @Composable
    private fun WidgetView(ws: WidgetSupport, id: Int) {
        val density = LocalDensity.current
        val hostView = remember(id) { ws.view(id) }
        if (hostView == null) {
            Placeholder(stringResource(R.string.widget_none))
            return
        }
        AndroidView(
            factory = { hostView },
            modifier = Modifier
                .fillMaxSize()
                .onSizeChanged { sz ->
                    val w = (sz.width / density.density).toInt()
                    val h = (sz.height / density.density).toInt()
                    try {
                        hostView.updateAppWidgetSize(android.os.Bundle(), w, h, w, h)
                    } catch (e: Exception) {
                    }
                }
        )
    }

    @Composable
    private fun Placeholder(text: String) {
        Box(
            Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(16.dp))
                .background(themeFg().copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Text(text, color = themeFg(), fontSize = 14.sp)
        }
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        val ws = inst.host.widgets ?: return
        var open by remember { mutableStateOf(false) }
        var expanded by remember { mutableStateOf<String?>(null) }
        val onSurface = MaterialTheme.colorScheme.onSurface
        Button(onClick = { open = !open }) { Text(stringResource(R.string.widget_choose)) }
        if (open) {
            // Widgets grouped by the app that provides them.
            val groups = remember {
                ws.providers()
                    .groupBy { it.provider.packageName }
                    .map { (pkg, list) -> Triple(pkg, ws.appLabel(list.first()), list) }
                    .sortedBy { it.second.lowercase() }
            }
            for ((pkg, appName, list) in groups) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { expanded = if (expanded == pkg) null else pkg }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncIcon(pkg, 96, Modifier.size(36.dp)) { ws.appIcon(list.first()) }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(appName)
                        Text(
                            list.size.toString().localizeDigits(inst.lang),
                            fontSize = 11.sp, color = Color.Gray
                        )
                    }
                    Text(if (expanded == pkg) "\u25B2" else "\u25BC", color = Color.Gray)
                }
                if (expanded == pkg) {
                    for (info in list) {
                        // Each widget with its preview picture.
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(onSurface.copy(alpha = 0.06f))
                                .clickable {
                                    open = false
                                    ws.bind(info) { newId ->
                                        if (newId != null) {
                                            val old = inst.s("wid", "-1").toIntOrNull() ?: -1
                                            if (old >= 0) ws.delete(old)
                                            inst.put("wid", newId.toString())
                                        }
                                    }
                                }
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            AsyncIcon(
                                info.provider.flattenToString(), 480,
                                Modifier.fillMaxWidth().heightIn(max = 140.dp)
                            ) { ws.preview(info) ?: ws.appIcon(info) }
                            Text(ws.label(info), fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }

    override fun onRemoved(inst: ModuleInstance) {
        val id = inst.s("wid", "-1").toIntOrNull() ?: -1
        if (id >= 0) inst.host.widgets?.delete(id)
    }
}

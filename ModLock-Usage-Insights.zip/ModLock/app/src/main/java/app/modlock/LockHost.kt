package app.modlock

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private val Accent = Color(0xFF64B5F6)
private val GroupGreen = Color(0xFF81C784)

/**
 * Draws the background and the pages of a scene ("lock" or "home"). Pages form a grid: swipe
 * left/right/up/down to move between them. In edit mode it also draws the editor.
 */
@Composable
fun LockScreenHost(store: SettingsStore, host: HostApi, scene: String, onExit: () -> Unit) {
    val layout = remember(scene) { LayoutStore(store, scene) }
    val editing = host.editing
    val isLock = scene == "lock"
    var selected by remember { mutableStateOf<String?>(null) }
    var panel by remember { mutableStateOf("none") } // none | add | settings | bg | pages | gstyle
    var groupPick by remember { mutableStateOf<Set<String>?>(null) }
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val realDir = LocalLayoutDirection.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    // Camera position in page units; (curX, curY) is the page we are on.
    var curX by remember { mutableIntStateOf(0) }
    var curY by remember { mutableIntStateOf(0) }
    var camX by remember { mutableFloatStateOf(0f) }
    var camY by remember { mutableFloatStateOf(0f) }
    var navJob by remember { mutableStateOf<Job?>(null) }
    var axis by remember { mutableIntStateOf(0) } // 0 undecided, 1 horizontal, 2 vertical
    var boxW by remember { mutableFloatStateOf(1f) }
    var boxH by remember { mutableFloatStateOf(1f) }
    val curKey = pageKey(curX, curY)
    val effect = store.get("page_effect", "slide")

    if (editing) {
        BackHandler {
            when {
                groupPick != null -> groupPick = null
                panel != "none" -> panel = "none"
                else -> onExit()
            }
        }
    }

    val modules = layout.items.mapNotNull { p -> ModuleRegistry.find(p.type)?.let { p to it } }
    val hasUnlock = modules.any { it.second.unlocks }
    val sel = layout.get(selected ?: "")?.takeIf { it.page == curKey || isPinned(it, store) }

    fun animateTo(tx: Int, ty: Int) {
        navJob?.cancel()
        navJob = scope.launch {
            val sx = camX
            val sy = camY
            animate(0f, 1f, animationSpec = tween(380, easing = FastOutSlowInEasing)) { t, _ ->
                camX = sx + (tx - sx) * t
                camY = sy + (ty - sy) * t
            }
            curX = tx
            curY = ty
            camX = tx.toFloat()
            camY = ty.toFloat()
        }
    }

    fun goTo(tx: Int, ty: Int) {
        if (abs(tx - curX) + abs(ty - curY) == 1) {
            animateTo(tx, ty)
        } else {
            navJob?.cancel()
            curX = tx; curY = ty; camX = tx.toFloat(); camY = ty.toFloat()
        }
    }

    fun panBy(dx: Float, dy: Float) {
        if (axis == 0) axis = if (abs(dx) > abs(dy)) 1 else 2
        // Page swipe sensitivity (Settings > Gestures): higher = a shorter finger movement.
        val sens = store.getFloat("page_sens", 1.8f).coerceIn(0.8f, 4f)
        if (axis == 1) {
            val off = camX - curX - dx * sens / boxW
            val lo = if (layout.hasPage(curX - 1, curY)) -1f else 0f
            val hi = if (layout.hasPage(curX + 1, curY)) 1f else 0f
            camX = curX + off.coerceIn(lo, hi)
        } else {
            val off = camY - curY - dy * sens / boxH
            val lo = if (layout.hasPage(curX, curY - 1)) -1f else 0f
            val hi = if (layout.hasPage(curX, curY + 1)) 1f else 0f
            camY = curY + off.coerceIn(lo, hi)
        }
    }

    fun cameraOff(): Boolean = abs(camX - curX) > 0.001f || abs(camY - curY) > 0.001f

    fun finishDrag(vx: Float = 0f, vy: Float = 0f) {
        val ox = camX - curX
        val oy = camY - curY
        val thr = 0.12f      // how far the camera must move (in pages) to switch
        val fast = 650f      // px/s: a quick flick switches even after a short drag
        var tx = curX
        var ty = curY
        if (axis == 1) {
            if ((ox > thr || (ox > 0.02f && vx < -fast)) && layout.hasPage(curX + 1, curY)) tx = curX + 1
            else if ((ox < -thr || (ox < -0.02f && vx > fast)) && layout.hasPage(curX - 1, curY)) tx = curX - 1
        } else if (axis == 2) {
            if ((oy > thr || (oy > 0.02f && vy < -fast)) && layout.hasPage(curX, curY + 1)) ty = curY + 1
            else if ((oy < -thr || (oy < -0.02f && vy > fast)) && layout.hasPage(curX, curY - 1)) ty = curY - 1
        }
        axis = 0
        animateTo(tx, ty)
    }

    // Lists and pagers inside a module scroll first; when they hit their end, the extra drag
    // moves the page camera instead (so a full-page "All apps" can still swipe to other pages).
    val nested = remember(layout) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (source != NestedScrollSource.Drag || !cameraOff()) return Offset.Zero
                navJob?.cancel()
                panBy(available.x, available.y)
                return if (axis == 1) Offset(available.x, 0f) else Offset(0f, available.y)
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source != NestedScrollSource.Drag) return Offset.Zero
                if (abs(available.x) < 0.5f && abs(available.y) < 0.5f) return Offset.Zero
                navJob?.cancel()
                val wasOff = cameraOff()
                val bx = camX
                val by = camY
                panBy(available.x, available.y)
                val moved = abs(camX - bx) > 1e-6f || abs(camY - by) > 1e-6f
                if (!moved) {
                    if (!wasOff) axis = 0 // no page that way: let the list show its own edge effect
                    return Offset.Zero
                }
                return if (axis == 1) Offset(available.x, 0f) else Offset(0f, available.y)
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                if (cameraOff()) {
                    finishDrag(available.x, available.y)
                    return available
                }
                return Velocity.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                if (cameraOff()) finishDrag(available.x, available.y)
                return Velocity.Zero
            }
        }
    }

    fun deleteModule(p: Placement) {
        val m = ModuleRegistry.find(p.type)
        val otherUnlocks = layout.items.count {
            it.uid != p.uid && ModuleRegistry.find(it.type)?.unlocks == true
        }
        if (isLock && m?.unlocks == true && otherUnlocks == 0) {
            Toast.makeText(ctx, R.string.unlock_required, Toast.LENGTH_LONG).show()
            return
        }
        m?.onRemoved(ModuleInstance(p.uid, host))
        layout.remove(p.uid)
        selected = null
        panel = "none"
    }

    fun deleteCurrentPage() {
        val key = curKey
        if (!layout.canRemovePage(key)) {
            Toast.makeText(ctx, R.string.pg_cannot_delete, Toast.LENGTH_LONG).show()
            return
        }
        val remaining = layout.items.filter { it.page != key }
        if (isLock && remaining.none { ModuleRegistry.find(it.type)?.unlocks == true }) {
            Toast.makeText(ctx, R.string.unlock_required, Toast.LENGTH_LONG).show()
            return
        }
        layout.items.filter { it.page == key }.forEach {
            ModuleRegistry.find(it.type)?.onRemoved(ModuleInstance(it.uid, host))
        }
        layout.removePage(key)
        selected = null
        panel = "none"
        goTo(0, 0)
    }

    // Only the pages that are (partly) on screen are composed.
    val visibleKeys by remember(layout) {
        derivedStateOf {
            layout.pages.filter { k ->
                val rx = pageX(k) - camX
                val ry = pageY(k) - camY
                (abs(ry) < 0.001f && abs(rx) < 0.999f) || (abs(rx) < 0.001f && abs(ry) < 0.999f)
            }.ifEmpty { listOf(curKey) }
        }
    }

    val pageNav = remember(layout) {
        PageNav(
            canGo = { dx, dy -> layout.hasPage(curX + dx, curY + dy) },
            begin = { navJob?.cancel(); axis = 0 },
            pan = { dx, dy -> panBy(dx, dy) },
            end = { vx, vy -> finishDrag(vx, vy) }
        )
    }

    // Android Back: from any page (even inside the app drawer) go back to the main page.
    if (!editing) {
        BackHandler(enabled = curKey != "0:0") { goTo(0, 0) }
    }

    var dropTarget by remember { mutableStateOf<String?>(null) }
    var showIconPicker by remember { mutableStateOf(false) }

    // Icon on top of another icon (or a folder) while editing => they become one folder.
    fun findDropTarget(uid: String): Placement? {
        val d = layout.get(uid) ?: return null
        if (d.type != "appicon") return null
        val cx = d.x + d.w / 2f
        val cy = d.y + d.h / 2f
        return layout.items.firstOrNull {
            it.uid != uid && it.page == d.page && (it.type == "appicon" || it.type == "folder") &&
                cx >= it.x && cx <= it.x + it.w && cy >= it.y && cy <= it.y + it.h
        }
    }

    fun handleDrop(uid: String) {
        val target = findDropTarget(uid)
        dropTarget = null
        if (target == null) return
        val pkg = store.get("i_${uid}_pkg", "")
        if (pkg.isBlank()) return
        if (target.type == "folder") {
            val cur = store.get("i_${target.uid}_items", "").split("|").filter { it.isNotBlank() }
            if (pkg !in cur) store.put("i_${target.uid}_items", (cur + pkg).joinToString("|"))
        } else {
            val tpkg = store.get("i_${target.uid}_pkg", "")
            layout.update(target.uid) { it.copy(type = "folder") }
            store.put("i_${target.uid}_items", listOf(tpkg, pkg).filter { it.isNotBlank() }.joinToString("|"))
        }
        layout.remove(uid)
        layout.save()
        selected = target.uid
    }

    val actions = remember(layout) {
        LauncherActions(
            addIcon = { pkg ->
                val n = layout.items.count { it.page == "0:0" && it.type == "appicon" }
                layout.addIcon("0:0", pkg, n)
                Toast.makeText(ctx, ctx.getString(R.string.apps_added_main), Toast.LENGTH_SHORT).show()
            },
            removeItem = { uid -> layout.get(uid)?.let { deleteModule(it) } }
        )
    }

    Box(Modifier.fillMaxSize()) {
        BackgroundLayer(store)

        Box(
            Modifier
                .fillMaxSize()
                .onSizeChanged { boxW = it.width.toFloat().coerceAtLeast(1f); boxH = it.height.toFloat().coerceAtLeast(1f) }
                .nestedScroll(nested)
                .pointerInput(layout) {
                    val tracker = VelocityTracker()
                    detectDragGestures(
                        onDragStart = { navJob?.cancel(); axis = 0; tracker.resetTracking() },
                        onDragEnd = {
                            val v = tracker.calculateVelocity()
                            finishDrag(v.x, v.y)
                        },
                        onDragCancel = { finishDrag() }
                    ) { change, drag ->
                        change.consume()
                        tracker.addPosition(change.uptimeMillis, change.position)
                        panBy(drag.x, drag.y)
                    }
                }
                .pointerInput(scene, editing) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        if (down.isConsumed || editing || isLock) return@awaitEachGesture
                        var cancelled = false
                        val slop = viewConfiguration.touchSlop
                        val holdMs = store.getFloat("hold_ms", 900f).toLong()
                        val timedOut = withTimeoutOrNull(holdMs) {
                            while (!cancelled) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id }
                                if (change == null || change.isConsumed || !change.pressed ||
                                    (change.position - down.position).getDistance() > slop
                                ) {
                                    cancelled = true
                                }
                            }
                        } == null
                        if (timedOut && !cancelled) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            host.requestEdit()
                        }
                    }
                }
        ) {
            for (k in visibleKeys) {
                key(k) {
                    PageLayer(k, effect, curKey, { camX }, { camY }) {
                      CompositionLocalProvider(LocalPageNav provides pageNav, LocalLauncherActions provides actions) {
                        PageContent(
                            pageKey = k, layout = layout, host = host, realDir = realDir,
                            selectedUid = selected, groupPick = groupPick,
                            dropTarget = dropTarget,
                            onHover = { id -> dropTarget = if (id == null) null else findDropTarget(id)?.uid },
                            onDrop = { id -> handleDrop(id) },
                            showFallback = isLock && !hasUnlock && !editing && k == "0:0",
                            onTap = { uid ->
                                val gp = groupPick
                                if (gp != null) {
                                    groupPick = if (uid in gp) gp - uid else gp + uid
                                } else {
                                    selected = uid
                                }
                            }
                        )
                      }
                    }
                }
            }
        }

        // Modules pinned to every page (a dock) stay put while the pages move.
        val pinned = layout.items.filter { isPinned(it, store) }
        if (pinned.isNotEmpty()) {
            CompositionLocalProvider(
                LocalLayoutDirection provides LayoutDirection.Ltr,
                LocalLauncherActions provides actions
            ) {
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val pcw = constraints.maxWidth
                    val pch = constraints.maxHeight
                    for (p in pinned) {
                        val m = ModuleRegistry.find(p.type) ?: continue
                        key("pin" + p.uid) {
                            PlacedModule(
                                p, m, host, layout, pcw, pch,
                                selected = selected == p.uid,
                                picked = groupPick?.contains(p.uid) == true,
                                grouped = false,
                                realDir = realDir,
                                dropHighlight = false,
                                onHover = { },
                                onDrop = { }
                            ) {
                                val gp = groupPick
                                if (gp != null) {
                                    groupPick = if (p.uid in gp) gp - p.uid else gp + p.uid
                                } else {
                                    selected = p.uid
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showIconPicker) {
            AppPickerDialog(
                initial = emptySet(),
                onDone = { pkgs ->
                    pkgs.forEachIndexed { i, pkg -> layout.addIcon(curKey, pkg, i) }
                    showIconPicker = false
                },
                onDismiss = { showIconPicker = false }
            )
        }

        // Page dots for the real screen (not while editing).
        if (!editing && layout.pages.size > 1) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 6.dp)
                    .graphicsLayer { alpha = 0.6f }
            ) {
                PageMap(layout.pages, curKey, null, 6.dp)
            }
        }

        if (!editing && !isLock && store.getBool("home_edit_btn", true)) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(16.dp)
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.45f))
                    .clickable { host.requestEdit() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }

        if (editing) {
            // Floating toolbar for the selected module.
            val s = sel
            if (s != null && groupPick == null) {
                Row(
                    Modifier
                        .align(Alignment.TopCenter)
                        .statusBarsPadding()
                        .padding(top = 28.dp, start = 12.dp, end = 12.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.Black.copy(alpha = 0.7f))
                        .horizontalScroll(rememberScrollState())
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PillButton(stringResource(R.string.editor_settings)) { panel = "settings" }
                    if (s.group.isEmpty()) {
                        PillButton(stringResource(R.string.grp_group)) { groupPick = setOf(s.uid) }
                    } else {
                        PillButton(stringResource(R.string.grp_style)) { panel = "gstyle" }
                        PillButton(stringResource(R.string.grp_ungroup)) { layout.ungroup(s.group) }
                    }
                    PillButton(stringResource(R.string.editor_delete), danger = true) { deleteModule(s) }
                }
            }

            // Group picking bar.
            val gp = groupPick
            if (gp != null) {
                Row(
                    Modifier
                        .align(Alignment.TopCenter)
                        .statusBarsPadding()
                        .padding(top = 28.dp, start = 12.dp, end = 12.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.Black.copy(alpha = 0.75f))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(stringResource(R.string.grp_pick), color = Color.White, fontSize = 12.sp)
                    PillButton(stringResource(R.string.grp_make) + " (" + gp.size.toString().localizeDigits(host.lang) + ")", primary = true) {
                        if (gp.size >= 2) {
                            layout.group(gp)
                            groupPick = null
                        } else {
                            Toast.makeText(ctx, R.string.grp_need_two, Toast.LENGTH_SHORT).show()
                        }
                    }
                    PillButton(stringResource(R.string.editor_close)) { groupPick = null }
                }
            }

            // Bottom bar (kept well above the system gesture area).
            if (groupPick == null) {
                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 64.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color.Black.copy(alpha = 0.7f))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        PageMap(layout.pages, curKey, { k -> goTo(pageX(k), pageY(k)) }, 24.dp, host.lang, true)
                        Text(pageLabel(layout.pages, curKey, host.lang), color = Color.White, fontSize = 12.sp)
                        PillButton(stringResource(R.string.pg_title)) { panel = "pages" }
                    }
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(28.dp))
                            .background(Color.Black.copy(alpha = 0.7f))
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PillButton(stringResource(R.string.editor_add)) { panel = "add" }
                        PillButton(stringResource(R.string.editor_background)) { panel = "bg" }
                        PillButton(stringResource(R.string.editor_done), primary = true) { onExit() }
                    }
                }
            }

            when (panel) {
                "add" -> EditorPanel(stringResource(R.string.add_module_title), { panel = "none" }) {
                    for (cat in ModuleRegistry.categories) {
                        val mods = ModuleRegistry.all.filter { it.category == cat }
                        if (mods.isEmpty()) continue
                        Text(
                            stringResource(cat),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                        for (m in mods) {
                            val disabled = m.singleton && layout.items.any { it.type == m.id }
                            key(m.id) {
                                ModulePreviewCard(m, host, disabled) {
                                    if (m.id == "appicon") {
                                        panel = "none"
                                        showIconPicker = true
                                    } else {
                                        val np = layout.add(m, curKey)
                                        selected = np.uid
                                        panel = "none"
                                    }
                                }
                            }
                        }
                    }
                }

                "settings" -> {
                    val m = sel?.let { ModuleRegistry.find(it.type) }
                    if (sel != null && m != null) {
                        EditorPanel(stringResource(m.nameRes), { panel = "none" }) {
                            val inst = ModuleInstance(sel.uid, host)
                            if (sel.group.isEmpty()) {
                                SettingControls(inst, listOf<Setting>(StyleSetting) + m.settings)
                            } else {
                                SettingControls(inst, m.settings)
                            }
                            // Rotation
                            Column {
                                Text(stringResource(R.string.rot_label) + ": " + sel.rot.roundToInt().toString().localizeDigits(host.lang) + "\u00B0")
                                Slider(
                                    value = sel.rot,
                                    onValueChange = { v -> layout.update(sel.uid) { it.copy(rot = v) } },
                                    onValueChangeFinished = { layout.save() },
                                    valueRange = -180f..180f
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    PillButton("0\u00B0") { layout.update(sel.uid) { it.copy(rot = 0f) }; layout.save() }
                                    PillButton("90\u00B0") { layout.update(sel.uid) { it.copy(rot = 90f) }; layout.save() }
                                    PillButton("-90\u00B0") { layout.update(sel.uid) { it.copy(rot = -90f) }; layout.save() }
                                }
                            }
                            // Move to another page
                            if (layout.pages.size > 1) {
                                ChoiceRow(
                                    label = stringResource(R.string.pg_move),
                                    options = layout.pages.map { k ->
                                        val hint = pageHint(k, host.lang)
                                        k to (pageLabel(layout.pages, k, host.lang) + (if (hint.isEmpty()) "" else " \u2014 " + hint))
                                    },
                                    selected = sel.page
                                ) { k ->
                                    layout.update(sel.uid) { it.copy(page = k) }
                                    layout.save()
                                    selected = null
                                    panel = "none"
                                }
                            }
                            m.CustomSettings(inst)
                        }
                    }
                }

                "gstyle" -> {
                    val gid = sel?.group ?: ""
                    if (gid.isNotEmpty()) {
                        EditorPanel(stringResource(R.string.grp_style), { panel = "none" }) {
                            SettingControls(ModuleInstance(gid, host), listOf<Setting>(StyleSetting))
                        }
                    }
                }

                "pages" -> EditorPanel(stringResource(R.string.pg_title), { panel = "none" }) {
                    Text(stringResource(R.string.pg_add_title), style = MaterialTheme.typography.titleSmall)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val dirs = listOf(
                            Triple(R.string.pg_left, -1, 0), Triple(R.string.pg_right, 1, 0),
                            Triple(R.string.pg_up, 0, -1), Triple(R.string.pg_down, 0, 1)
                        )
                        for ((label, dx, dy) in dirs) {
                            if (!layout.hasPage(curX + dx, curY + dy)) {
                                PillButton(stringResource(label), primary = true) {
                                    val tx = curX + dx
                                    val ty = curY + dy
                                    layout.addPage(tx, ty)
                                    panel = "none"
                                    scope.launch {
                                        delay(60)
                                        goTo(tx, ty)
                                    }
                                }
                            }
                        }
                    }
                    ChoiceRow(
                        label = stringResource(R.string.pg_effect),
                        options = listOf(
                            "slide" to stringResource(R.string.fx_slide),
                            "fade" to stringResource(R.string.fx_fade),
                            "zoom" to stringResource(R.string.fx_zoom),
                            "depth" to stringResource(R.string.fx_depth),
                            "cube" to stringResource(R.string.fx_cube),
                            "flip" to stringResource(R.string.fx_flip),
                        ),
                        selected = effect
                    ) { store.put("page_effect", it) }
                    if (curKey != "0:0") {
                        PillButton(stringResource(R.string.pg_delete), danger = true) { deleteCurrentPage() }
                    }
                }

                "bg" -> EditorPanel(stringResource(R.string.bg_title), { panel = "none" }) {
                    ChoiceRow(
                        label = stringResource(R.string.bg_source),
                        options = listOf(
                            "own" to stringResource(R.string.bg_src_own),
                            "system" to stringResource(R.string.bg_src_system),
                        ),
                        selected = store.get("bg_source", "own")
                    ) { store.put("bg_source", it) }
                    if (store.get("bg_source", "own") == "system") {
                        Text(stringResource(R.string.bg_system_note), style = MaterialTheme.typography.bodySmall)
                        Button(onClick = {
                            val chooser = Intent.createChooser(
                                Intent(Intent.ACTION_SET_WALLPAPER),
                                ctx.getString(R.string.bg_change_wallpaper)
                            )
                            try { host.activity?.startActivity(chooser) } catch (e: Exception) { }
                        }) { Text(stringResource(R.string.bg_change_wallpaper)) }
                    } else {
                        Button(onClick = { host.pickBackground() }) {
                            Text(stringResource(R.string.bg_choose))
                        }
                        OutlinedButton(onClick = { removeBackground(store) }) {
                            Text(stringResource(R.string.bg_remove))
                        }
                        GradientSettings(store)
                    }
                }
            }
        }
    }
}

/** Applies the page-change effect. Reads the camera only while drawing, so motion never recomposes. */
@Composable
private fun PageLayer(
    key: String,
    effect: String,
    curKey: String,
    camX: () -> Float,
    camY: () -> Float,
    content: @Composable () -> Unit
) {
    val px = pageX(key)
    val py = pageY(key)
    val isCur = key == curKey
    Box(
        Modifier
            .fillMaxSize()
            .zIndex(if (effect == "depth" && isCur) 1f else 0f)
            .graphicsLayer {
                val relX = px - camX()
                val relY = py - camY()
                val horizontal = abs(relX) >= abs(relY)
                val o = if (horizontal) relX else relY
                val a = abs(o).coerceIn(0f, 1f)
                val w = size.width
                val h = size.height
                var tx = relX * w
                var ty = relY * h
                when (effect) {
                    "fade" -> {
                        tx = 0f; ty = 0f
                        alpha = 1f - a
                    }
                    "zoom" -> {
                        val s = 1f - 0.25f * a
                        scaleX = s; scaleY = s
                        alpha = 1f - 0.6f * a
                    }
                    "depth" -> if (!isCur) {
                        tx = 0f; ty = 0f
                        val s = 0.8f + 0.2f * (1f - a)
                        scaleX = s; scaleY = s
                        alpha = 1f - a
                    }
                    "cube" -> {
                        cameraDistance = 12f * density
                        if (horizontal) {
                            transformOrigin = TransformOrigin(if (o < 0f) 1f else 0f, 0.5f)
                            rotationY = 90f * o
                        } else {
                            transformOrigin = TransformOrigin(0.5f, if (o < 0f) 1f else 0f)
                            rotationX = -90f * o
                        }
                    }
                    "flip" -> {
                        tx = 0f; ty = 0f
                        cameraDistance = 12f * density
                        if (horizontal) rotationY = 180f * o else rotationX = -180f * o
                        alpha = if (a > 0.5f) 0f else 1f
                    }
                }
                translationX = tx
                translationY = ty
            }
    ) { content() }
}

/** One page: group panels first, then the modules, absolutely positioned. */
@Composable
private fun PageContent(
    pageKey: String,
    layout: LayoutStore,
    host: HostApi,
    realDir: LayoutDirection,
    selectedUid: String?,
    groupPick: Set<String>?,
    dropTarget: String?,
    onHover: (String?) -> Unit,
    onDrop: (String) -> Unit,
    showFallback: Boolean,
    onTap: (String) -> Unit
) {
    val density = LocalDensity.current
    // Placement uses absolute coordinates, so lay it out left-to-right
    // and give each module the real (possibly RTL) direction again.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val cw = constraints.maxWidth
            val ch = constraints.maxHeight
            val pageItems = layout.items.filter { it.page == pageKey && !isPinned(it, host.store) }
            val groups = pageItems.filter { it.group.isNotEmpty() }.groupBy { it.group }
                .filter { it.value.size >= 2 }
            val groupedUids = groups.values.flatten().map { it.uid }.toSet()

            for ((gid, ms) in groups) {
                key("grp$gid") {
                    val pad = 10.dp
                    val padPx = with(density) { pad.toPx() }
                    val gx = ms.minOf { it.x } * cw - padPx
                    val gy = ms.minOf { it.y } * ch - padPx
                    val gw = (ms.maxOf { it.x + it.w } - ms.minOf { it.x }) * cw + padPx * 2
                    val gh = (ms.maxOf { it.y + it.h } - ms.minOf { it.y }) * ch + padPx * 2
                    val spec = rememberPanelSpec(host.store, ModuleInstance(gid, host).s("style", "global"))
                    val highlight = host.editing && ms.any { it.uid == selectedUid }
                    Box(
                        Modifier
                            .absoluteOffset { IntOffset(gx.roundToInt(), gy.roundToInt()) }
                            .size(with(density) { gw.toDp() }, with(density) { gh.toDp() })
                            .panel(spec, RoundedCornerShape(spec.radius.dp))
                            .then(
                                if (highlight) Modifier.border(1.5.dp, GroupGreen, RoundedCornerShape(spec.radius.dp))
                                else Modifier
                            )
                    )
                }
            }

            for (p in pageItems) {
                val m = ModuleRegistry.find(p.type) ?: continue
                key(p.uid) {
                    PlacedModule(
                        p, m, host, layout, cw, ch,
                        selected = selectedUid == p.uid,
                        picked = groupPick?.contains(p.uid) == true,
                        grouped = p.uid in groupedUids,
                        realDir = realDir,
                        dropHighlight = dropTarget == p.uid,
                        onHover = onHover,
                        onDrop = onDrop
                    ) { onTap(p.uid) }
                }
            }

            // Safety net: if no unlock module exists, show a plain slider.
            if (showFallback) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(horizontal = 32.dp, vertical = 32.dp)
                        .fillMaxWidth()
                        .height(64.dp)
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides realDir) {
                        SlideUnlockModule.Content(ModuleInstance("fallback", host))
                    }
                }
            }
        }
    }
}

/** A small map of the page grid; the current page is highlighted. */
@Composable
private fun PageMap(
    pages: List<String>, cur: String, onPick: ((String) -> Unit)?,
    cell: androidx.compose.ui.unit.Dp, lang: String = "en", numbers: Boolean = false
) {
    val minX = pages.minOf { pageX(it) }
    val maxX = pages.maxOf { pageX(it) }
    val minY = pages.minOf { pageY(it) }
    val maxY = pages.maxOf { pageY(it) }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            for (y in minY..maxY) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (x in minX..maxX) {
                        val k = pageKey(x, y)
                        val exists = k in pages
                        Box(
                            Modifier
                                .size(cell)
                                .clip(RoundedCornerShape(3.dp))
                                .background(
                                    when {
                                        !exists -> Color.Transparent
                                        k == cur -> Color.White
                                        else -> Color.White.copy(alpha = 0.35f)
                                    }
                                )
                                .then(
                                    if (exists && onPick != null) Modifier.clickable { onPick(k) } else Modifier
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (numbers && exists) {
                                Text(
                                    (pages.indexOf(k) + 1).toString().localizeDigits(lang),
                                    fontSize = 11.sp,
                                    color = if (k == cur) Color(0xFF1B1B1F) else Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlacedModule(
    p: Placement,
    module: LockModule,
    host: HostApi,
    layout: LayoutStore,
    cw: Int,
    ch: Int,
    selected: Boolean,
    picked: Boolean,
    grouped: Boolean,
    realDir: LayoutDirection,
    dropHighlight: Boolean,
    onHover: (String?) -> Unit,
    onDrop: (String) -> Unit,
    onTap: () -> Unit
) {
    val density = LocalDensity.current
    val inst = remember(p.uid, grouped, host) { ModuleInstance(p.uid, host, grouped) }
    val wDp = with(density) { (p.w * cw).toDp() }
    val hDp = with(density) { (p.h * ch).toDp() }

    Box(
        Modifier
            .absoluteOffset { IntOffset((p.x * cw).roundToInt(), (p.y * ch).roundToInt()) }
            .size(wDp, hDp)
            .graphicsLayer { rotationZ = p.rot }
    ) {
        val groupFg = if (grouped) {
            rememberPanelSpec(host.store, ModuleInstance(p.group, host).s("style", "global")).autoFg
        } else {
            null
        }
        ModuleBody(module, inst, host, realDir, noPanel = grouped, fgOverride = groupFg)

        if (host.editing) {
            // Transparent layer that grabs touches: drag = move, tap = select.
            Box(
                Modifier
                    .fillMaxSize()
                    .border(
                        if (dropHighlight) 4.dp else if (selected || picked) 2.dp else 1.dp,
                        when {
                            dropHighlight -> GroupGreen
                            picked -> GroupGreen
                            selected -> Accent
                            else -> Color.White.copy(alpha = 0.4f)
                        },
                        RoundedCornerShape(12.dp)
                    )
                    .pointerInput(p.uid) { detectTapGestures(onTap = { onTap() }) }
                    .pointerInput(p.uid, cw, ch) {
                        detectDragGestures(
                            onDragStart = { onTap() },
                            onDragEnd = {
                                layout.save()
                                onDrop(p.uid)
                            },
                            onDragCancel = {
                                layout.save()
                                onHover(null)
                            }
                        ) { change, drag ->
                            change.consume()
                            val cur = layout.get(p.uid) ?: return@detectDragGestures
                            // The layer may be rotated: turn the finger movement back to screen axes.
                            val th = Math.toRadians(cur.rot.toDouble())
                            val gx = (drag.x * cos(th) - drag.y * sin(th)).toFloat()
                            val gy = (drag.x * sin(th) + drag.y * cos(th)).toFloat()
                            if (cur.group.isNotEmpty()) {
                                layout.moveGroup(cur.group, gx / cw, gy / ch)
                            } else {
                                layout.update(p.uid) {
                                    it.copy(
                                        x = (it.x + gx / cw).coerceIn(0f, (1f - it.w).coerceAtLeast(0f)),
                                        y = (it.y + gy / ch).coerceIn(0f, (1f - it.h).coerceAtLeast(0f))
                                    )
                                }
                            }
                            onHover(p.uid)
                        }
                    }
            )

            if (selected) {
                // Resize handle (bottom-right corner).
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .size(44.dp)
                        .pointerInput(p.uid, cw, ch) {
                            detectDragGestures(
                                onDragEnd = { layout.save() },
                                onDragCancel = { layout.save() }
                            ) { change, drag ->
                                change.consume()
                                layout.update(p.uid) { cur ->
                                    cur.copy(
                                        w = (cur.w + drag.x / cw).coerceIn(0.1f, maxOf(0.1f, 1f - cur.x)),
                                        h = (cur.h + drag.y / ch).coerceIn(0.05f, maxOf(0.05f, 1f - cur.y))
                                    )
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(18.dp).clip(CircleShape).background(Accent))
                }
            }
        }
    }
}

/** One module drawn exactly as it appears on the screen (panel style included). */
@Composable
fun ModuleBody(
    module: LockModule, inst: ModuleInstance, host: HostApi, realDir: LayoutDirection,
    noPanel: Boolean = false, fgOverride: Color? = null
) {
    val spec = rememberPanelSpec(host.store, if (inst.grouped) "none" else inst.s("style", "global"))
    // Light panels (paper, sticker) and dark ones (neon) need their own readable "auto" text color.
    val fg = fgOverride ?: spec.autoFg
    CompositionLocalProvider(LocalLayoutDirection provides realDir, LocalAutoFg provides fg) {
        if (module.ownsPanel) {
            Box(Modifier.fillMaxSize()) { module.Content(inst) }
        } else if (noPanel) {
            Box(Modifier.fillMaxSize().padding(2.dp).clipToBounds()) { module.Content(inst) }
        } else {
            val pad = if (spec.style == "none") 0.dp else module.panelPadding
            Box(Modifier.fillMaxSize().panel(spec, RoundedCornerShape(spec.radius.dp))) {
                Box(Modifier.fillMaxSize().padding(pad).clipToBounds()) { module.Content(inst) }
            }
        }
    }
}

/** A card in the Add-module list: name, a live sample on a colorful backdrop, and an Add button. */
@Composable
private fun ModulePreviewCard(module: LockModule, host: HostApi, disabled: Boolean, onAdd: () -> Unit) {
    val conf = LocalConfiguration.current
    val onSurface = MaterialTheme.colorScheme.onSurface
    val realDir = LocalLayoutDirection.current
    val inst = remember(module.id, host) { ModuleInstance("pv_${module.id}", host) }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(onSurface.copy(alpha = 0.06f))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(module.nameRes), Modifier.weight(1f), fontWeight = FontWeight.Bold)
            if (disabled) {
                Text(stringResource(R.string.already_added), color = Color.Gray, fontSize = 12.sp)
            } else {
                PillButton(stringResource(R.string.editor_add), primary = true) { onAdd() }
            }
        }
        Spacer(Modifier.height(10.dp))
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val boxWidth = maxWidth
            val wDp = minOf(boxWidth, (module.defaultW * conf.screenWidthDp).dp)
            val hDp = (module.defaultH * conf.screenHeightDp).dp.coerceIn(48.dp, 220.dp)
            Box(
                Modifier
                    .align(Alignment.Center)
                    .size(wDp, hDp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(listOf(Color(0xFFFFC857), Color(0xFF7AB8FF), Color(0xFFB78CFF)))
                    )
            ) {
                ModuleBody(module, inst, host, realDir)
                // Samples are only for looking: swallow touches.
                Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } })
            }
        }
    }
}


/** "Main page" or "Page 3": pages are numbered in the order they were created. */
@Composable
private fun pageLabel(pages: List<String>, key: String, lang: String): String {
    if (key == "0:0") return stringResource(R.string.pg_main)
    val n = (pages.indexOf(key) + 1).coerceAtLeast(1)
    return stringResource(R.string.pg_num, n.toString().localizeDigits(lang))
}

/** Where a page is relative to the main page, e.g. "Right 2" or "Up". */
@Composable
private fun pageHint(key: String, lang: String): String {
    val x = pageX(key)
    val y = pageY(key)
    if (key == "0:0") return ""
    val horizontal = if (x == 0) "" else
        stringResource(if (x > 0) R.string.pg_right else R.string.pg_left) +
            (if (abs(x) > 1) " " + abs(x).toString().localizeDigits(lang) else "")
    val vertical = if (y == 0) "" else
        stringResource(if (y > 0) R.string.pg_down else R.string.pg_up) +
            (if (abs(y) > 1) " " + abs(y).toString().localizeDigits(lang) else "")
    return listOf(horizontal, vertical).filter { it.isNotEmpty() }.joinToString(" + ")
}


/** A dock set to "show on every page" stays on screen while pages move. */
fun isPinned(p: Placement, store: SettingsStore): Boolean =
    p.type == "dock" && store.getBool("i_${p.uid}_allpages", true)

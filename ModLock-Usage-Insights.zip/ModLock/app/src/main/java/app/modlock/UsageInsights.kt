package app.modlock

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.*
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

/** Device-local usage event collector. It runs only while the existing lock service is active. */
object UsageInsightsTracker {
    private const val PREF = "usage_insights_data"
    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun day(t: Long = System.currentTimeMillis()) = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(t))
    private fun enabled(c: Context, key: String) = SettingsStore(c).getBool("insight_$key", true)

    @Suppress("DEPRECATION")
    fun start(c: Context): BroadcastReceiver {
        val app = c.applicationContext
        val p = prefs(app)
        pruneOldData(app)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val now = System.currentTimeMillis()
                when (intent.action) {
                    Intent.ACTION_SCREEN_ON -> if (enabled(app, "screen")) {
                        if (p.getLong("screen_start", 0L) == 0L) p.edit().putLong("screen_start", now).apply()
                        sampleNetwork(app, now)
                    }
                    Intent.ACTION_SCREEN_OFF -> {
                        closeScreen(app, now)
                        sampleNetwork(app, now)
                    }
                    Intent.ACTION_USER_PRESENT -> if (enabled(app, "unlock")) {
                        p.edit().putInt("${day()}_unlock", p.getInt("${day()}_unlock", 0) + 1).apply()
                    }
                    Intent.ACTION_BATTERY_CHANGED -> if (enabled(app, "battery")) {
                        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                        if (level >= 0) p.edit().putInt("battery_level", level * 100 / scale).apply()
                    }
                    Intent.ACTION_POWER_CONNECTED -> if (enabled(app, "battery")) {
                        p.edit().putInt("${day()}_charges", p.getInt("${day()}_charges", 0) + 1).putLong("charge_start", now).apply()
                    }
                    Intent.ACTION_POWER_DISCONNECTED -> if (enabled(app, "battery")) {
                        val start = p.getLong("charge_start", 0L)
                        if (start > 0L) p.edit().putLong("${day()}_charge_ms", p.getLong("${day()}_charge_ms", 0L) + (now - start).coerceAtLeast(0L)).remove("charge_start").apply()
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_BATTERY_CHANGED); addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED) else app.registerReceiver(receiver, filter)
        val pm = app.getSystemService(PowerManager::class.java)
        if (pm?.isInteractive == true && enabled(app, "screen") && p.getLong("screen_start", 0L) == 0L) p.edit().putLong("screen_start", System.currentTimeMillis()).apply()
        sampleNetwork(app, System.currentTimeMillis())
        if (enabled(app, "battery")) {
            val batteryIntent = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100)?.coerceAtLeast(1) ?: 100
            if (level >= 0) p.edit().putInt("battery_level", level * 100 / scale).apply()
        }
        return receiver
    }

    fun stop(c: Context, receiver: BroadcastReceiver?) {
        try { if (receiver != null) c.applicationContext.unregisterReceiver(receiver) } catch (_: Exception) { }
        closeScreen(c.applicationContext, System.currentTimeMillis())
    }

    private fun closeScreen(c: Context, now: Long) {
        val p = prefs(c); val start = p.getLong("screen_start", 0L)
        if (start > 0L && enabled(c, "screen")) {
            var cursor = start
            while (cursor < now) {
                val midnight = Calendar.getInstance().apply { timeInMillis = cursor; add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                val end = minOf(now, midnight)
                val k = "${day(cursor)}_screen_ms"
                p.edit().putLong(k, p.getLong(k, 0L) + (end - cursor).coerceAtLeast(0L)).apply()
                cursor = end
            }
        }
        p.edit().remove("screen_start").apply()
    }

    private fun sampleNetwork(c: Context, now: Long) {
        if (!enabled(c, "network")) return
        val rx = TrafficStats.getTotalRxBytes(); val tx = TrafficStats.getTotalTxBytes()
        if (rx == TrafficStats.UNSUPPORTED.toLong() || tx == TrafficStats.UNSUPPORTED.toLong()) return
        val p = prefs(c); val oldRx = p.getLong("net_rx", -1L); val oldTx = p.getLong("net_tx", -1L)
        if (oldRx >= 0 && oldTx >= 0 && rx >= oldRx && tx >= oldTx) {
            val dr = rx - oldRx; val dt = tx - oldTx
            val k = day(now)
            p.edit().putLong("${k}_rx", p.getLong("${k}_rx", 0L) + dr).putLong("${k}_tx", p.getLong("${k}_tx", 0L) + dt).apply()
        }
        p.edit().putLong("net_rx", rx).putLong("net_tx", tx).apply()
    }

    fun refreshNetwork(c: Context) = sampleNetwork(c, System.currentTimeMillis())

    fun setCollection(c: Context, key: String, on: Boolean) {
        val p = prefs(c)
        if (key == "screen" && !on) closeScreen(c, System.currentTimeMillis())
        if (key == "network" && !on) sampleNetwork(c, System.currentTimeMillis())
        if (key == "battery" && !on) p.edit().remove("charge_start").apply()
        SettingsStore(c).putBool("insight_$key", on)
        if (on && key == "screen") {
            if (c.getSystemService(PowerManager::class.java)?.isInteractive == true)
                p.edit().putLong("screen_start", System.currentTimeMillis()).apply()
        }
        if (on && key == "network") {
            p.edit().putLong("net_rx", TrafficStats.getTotalRxBytes()).putLong("net_tx", TrafficStats.getTotalTxBytes()).apply()
        }
    }

    private fun pruneOldData(c: Context) {
        val cutoff = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -365) }.timeInMillis
        val cutoffDay = day(cutoff)
        val p = prefs(c)
        val edit = p.edit()
        p.all.keys.filter { it.length >= 9 && it.substring(0, 8).all(Char::isDigit) && it.substring(0, 8) < cutoffDay && it[8] == '_' }.forEach { edit.remove(it) }
        edit.apply()
    }

    fun getLong(c: Context, key: String, default: Long = 0L) = prefs(c).getLong(key, default)
    fun getInt(c: Context, key: String, default: Int = 0) = prefs(c).getInt(key, default)
    fun clear(c: Context) {
        val p = prefs(c)
        p.edit().clear().apply()
        if (enabled(c, "screen") && c.getSystemService(PowerManager::class.java)?.isInteractive == true)
            p.edit().putLong("screen_start", System.currentTimeMillis()).apply()
        if (enabled(c, "network"))
            p.edit().putLong("net_rx", TrafficStats.getTotalRxBytes()).putLong("net_tx", TrafficStats.getTotalTxBytes()).apply()
    }
}

class UsageInsightsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = SettingsStore(this)
        setContent { LocalizedTheme(store) { UsageInsightsScreen(this, store) } }
    }
}

private fun usageAccessGranted(context: Context): Boolean {
    val ops = context.getSystemService(AppOpsManager::class.java)
    @Suppress("DEPRECATION")
    val mode = if (Build.VERSION.SDK_INT >= 29) ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), context.packageName)
    else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), context.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}

private data class AppUsage(val label: String, val millis: Long)
private fun appUsage(context: Context): List<AppUsage> {
    if (!usageAccessGranted(context)) return emptyList()
    val end = System.currentTimeMillis(); val start = Calendar.getInstance().apply { timeInMillis = end; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
    return try {
        val pm = context.packageManager
        context.getSystemService(UsageStatsManager::class.java).queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
            .orEmpty().filter { it.totalTimeInForeground > 0 && it.packageName != context.packageName }
            .map { s ->
                val label = try { pm.getApplicationLabel(pm.getApplicationInfo(s.packageName, 0)).toString() } catch (_: Exception) { s.packageName }
                AppUsage(label, s.totalTimeInForeground)
            }
            .sortedByDescending { it.millis }.take(6)
    } catch (_: Exception) { emptyList() }
}

@Composable
private fun UsageInsightsScreen(activity: ComponentActivity, store: SettingsStore) {
    val fa = store.lang == "fa"
    fun t(f: String, e: String) = if (fa) f else e
    var refresh by remember { mutableIntStateOf(0) }
    var range by remember { mutableStateOf("today") }
    val ctx = LocalContext.current
    val dateKeys = remember(range, refresh) {
        val n = if (range == "week") 7 else 1
        (0 until n).map { i -> Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }.let { SimpleDateFormat("yyyyMMdd", Locale.US).format(it.time) } }.reversed()
    }
    val unlocks = dateKeys.sumOf { UsageInsightsTracker.getInt(ctx, "${it}_unlock").toLong() }
    val recordedScreenMs = dateKeys.sumOf { UsageInsightsTracker.getLong(ctx, "${it}_screen_ms") }
    val liveStart = UsageInsightsTracker.getLong(ctx, "screen_start")
    val liveScreenMs = if (liveStart > 0L && ctx.getSystemService(PowerManager::class.java)?.isInteractive == true) System.currentTimeMillis() - liveStart else 0L
    val screenMs = recordedScreenMs + liveScreenMs
    val rx = dateKeys.sumOf { UsageInsightsTracker.getLong(ctx, "${it}_rx") }
    val tx = dateKeys.sumOf { UsageInsightsTracker.getLong(ctx, "${it}_tx") }
    val battery = UsageInsightsTracker.getInt(ctx, "battery_level", -1)
    val apps = remember(refresh) { appUsage(ctx) }
    val access = remember(refresh) { usageAccessGranted(ctx) }
    val dayUnlocks = dateKeys.map { UsageInsightsTracker.getInt(ctx, "${it}_unlock").toFloat() }
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { activity.finish() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = t("بازگشت", "Back")) }
            Column(Modifier.weight(1f)) {
                Text(t("گزارش استفاده", "Usage insights"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(t("نمای کلی فعالیت دستگاه", "Your device activity overview"), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            TextButton(onClick = { refresh++ }) { Text(t("تازه‌سازی", "Refresh")) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF282345), Color(0xFF17405A)))).padding(20.dp)) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Info, null, tint = Color(0xFFB9A7FF)); Spacer(Modifier.width(8.dp)); Text(t("داشبورد هوشمند", "INSIGHTS DASHBOARD"), color = Color(0xFFD8D2FF), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(12.dp))
                    Text(formatDuration(screenMs, fa), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text(t("زمان روشن بودن صفحه", "Screen-on time"), color = Color(0xFFC8C5D8), fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        HeroMini(t("بازشدن قفل", "Unlocks"), unlocks.toString().localizeDigits(store.lang), Color(0xFFB9A7FF), Modifier.weight(1f))
                        HeroMini(t("دانلود", "Downloaded"), formatBytes(rx, fa), Color(0xFF65D6F2), Modifier.weight(1f))
                        HeroMini(t("آپلود", "Uploaded"), formatBytes(tx, fa), Color(0xFF66D9B0), Modifier.weight(1f))
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(selected = range == "today", onClick = { range = "today" }, label = { Text(t("امروز", "Today")) })
                FilterChip(selected = range == "week", onClick = { range = "week" }, label = { Text(t("۷ روز اخیر", "Last 7 days")) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(t("بازشدن قفل", "Unlocks"), unlocks.toString().localizeDigits(store.lang), t("تعداد دفعات", "Unlock events"), Icons.Filled.Lock, Color(0xFF9B87FF), Modifier.weight(1f))
                MetricCard(t("صفحه روشن", "Screen on"), formatDuration(screenMs, fa), t("زمان تجمعی", "Total duration"), Icons.Filled.Lock, Color(0xFF55B8FF), Modifier.weight(1f))
            }
            if (!store.getBool("service_enabled", false)) {
                Text(t("برای ثبت پیوسته تعداد بازشدن قفل، زمان روشن بودن صفحه و نمونه‌برداری اینترنت، سرویس قفل ویترین باید فعال باشد.", "Keep Vitrin's lock service enabled to continuously record unlocks, screen-on time, and network samples."), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            SectionTitle(t("روند بازشدن قفل", "Unlock activity"))
            Surface(shape = RoundedCornerShape(24.dp), color = cs.surface) {
                Column(Modifier.padding(16.dp)) {
                    BarChart(dayUnlocks, dateKeys.map { it.takeLast(2) }, Color(0xFF9B87FF))
                    Text(t("آمار بر اساس رویدادهای ثبت‌شده هنگام فعال بودن سرویس ویترین است.", "Events are collected while Vitrin's lock service is running."), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            SectionTitle(t("مصرف اینترنت", "Network usage"))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(t("دریافت", "Received"), formatBytes(rx, fa), t("مجموع دانلود", "Download total"), Icons.Filled.Info, Color(0xFF55C8E8), Modifier.weight(1f))
                MetricCard(t("ارسال", "Sent"), formatBytes(tx, fa), t("مجموع آپلود", "Upload total"), Icons.Filled.Info, Color(0xFF43CFA0), Modifier.weight(1f))
            }
            Text(t("مقادیر شبکه از شمارنده تجمعی اندروید نمونه‌برداری می‌شوند؛ ممکن است با راه‌اندازی مجدد گوشی یا خاموش بودن سرویس، بخشی از ترافیک ثبت نشود.", "Network totals are sampled from Android cumulative counters. Traffic may be missed while the service is stopped or across device restarts."), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            if (store.getBool("insight_apps", true)) {
            SectionTitle(t("برنامه‌های پرمصرف امروز", "Top apps today"))
            if (!access) {
                Surface(shape = RoundedCornerShape(22.dp), color = cs.surface) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(t("برای نمایش زمان استفاده هر برنامه، دسترسی Usage Access لازم است.", "Usage Access is required to show per-app screen time."), style = MaterialTheme.typography.bodyMedium)
                        Button(onClick = { activity.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) { Text(t("فعال‌سازی دسترسی", "Grant usage access")) }
                    }
                }
            } else if (apps.isEmpty()) Text(t("هنوز داده‌ای برای امروز موجود نیست.", "No app usage data available yet."), color = cs.onSurfaceVariant)
            else Surface(shape = RoundedCornerShape(22.dp), color = cs.surface) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    apps.forEachIndexed { i, a ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}".localizeDigits(store.lang), color = cs.primary, fontWeight = FontWeight.Bold, modifier = Modifier.width(26.dp))
                            Text(a.label, modifier = Modifier.weight(1f), maxLines = 1)
                            Text(formatDuration(a.millis, fa), fontWeight = FontWeight.SemiBold)
                        }
                        if (i != apps.lastIndex) HorizontalDivider(color = cs.outlineVariant.copy(alpha = .45f))
                    }
                }
            }
            }
            SectionTitle(t("باتری", "Battery"))
            Surface(shape = RoundedCornerShape(22.dp), color = cs.surface) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Info, null, tint = Color(0xFF43CFA0), modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (battery >= 0) "${battery}%".localizeDigits(store.lang) else t("در انتظار داده باتری", "Waiting for battery data"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text(t("آخرین سطح باتری ثبت‌شده", "Last recorded battery level"), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${dateKeys.sumOf { UsageInsightsTracker.getInt(ctx, "${it}_charges") }}".localizeDigits(store.lang) + " " + t("اتصال شارژ", "charge sessions"), style = MaterialTheme.typography.bodySmall)
                        Text(t("مدت شارژ: ", "Charging: ") + formatDuration(dateKeys.sumOf { UsageInsightsTracker.getLong(ctx, "${it}_charge_ms") }, fa), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                }
            }
            SectionTitle(t("تنظیمات جمع‌آوری", "Collection settings"))
            Surface(shape = RoundedCornerShape(22.dp), color = cs.surface) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    InsightSwitch(t("تعداد بازشدن قفل", "Unlock count"), "unlock", store)
                    HorizontalDivider()
                    InsightSwitch(t("مدت روشن بودن صفحه", "Screen-on duration"), "screen", store)
                    HorizontalDivider()
                    InsightSwitch(t("مصرف اینترنت", "Network traffic"), "network", store)
                    HorizontalDivider()
                    InsightSwitch(t("اطلاعات باتری و شارژ", "Battery and charging"), "battery", store)
                    HorizontalDivider()
                    InsightSwitch(t("گزارش برنامه‌ها", "Per-app usage"), "apps", store)
                }
            }
            OutlinedButton(onClick = { UsageInsightsTracker.clear(ctx); refresh++ }, modifier = Modifier.fillMaxWidth()) { Text(t("پاک کردن همه گزارش‌ها", "Clear all reports")) }
            Text(t("اطلاعات فقط روی همین دستگاه ذخیره می‌شود. آمار پیش از فعال‌سازی جمع‌آوری، قابل بازیابی نیست.", "Data is stored only on this device. Historical data from before collection was enabled cannot be reconstructed."), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable private fun HeroMini(label: String, value: String, tint: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .09f)).padding(10.dp)) {
        Text(value, color = tint, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
        Text(label, color = Color.White.copy(alpha = .72f), fontSize = 10.sp, maxLines = 1)
    }
}
@Composable private fun MetricCard(title: String, value: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(modifier.clip(RoundedCornerShape(22.dp)).background(cs.surface).padding(15.dp)) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp)); Spacer(Modifier.height(10.dp))
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(title, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        Text(sub, style = MaterialTheme.typography.labelSmall, color = tint)
    }
}
@Composable private fun SectionTitle(s: String) { Text(s, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp)) }
@Composable private fun InsightSwitch(label: String, key: String, store: SettingsStore, enabled: Boolean = true) {
    val context = LocalContext.current
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = store.getBool("insight_$key", true), enabled = enabled, onCheckedChange = { UsageInsightsTracker.setCollection(context, key, it) })
    }
}
@Composable private fun BarChart(values: List<Float>, labels: List<String>, color: Color) {
    val cs = MaterialTheme.colorScheme
    Canvas(Modifier.fillMaxWidth().height(145.dp)) {
        val maxV = max(1f, values.maxOrNull() ?: 1f); val gap = size.width / (values.size * 2f + 1f); val barW = gap
        repeat(values.size) { i ->
            val h = (values[i] / maxV) * (size.height - 28.dp.toPx()); val x = gap + i * gap * 2
            drawRoundRect(color.copy(alpha = .18f), androidx.compose.ui.geometry.Offset(x, 0f), androidx.compose.ui.geometry.Size(barW, size.height - 24.dp.toPx()), cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f))
            drawRoundRect(color, androidx.compose.ui.geometry.Offset(x, size.height - 24.dp.toPx() - h), androidx.compose.ui.geometry.Size(barW, h.coerceAtLeast(3f)), cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f))
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { labels.forEach { Text(it, fontSize = 10.sp, color = cs.onSurfaceVariant) } }
}
private fun formatDuration(ms: Long, fa: Boolean): String {
    val mins = ms.coerceAtLeast(0) / 60000; val h = mins / 60; val m = mins % 60
    return if (h > 0) "${h}h ${m}m".localizeDigits(if (fa) "fa" else "en") else "${m}m".localizeDigits(if (fa) "fa" else "en")
}
private fun formatBytes(bytes: Long, fa: Boolean): String {
    val v = bytes.coerceAtLeast(0).toDouble(); val (n, unit) = when { v >= 1024.0 * 1024.0 * 1024.0 -> v / (1024.0 * 1024.0 * 1024.0) to "GB"; v >= 1024.0 * 1024.0 -> v / (1024.0 * 1024.0) to "MB"; v >= 1024.0 -> v / 1024.0 to "KB"; else -> v to "B" }
    return String.format(Locale.US, "%.1f %s", n, unit).localizeDigits(if (fa) "fa" else "en")
}

package app.modlock

import android.icu.util.Calendar
import android.icu.util.GregorianCalendar
import android.icu.util.ULocale
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object CalendarModule : LockModule {
    override val id = "calendar"
    override val nameRes = R.string.mod_calendar
    override val category = R.string.cat_time
    override val defaultW = 0.88f
    override val defaultH = 0.45f
    override val settings: List<Setting> = listOf(
        ChoiceSetting(
            "type", R.string.calendar_type,
            listOf(
                "auto" to R.string.cal_auto,
                "jalali" to R.string.cal_jalali,
                "gregorian" to R.string.cal_gregorian,
            ),
            "auto"
        ),
        SwitchSetting("grid", R.string.cal_grid, true),
        SwitchSetting("events", R.string.cal_events, true),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val lang = inst.lang
        val type = inst.s("type", "auto")
        val jalali = type == "jalali" || (type == "auto" && lang == "fa")
        val showGrid = inst.b("grid", true)
        val color = inst.color("color")

        val cal: Calendar =
            if (jalali) Calendar.getInstance(ULocale("fa_IR@calendar=persian")) else GregorianCalendar()
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH)
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val dow = cal.get(Calendar.DAY_OF_WEEK) // 1 = Sunday

        val events = jalali && inst.b("events", true)
        val todayOccasions = remember(year, month, day, events, lang) {
            if (events) occasionsOn(cal.timeInMillis, month + 1, day).map { it.name(lang) } else emptyList()
        }
        val weekdays = stringArrayResource(R.array.weekdays)
        val months = stringArrayResource(
            if (jalali) R.array.months_jalali else R.array.months_gregorian
        )

        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val s = minOf(
                maxWidth.value / 320f,
                maxHeight.value / (if (showGrid) 330f else 80f)
            ).coerceIn(0.4f, 3f)

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(weekdays[dow - 1], color = color, fontSize = (20 * s).sp)
                Text(
                    "$day ${months[month]} $year".localizeDigits(lang),
                    color = color, fontSize = (26 * s).sp, fontWeight = FontWeight.Medium
                )
                if (todayOccasions.isNotEmpty()) {
                    Text(
                        todayOccasions.joinToString(" · "),
                        color = Color(0xFFEF5350), fontSize = (13 * s).sp
                    )
                }
                if (showGrid) {
                    Spacer(Modifier.height((10 * s).dp))
                    MonthGrid(cal, jalali, events, lang, s, color)
                }
            }
        }
    }
}

@Composable
private fun MonthGrid(cal: Calendar, jalali: Boolean, events: Boolean, lang: String, s: Float, color: Color) {
    val today = cal.get(Calendar.DAY_OF_MONTH)
    val first = cal.clone() as Calendar
    first.set(Calendar.DAY_OF_MONTH, 1)
    val weekStart = if (jalali) Calendar.SATURDAY else Calendar.SUNDAY
    val offset = (first.get(Calendar.DAY_OF_WEEK) - weekStart + 7) % 7
    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val short = stringArrayResource(R.array.weekdays_short)
    val rows = (offset + daysInMonth + 6) / 7
    val curMonth = cal.get(Calendar.MONTH)
    val holidays: Set<Int> = remember(cal.get(Calendar.YEAR), curMonth, events) {
        val set = mutableSetOf<Int>()
        if (events) {
            for (d in 1..daysInMonth) {
                val t = cal.clone() as Calendar
                t.set(Calendar.DAY_OF_MONTH, d)
                if (occasionsOn(t.timeInMillis, curMonth + 1, d).any { it.holiday }) set.add(d)
            }
        }
        set
    }

    Column(
        Modifier
            .fillMaxWidth()
            .padding((4 * s).dp)
    ) {
        Row(Modifier.fillMaxWidth()) {
            for (i in 0..6) Cell(short[(weekStart - 1 + i) % 7], false, true, false, s, color)
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0..6) {
                    val d = r * 7 + c - offset + 1
                    if (d in 1..daysInMonth) {
                        val red = (jalali && c == 6) || d in holidays
                        Cell(d.toString().localizeDigits(lang), d == today, false, red, s, color)
                    } else {
                        Cell("", false, false, false, s, color)
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.Cell(text: String, highlight: Boolean, dim: Boolean, red: Boolean, s: Float, color: Color) {
    Box(Modifier.weight(1f).height((30 * s).dp), contentAlignment = Alignment.Center) {
        if (highlight) {
            Box(Modifier.size((26 * s).dp).clip(CircleShape).background(color.copy(alpha = 0.9f)))
        }
        Text(
            text,
            fontSize = (13 * s).sp,
            color = when {
                highlight -> if (color.luminance() > 0.5f) Color.Black else Color.White
                dim -> color.copy(alpha = 0.6f)
                red -> Color(0xFFEF5350)
                else -> color
            }
        )
    }
}

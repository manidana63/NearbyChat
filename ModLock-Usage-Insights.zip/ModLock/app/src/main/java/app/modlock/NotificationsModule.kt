package app.modlock

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private class NItem(
    val key: String,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val open: PendingIntent?,
)

private fun readNotifications(ctx: Context): List<NItem> {
    val svc = MediaListener.instance ?: return emptyList()
    val pm = ctx.packageManager
    return try {
        svc.activeNotifications
            .filter { sbn ->
                val n = sbn.notification
                sbn.packageName != ctx.packageName &&
                    (n.flags and Notification.FLAG_ONGOING_EVENT) == 0 &&
                    (n.flags and Notification.FLAG_GROUP_SUMMARY) == 0
            }
            .sortedByDescending { it.postTime }
            .map { sbn ->
                val n = sbn.notification
                val secret = n.visibility == Notification.VISIBILITY_SECRET
                val extras = n.extras
                val app = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
                } catch (e: Exception) {
                    sbn.packageName
                }
                NItem(
                    sbn.key, sbn.packageName, app,
                    if (secret) "" else extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "",
                    if (secret) "" else extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "",
                    n.contentIntent
                )
            }
    } catch (e: Exception) {
        emptyList()
    }
}

/** Your latest notifications; tapping one opens it (after the system unlock if needed). */
object NotificationsModule : LockModule {
    override val id = "notifs"
    override val nameRes = R.string.mod_notifs
    override val category = R.string.cat_access
    override val defaultW = 0.88f
    override val defaultH = 0.22f
    override val settings: List<Setting> = listOf(
        StepSetting("count", R.string.notif_count, 1, 8, 3),
        SwitchSetting("hide_text", R.string.notif_hide, false),
        ColorSetting("color", R.string.setting_color, "auto"),
        AnimSetting,
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val color = inst.color("color")
        val count = (inst.s("count", "3").toIntOrNull() ?: 3).coerceIn(1, 8)
        val hideText = inst.b("hide_text", false)
        var allowed by remember { mutableStateOf(true) }
        var list by remember { mutableStateOf<List<NItem>>(emptyList()) }

        LaunchedEffect(Unit) {
            if (inst.isPreview) return@LaunchedEffect
            while (true) {
                allowed = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
                list = if (allowed) readNotifications(ctx) else emptyList()
                delay(1500)
            }
        }

        val sampleTitle = stringResource(R.string.notif_sample_title)
        val sampleText = stringResource(R.string.notif_sample_text)
        val sampleApp = stringResource(R.string.notif_sample_app)
        val source = if (inst.isPreview) {
            listOf(
                NItem("s1", "", sampleApp, sampleTitle, sampleText, null),
                NItem("s2", "", sampleApp, sampleTitle, sampleText, null),
            )
        } else {
            list
        }
        val shown = source.take(count)

        if (!allowed && !inst.isPreview) {
            Box(
                Modifier.fillMaxSize().clickable {
                    inst.host.launch(android.content.Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                },
                contentAlignment = Alignment.Center
            ) {
                Text(stringResource(R.string.music_allow), color = color, fontSize = 13.sp)
            }
            return
        }
        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.notif_none), color = color.copy(alpha = 0.7f), fontSize = 14.sp)
            }
            return
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            for (item in shown) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable(enabled = !inst.editing && item.pkg.isNotEmpty()) {
                            inst.host.runAfterUnlock {
                                try {
                                    val pi = item.open
                                    val opts = inst.animOptions()
                                    if (pi != null) {
                                        if (opts != null) pi.send(ctx, 0, null, null, null, null, opts) else pi.send()
                                    } else {
                                        ctx.packageManager.getLaunchIntentForPackage(item.pkg)?.let {
                                            it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                            if (opts != null) ctx.startActivity(it, opts) else ctx.startActivity(it)
                                        }
                                    }
                                } catch (e: Exception) {
                                }
                            }
                        }
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncIcon(item.key, 96, Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))) {
                        ctx.packageManager.getApplicationIcon(item.pkg)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.app, color = color.copy(alpha = 0.7f), fontSize = 11.sp, maxLines = 1)
                        if (hideText) {
                            Text(stringResource(R.string.notif_hidden), color = color, fontSize = 13.sp, maxLines = 1)
                        } else {
                            if (item.title.isNotEmpty()) {
                                Text(item.title, color = color, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                            }
                            if (item.text.isNotEmpty()) {
                                Text(item.text, color = color.copy(alpha = 0.85f), fontSize = 12.sp, maxLines = 2)
                            }
                        }
                    }
                }
            }
        }
    }
}

@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)

package app.modlock

import android.app.AlarmManager
import android.content.Intent
import android.icu.util.Calendar
import android.icu.util.GregorianCalendar
import android.icu.util.ULocale
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.AlarmClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin

private fun pt(c: Offset, len: Float, deg: Float): Offset {
    val a = Math.toRadians(deg.toDouble())
    return Offset(c.x + len * sin(a).toFloat(), c.y - len * cos(a).toFloat())
}

/** Analog clock with a few faces. */
object AnalogClockModule : LockModule {
    override val id = "analog"
    override val nameRes = R.string.mod_analog
    override val category = R.string.cat_time
    override val defaultW = 0.5f
    override val defaultH = 0.22f
    override val settings: List<Setting> = listOf(
        ChoiceSetting(
            "skin", R.string.analog_skin,
            listOf(
                "classic" to R.string.skin_classic,
                "minimal" to R.string.skin_minimal,
                "dots" to R.string.skin_dots
            ),
            "classic"
        ),
        SwitchSetting("numbers", R.string.analog_numbers, true),
        SwitchSetting("seconds", R.string.clock_seconds, true),
        ColorSetting("color", R.string.setting_color, "auto"),
        ColorSetting("accent", R.string.analog_accent, "FFB74D"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val color = inst.color("color")
        val accent = inst.color("accent", "FFB74D")
        val skin = inst.s("skin", "classic")
        val numbers = inst.b("numbers", true)
        val showSec = inst.b("seconds", true)
        val lang = inst.lang
        var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(Unit) {
            while (true) {
                now = System.currentTimeMillis()
                delay(1000L - now % 1000L)
            }
        }
        val cal = remember(now) { java.util.Calendar.getInstance().apply { timeInMillis = now } }
        val hour = cal.get(java.util.Calendar.HOUR)
        val min = cal.get(java.util.Calendar.MINUTE)
        val sec = cal.get(java.util.Calendar.SECOND)
        val measurer = rememberTextMeasurer()

        Canvas(Modifier.fillMaxSize()) {
            val r = minOf(size.width, size.height) / 2f * 0.96f
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(color.copy(alpha = 0.10f), r, c)
            drawCircle(color.copy(alpha = 0.35f), r, c, style = Stroke(r * 0.025f))

            for (i in 0 until 60) {
                val major = i % 5 == 0
                if (skin == "minimal" && i % 15 != 0) continue
                if (skin == "dots") {
                    if (major) drawCircle(color.copy(alpha = 0.9f), r * 0.04f, pt(c, r * 0.88f, i * 6f))
                    continue
                }
                val len = if (major) r * 0.12f else r * 0.05f
                drawLine(
                    color.copy(alpha = if (major) 0.9f else 0.45f),
                    pt(c, r * 0.95f - len, i * 6f), pt(c, r * 0.95f, i * 6f),
                    strokeWidth = if (major) r * 0.03f else r * 0.015f,
                    cap = StrokeCap.Round
                )
            }

            if (numbers && skin == "classic") {
                val style = TextStyle(color = color, fontSize = (r * 0.17f).toSp(), fontWeight = FontWeight.Medium)
                for (n in 1..12) {
                    val txt = n.toString().localizeDigits(lang)
                    val ts = measurer.measure(txt, style).size
                    val p = pt(c, r * 0.68f, n * 30f)
                    drawText(measurer, txt, topLeft = Offset(p.x - ts.width / 2f, p.y - ts.height / 2f), style = style)
                }
            }

            val hAng = hour * 30f + min * 0.5f
            val mAng = min * 6f + sec * 0.1f
            val sAng = sec * 6f
            drawLine(color, c, pt(c, r * 0.5f, hAng), strokeWidth = r * 0.07f, cap = StrokeCap.Round)
            drawLine(color, c, pt(c, r * 0.75f, mAng), strokeWidth = r * 0.045f, cap = StrokeCap.Round)
            if (showSec) {
                drawLine(accent, pt(c, -r * 0.12f, sAng), pt(c, r * 0.82f, sAng), strokeWidth = r * 0.02f, cap = StrokeCap.Round)
            }
            drawCircle(accent, r * 0.045f, c)
        }
    }
}

private class City(val key: String, val tz: String, val en: String, val fa: String)

private val allCities = listOf(
    City("Tehran", "Asia/Tehran", "Tehran", "تهران"),
    City("London", "Europe/London", "London", "لندن"),
    City("Paris", "Europe/Paris", "Paris", "پاریس"),
    City("Berlin", "Europe/Berlin", "Berlin", "برلین"),
    City("Madrid", "Europe/Madrid", "Madrid", "مادرید"),
    City("Rome", "Europe/Rome", "Rome", "رم"),
    City("Amsterdam", "Europe/Amsterdam", "Amsterdam", "آمستردام"),
    City("Istanbul", "Europe/Istanbul", "Istanbul", "استانبول"),
    City("Moscow", "Europe/Moscow", "Moscow", "مسکو"),
    City("Baku", "Asia/Baku", "Baku", "باکو"),
    City("Dubai", "Asia/Dubai", "Dubai", "دبی"),
    City("Riyadh", "Asia/Riyadh", "Riyadh", "ریاض"),
    City("Baghdad", "Asia/Baghdad", "Baghdad", "بغداد"),
    City("Cairo", "Africa/Cairo", "Cairo", "قاهره"),
    City("Kabul", "Asia/Kabul", "Kabul", "کابل"),
    City("Tashkent", "Asia/Tashkent", "Tashkent", "تاشکند"),
    City("Karachi", "Asia/Karachi", "Karachi", "کراچی"),
    City("Delhi", "Asia/Kolkata", "Delhi", "دهلی"),
    City("Dhaka", "Asia/Dhaka", "Dhaka", "داکا"),
    City("Bangkok", "Asia/Bangkok", "Bangkok", "بانکوک"),
    City("Singapore", "Asia/Singapore", "Singapore", "سنگاپور"),
    City("Beijing", "Asia/Shanghai", "Beijing", "پکن"),
    City("Seoul", "Asia/Seoul", "Seoul", "سئول"),
    City("Tokyo", "Asia/Tokyo", "Tokyo", "توکیو"),
    City("Sydney", "Australia/Sydney", "Sydney", "سیدنی"),
    City("Auckland", "Pacific/Auckland", "Auckland", "اوکلند"),
    City("Toronto", "America/Toronto", "Toronto", "تورنتو"),
    City("New York", "America/New_York", "New York", "نیویورک"),
    City("Chicago", "America/Chicago", "Chicago", "شیکاگو"),
    City("Los Angeles", "America/Los_Angeles", "Los Angeles", "لس‌آنجلس"),
    City("Mexico City", "America/Mexico_City", "Mexico City", "مکزیکوسیتی"),
    City("Sao Paulo", "America/Sao_Paulo", "São Paulo", "سائوپائولو"),
)

/** Clocks of several cities at once. */
object WorldClockModule : LockModule {
    override val id = "world"
    override val nameRes = R.string.mod_world
    override val category = R.string.cat_fun
    override val defaultW = 0.6f
    override val defaultH = 0.18f
    override val settings: List<Setting> = listOf(
        SwitchSetting("h24", R.string.clock_24h, true),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    private fun selected(inst: ModuleInstance): List<City> =
        inst.s("cities", "Tehran|London|New York").split("|")
            .mapNotNull { k -> allCities.firstOrNull { it.key == k } }

    @Composable
    override fun Content(inst: ModuleInstance) {
        val color = inst.color("color")
        val is24 = inst.b("h24", true)
        val lang = inst.lang
        val list = selected(inst)
        var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(Unit) {
            while (true) {
                now = System.currentTimeMillis()
                delay(15_000L)
            }
        }
        val am = stringResource(R.string.am)
        val pm = stringResource(R.string.pm)
        val localDate = remember(now) { LocalDate.now() }

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val rowH = maxHeight / maxOf(list.size, 1)
            val fs = (rowH.value * 0.5f).coerceIn(10f, 22f)
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                for (c in list) {
                    val z = ZonedDateTime.ofInstant(Instant.ofEpochMilli(now), ZoneId.of(c.tz))
                    val hh = if (is24) z.hour else (if (z.hour % 12 == 0) 12 else z.hour % 12)
                    val t = "%02d:%02d".format(Locale.ENGLISH, hh, z.minute).localizeDigits(lang) +
                        if (is24) "" else " " + (if (z.hour < 12) am else pm)
                    val diff = z.toLocalDate().toEpochDay() - localDate.toEpochDay()
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (lang == "fa") c.fa else c.en, Modifier.weight(1f), color = color, fontSize = fs.sp, maxLines = 1)
                        if (diff != 0L) {
                            Text(
                                (if (diff > 0) "+1" else "-1").localizeDigits(lang),
                                color = color.copy(alpha = 0.6f), fontSize = (fs * 0.7f).sp,
                                modifier = Modifier.padding(horizontal = 6.dp)
                            )
                        }
                        Text(t, color = color, fontSize = fs.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        val chosen = selected(inst).map { it.key }
        val lang = inst.lang
        for (c in allCities) {
            val on = c.key in chosen
            val toggle = {
                val next = if (on) chosen - c.key else chosen + c.key
                inst.put("cities", next.joinToString("|"))
            }
            Row(
                Modifier.fillMaxWidth().clickable { toggle() }.padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (lang == "fa") c.fa else c.en, Modifier.weight(1f))
                Checkbox(checked = on, onCheckedChange = { toggle() })
            }
        }
    }
}

/** Days until (or since) a date, optionally repeating every year (birthdays). */
object CountdownModule : LockModule {
    override val id = "countdown"
    override val nameRes = R.string.mod_countdown
    override val category = R.string.cat_fun
    override val defaultW = 0.5f
    override val defaultH = 0.14f
    override val settings: List<Setting> = listOf(
        TextSetting("title", R.string.cd_title, ""),
        TextSetting("date", R.string.cd_date, ""),
        ChoiceSetting(
            "cal", R.string.calendar_type,
            listOf("auto" to R.string.cal_auto, "jalali" to R.string.cal_jalali, "gregorian" to R.string.cal_gregorian),
            "auto"
        ),
        SwitchSetting("yearly", R.string.cd_yearly, false),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    private fun newCal(jalali: Boolean): Calendar =
        if (jalali) Calendar.getInstance(ULocale("fa_IR@calendar=persian")) else GregorianCalendar()

    private fun epochDay(jalali: Boolean, y: Int, m: Int, d: Int): Long {
        val cal = newCal(jalali)
        cal.clear()
        cal.set(y, m - 1, d)
        return Instant.ofEpochMilli(cal.timeInMillis).atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()
    }

    private fun daysLeft(text: String, jalali: Boolean, yearly: Boolean): Long? {
        val parts = text.asciiDigits().split("/", "-", ".").map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size != 3) return null
        val y = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        val d = parts[2].toIntOrNull() ?: return null
        return try {
            val today = LocalDate.now().toEpochDay()
            var target = epochDay(jalali, y, m, d)
            if (yearly && target < today) {
                val curY = newCal(jalali).get(Calendar.YEAR)
                target = epochDay(jalali, curY, m, d)
                if (target < today) target = epochDay(jalali, curY + 1, m, d)
            }
            target - today
        } catch (e: Exception) {
            null
        }
    }

    @Composable
    override fun Content(inst: ModuleInstance) {
        val color = inst.color("color")
        val lang = inst.lang
        val calType = inst.s("cal", "auto")
        val jalali = calType == "jalali" || (calType == "auto" && lang == "fa")
        val parsed = daysLeft(inst.s("date", ""), jalali, inst.b("yearly", false))
        val demo = parsed == null && inst.isPreview
        val days: Long? = if (demo) 45L else parsed
        val title = if (demo) stringResource(R.string.cd_demo) else inst.s("title", "")
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val s = minOf(maxWidth.value / 200f, maxHeight.value / 90f).coerceIn(0.5f, 3f)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (days == null) {
                    Text(stringResource(R.string.cd_unset), color = color, fontSize = (13 * s).sp)
                } else {
                    if (title.isNotBlank()) Text(title, color = color, fontSize = (15 * s).sp, maxLines = 1)
                    val n = kotlin.math.abs(days)
                    Text(
                        if (days == 0L) stringResource(R.string.cd_today) else n.toString().localizeDigits(lang),
                        color = color, fontSize = (40 * s).sp, fontWeight = FontWeight.Bold
                    )
                    if (days != 0L) {
                        Text(
                            stringResource(if (days > 0) R.string.cd_left else R.string.cd_ago),
                            color = color.copy(alpha = 0.8f), fontSize = (13 * s).sp
                        )
                    }
                }
            }
        }
    }
}

private class TimerState {
    var running by mutableStateOf(false)
    var base by mutableLongStateOf(0L)
    var startedAt by mutableLongStateOf(0L)
    fun elapsed(now: Long): Long = base + if (running) now - startedAt else 0L
}

/** Stopwatch or countdown timer. Keeps running while the screen is shown again. */
object TimerModule : LockModule {
    override val id = "timer"
    override val nameRes = R.string.mod_timer
    override val category = R.string.cat_tools
    override val defaultW = 0.6f
    override val defaultH = 0.16f
    override val settings: List<Setting> = listOf(
        ChoiceSetting(
            "mode", R.string.tm_mode,
            listOf("stopwatch" to R.string.tm_stopwatch, "timer" to R.string.tm_timer), "stopwatch"
        ),
        StepSetting("minutes", R.string.tm_minutes, 1, 120, 5),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    private val states = HashMap<String, TimerState>()

    private fun fmt(totalSec: Long, lang: String): String {
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        val t = if (h > 0) "%d:%02d:%02d".format(Locale.ENGLISH, h, m, s) else "%02d:%02d".format(Locale.ENGLISH, m, s)
        return t.localizeDigits(lang)
    }

    @Composable
    override fun Content(inst: ModuleInstance) {
        val color = inst.color("color")
        val lang = inst.lang
        val isTimer = inst.s("mode", "stopwatch") == "timer"
        val totalMs = (inst.s("minutes", "5").toLongOrNull() ?: 5L) * 60_000L
        val st = states.getOrPut(inst.uid) { TimerState() }
        val ctx = LocalContext.current
        var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

        LaunchedEffect(st.running, isTimer, totalMs) {
            while (true) {
                now = System.currentTimeMillis()
                if (isTimer && st.running && st.elapsed(now) >= totalMs) {
                    st.running = false
                    st.base = 0L
                    try {
                        ctx.getSystemService(Vibrator::class.java)
                            ?.vibrate(VibrationEffect.createOneShot(700, VibrationEffect.DEFAULT_AMPLITUDE))
                    } catch (e: Exception) {
                    }
                }
                delay(if (st.running) 50L else 500L)
            }
        }

        val el = st.elapsed(now)
        val text = if (isTimer) {
            fmt(ceil(maxOf(0L, totalMs - el) / 1000.0).toLong(), lang)
        } else {
            val tenth = (el / 100) % 10
            fmt(el / 1000, lang) + "." + tenth.toString().localizeDigits(lang)
        }

        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val s = minOf(maxWidth.value / 220f, maxHeight.value / 100f).coerceIn(0.5f, 3f)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text, color = color, fontSize = (38 * s).sp, fontWeight = FontWeight.Light, maxLines = 1)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton(
                        stringResource(if (st.running) R.string.tm_pause else R.string.tm_start),
                        primary = true
                    ) {
                        val t = System.currentTimeMillis()
                        if (st.running) {
                            st.base += t - st.startedAt
                            st.running = false
                        } else {
                            st.startedAt = t
                            st.running = true
                        }
                    }
                    PillButton(stringResource(R.string.tm_reset)) {
                        st.running = false
                        st.base = 0L
                    }
                }
            }
        }
    }
}

/** Shows the next alarm and opens the clock app. */
object AlarmModule : LockModule {
    override val id = "alarm"
    override val nameRes = R.string.mod_alarm
    override val category = R.string.cat_tools
    override val defaultW = 0.5f
    override val defaultH = 0.1f
    override val settings: List<Setting> = listOf(
        SwitchSetting("h24", R.string.clock_24h, true),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val color = inst.color("color")
        val lang = inst.lang
        val ctx = LocalContext.current
        val is24 = inst.b("h24", true)
        var trigger by remember { mutableLongStateOf(0L) }
        LaunchedEffect(Unit) {
            while (true) {
                trigger = try {
                    ctx.getSystemService(AlarmManager::class.java)?.nextAlarmClock?.triggerTime ?: 0L
                } catch (e: Exception) {
                    0L
                }
                delay(20_000L)
            }
        }
        if (trigger == 0L && inst.isPreview) trigger = System.currentTimeMillis() + 9 * 3600_000L

        val weekdays = stringArrayResource(R.array.weekdays)
        val am = stringResource(R.string.am)
        val pm = stringResource(R.string.pm)
        val label = if (trigger == 0L) {
            stringResource(R.string.al_none)
        } else {
            val z = Instant.ofEpochMilli(trigger).atZone(ZoneId.systemDefault())
            val hh = if (is24) z.hour else (if (z.hour % 12 == 0) 12 else z.hour % 12)
            val time = "%02d:%02d".format(Locale.ENGLISH, hh, z.minute).localizeDigits(lang) +
                if (is24) "" else " " + (if (z.hour < 12) am else pm)
            val dd = z.toLocalDate().toEpochDay() - LocalDate.now().toEpochDay()
            val day = when (dd) {
                0L -> stringResource(R.string.al_today)
                1L -> stringResource(R.string.al_tomorrow)
                else -> weekdays[z.dayOfWeek.value % 7]
            }
            "$time · $day"
        }
        BoxWithConstraints(
            Modifier.fillMaxSize().clickable { inst.host.launch(Intent(AlarmClock.ACTION_SHOW_ALARMS)) },
            contentAlignment = Alignment.Center
        ) {
            val s = minOf(maxWidth.value / 200f, maxHeight.value / 40f).coerceIn(0.5f, 3f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("\u23F0", fontSize = (22 * s).sp)
                Spacer(Modifier.width(8.dp))
                Text(label, color = color, fontSize = (16 * s).sp, maxLines = 1)
            }
        }
    }
}

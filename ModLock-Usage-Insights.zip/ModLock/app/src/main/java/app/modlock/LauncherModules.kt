package app.modlock

import android.content.pm.PackageManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** What the screen offers to icon modules: put an icon on the main page, or remove one. */
class LauncherActions(
    val addIcon: (String) -> Unit,
    val removeItem: (String) -> Unit,
)

val LocalLauncherActions = compositionLocalOf<LauncherActions?> { null }

private fun appLabel(pm: PackageManager, pkg: String): String =
    try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }

private fun pkgList(raw: String): List<String> = raw.split("|").filter { it.isNotBlank() }

private fun tintOf(inst: ModuleInstance, pkg: String): Color? {
    val v = inst.s("tint_$pkg", "")
    return if (v.isNotEmpty()) hexColor(v) else null
}

/** Pick apps from the whole list (with search). In single mode a tap picks and closes. */
@Composable
fun AppPickerDialog(
    initial: Set<String>,
    single: Boolean = false,
    onDone: (List<String>) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val lang = SettingsStore(ctx).lang
    var q by remember { mutableStateOf("") }
    var chosen by remember { mutableStateOf(initial.toList()) }
    val all by produceState(AppsCache.peek() ?: emptyList(), ctx) {
        value = withContext(Dispatchers.Default) { AppsCache.load(ctx) }
    }
    val list = remember(all, q) {
        all.sortedBy { it.second.lowercase() }
            .filter { q.isBlank() || it.second.contains(q, ignoreCase = true) }
    }
    LocalizedDialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.fillMaxWidth().padding(16.dp).heightIn(max = 560.dp),
            shape = RoundedCornerShape(28.dp), color = cs.surface, tonalElevation = 8.dp
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.picker_title), Modifier.weight(1f),
                        style = MaterialTheme.typography.titleLarge
                    )
                    if (!single) {
                        Text(
                            stringResource(R.string.picker_count, chosen.size.toString().localizeDigits(lang)),
                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                        )
                    }
                }
                SearchField(q, { q = it }, cs.onSurface, 22.dp, stringResource(R.string.apps_search))
                LazyColumn(Modifier.weight(1f)) {
                    items(list, key = { it.first }) { app ->
                        val pkg = app.first
                        val on = pkg in chosen
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (single) onDone(listOf(pkg))
                                    else chosen = if (on) chosen - pkg else chosen + pkg
                                }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(pkg, 40.dp, 26, null)
                            Text(app.second, Modifier.weight(1f).padding(horizontal = 12.dp), maxLines = 1)
                            if (!single) Checkbox(checked = on, onCheckedChange = null)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onDismiss) { Text(stringResource(R.string.editor_close)) }
                    Spacer(Modifier.weight(1f))
                    if (!single) {
                        Button(onClick = { onDone(chosen) }) { Text(stringResource(R.string.picker_done)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaceholderIcon(size: Dp, radius: Int, color: Color) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(radius)).background(color.copy(alpha = 0.22f)),
        contentAlignment = Alignment.Center
    ) {
        Text("+", color = color, fontSize = (size.value * 0.5f).sp)
    }
}

// ------------------------------------------------------------------------------------------
// One app icon on a page. Hold for the menu; drag it onto another icon to make a folder.
// ------------------------------------------------------------------------------------------
object AppIconModule : LockModule {
    override val id = "appicon"
    override val nameRes = R.string.mod_appicon
    override val category = R.string.cat_access
    override val defaultW = 0.2f
    override val defaultH = 0.11f
    override val settings: List<Setting> = listOf(
        SwitchSetting("labels", R.string.sc_labels, true),
        SliderSetting("radius", R.string.setting_radius, 0f, 50f, 26f),
        ColorSetting("color", R.string.setting_color, "auto"),
        AnimSetting,
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val pm = ctx.packageManager
        val actions = LocalLauncherActions.current
        val color = inst.color("color")
        val labels = inst.b("labels", true)
        val radius = inst.f("radius", 26f).roundToInt().coerceIn(0, 50)
        val pkg = inst.s("pkg", "")
        val label = remember(pkg) { if (pkg.isBlank()) "" else appLabel(pm, pkg) }
        val tintHex = inst.s("tint_$pkg", "")
        var menu by remember { mutableStateOf(false) }
        var perm by remember { mutableStateOf(false) }
        val canUse = !inst.editing && !inst.isPreview && pkg.isNotBlank()
        val sample = stringResource(R.string.sample_a)

        BoxWithConstraints(
            Modifier.fillMaxSize().pointerInput(canUse, pkg) {
                if (canUse) {
                    detectTapGestures(
                        onTap = { pm.getLaunchIntentForPackage(pkg)?.let { inst.launch(it) } },
                        onLongPress = { menu = true }
                    )
                }
            },
            contentAlignment = Alignment.Center
        ) {
            val boxW = maxWidth
            val boxH = maxHeight
            val labelH = if (labels) 18.dp else 0.dp
            val icon = (minOf(boxW, boxH - labelH) * 0.9f).coerceAtLeast(20.dp)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (pkg.isBlank()) {
                    PlaceholderIcon(icon, radius, color)
                } else {
                    AppIcon(pkg, icon, radius, if (tintHex.isNotEmpty()) hexColor(tintHex) else null)
                }
                if (labels) {
                    Text(
                        if (pkg.isBlank()) (if (inst.isPreview) sample else "") else label,
                        color = color, fontSize = 11.sp, maxLines = 1,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        if (menu) {
            AppMenuDialog(
                app = AppEntry(pkg, label, ""), inst = inst, tintNow = tintHex,
                onDismiss = { menu = false },
                onPermissions = { menu = false; perm = true },
                onHide = {
                    menu = false
                    actions?.removeItem?.invoke(inst.uid)
                },
                hideLabel = R.string.apps_remove_page
            )
        }
        if (perm) PermissionsDialog(AppEntry(pkg, label, ""), inst.host) { perm = false }
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        var picker by remember { mutableStateOf(false) }
        Button(onClick = { picker = true }) { Text(stringResource(R.string.appicon_change)) }
        if (picker) {
            AppPickerDialog(
                initial = setOf(inst.s("pkg", "")).filter { it.isNotBlank() }.toSet(),
                single = true,
                onDone = { inst.put("pkg", it.first()); picker = false },
                onDismiss = { picker = false }
            )
        }
    }
}

// ------------------------------------------------------------------------------------------
// A folder of apps. Its own name, columns, preview grid, roundness, colors and animation.
// ------------------------------------------------------------------------------------------
object AppFolderModule : LockModule {
    override val id = "folder"
    override val nameRes = R.string.mod_folder
    override val category = R.string.cat_access
    override val defaultW = 0.2f
    override val defaultH = 0.12f
    override val settings: List<Setting> = listOf(
        TextSetting("name", R.string.folder_name, ""),
        StepSetting("cols", R.string.sc_columns, 2, 5, 4),
        ChoiceSetting("pv", R.string.folder_pv, listOf("2" to R.string.pv_2, "3" to R.string.pv_3), "2"),
        SliderSetting("radius", R.string.setting_radius, 0f, 50f, 28f),
        SwitchSetting("labels", R.string.sc_labels, true),
        ColorSetting("color", R.string.setting_color, "auto"),
        AnimSetting,
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val color = inst.color("color")
        val items = pkgList(inst.s("items", ""))
        val name = inst.s("name", "").ifBlank { stringResource(R.string.folder_default) }
        val labels = inst.b("labels", true)
        val radius = inst.f("radius", 28f).roundToInt().coerceIn(0, 50)
        val cols = (inst.s("cols", "4").toIntOrNull() ?: 4).coerceIn(2, 5)
        val pvn = (inst.s("pv", "2").toIntOrNull() ?: 2).coerceIn(2, 3)
        var open by remember { mutableStateOf(false) }
        val canUse = !inst.editing && !inst.isPreview

        BoxWithConstraints(
            Modifier.fillMaxSize().clickable(enabled = canUse) { open = true },
            contentAlignment = Alignment.Center
        ) {
            val boxW = maxWidth
            val boxH = maxHeight
            val labelH = if (labels) 18.dp else 0.dp
            val tile = (minOf(boxW, boxH - labelH) * 0.9f).coerceAtLeast(24.dp)
            val shape = RoundedCornerShape(radius)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier
                        .size(tile)
                        .clip(shape)
                        .background(color.copy(alpha = 0.18f))
                        .border(1.dp, color.copy(alpha = 0.25f), shape),
                    contentAlignment = Alignment.Center
                ) {
                    val cell = (tile * 0.78f - 2.dp * (pvn - 1)) / pvn
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        for (r in 0 until pvn) {
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                for (c in 0 until pvn) {
                                    val pkg = items.getOrNull(r * pvn + c)
                                    Box(Modifier.size(cell), contentAlignment = Alignment.Center) {
                                        if (pkg != null) {
                                            AppIcon(pkg, cell, 24, null)
                                        } else if (inst.isPreview && items.isEmpty()) {
                                            Box(
                                                Modifier.size(cell).clip(RoundedCornerShape(24))
                                                    .background(color.copy(alpha = 0.3f))
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (labels) {
                    Text(name, color = color, fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }

        if (open) {
            FolderDialog(inst, name, items, cols, radius, labels, color) { open = false }
        }
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        var picker by remember { mutableStateOf(false) }
        val items = pkgList(inst.s("items", ""))
        val pm = LocalContext.current.packageManager
        Button(onClick = { picker = true }) { Text(stringResource(R.string.folder_add)) }
        for (pkg in items) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AppIcon(pkg, 32.dp, 26, null)
                Text(appLabel(pm, pkg), Modifier.weight(1f).padding(horizontal = 10.dp), maxLines = 1)
                PillButton(stringResource(R.string.editor_delete), danger = true) {
                    inst.put("items", items.filter { it != pkg }.joinToString("|"))
                }
            }
        }
        if (picker) {
            AppPickerDialog(
                initial = items.toSet(),
                onDone = { chosen ->
                    inst.put("items", (items.filter { it in chosen } + chosen.filter { it !in items }).joinToString("|"))
                    picker = false
                },
                onDismiss = { picker = false }
            )
        }
    }
}

@Composable
private fun FolderDialog(
    inst: ModuleInstance, name: String, items: List<String>, cols: Int, radius: Int,
    labels: Boolean, color: Color, onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    val cs = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf<String?>(null) }
    var perm by remember { mutableStateOf<String?>(null) }
    var picker by remember { mutableStateOf(false) }

    LocalizedDialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.fillMaxWidth().padding(20.dp),
            shape = RoundedCornerShape(28.dp), color = cs.surface, tonalElevation = 8.dp
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(name, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, maxLines = 1)
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = null) }
                }
                if (items.isEmpty()) {
                    Text(stringResource(R.string.folder_empty), color = cs.onSurfaceVariant)
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(cols),
                        modifier = Modifier.heightIn(max = 360.dp)
                    ) {
                        items(items, key = { it }) { pkg ->
                            Column(
                                Modifier
                                    .padding(4.dp)
                                    .pointerInput(pkg) {
                                        detectTapGestures(
                                            onTap = {
                                                pm.getLaunchIntentForPackage(pkg)?.let {
                                                    inst.launch(it)
                                                    onDismiss()
                                                }
                                            },
                                            onLongPress = { menu = pkg }
                                        )
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                AppIcon(pkg, 56.dp, radius, tintOf(inst, pkg))
                                if (labels) {
                                    Text(
                                        appLabel(pm, pkg), fontSize = 11.sp, maxLines = 1,
                                        color = cs.onSurface, modifier = Modifier.padding(top = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { picker = true }) { Text(stringResource(R.string.folder_add)) }
                    Spacer(Modifier.weight(1f))
                    Button(onClick = onDismiss) { Text(stringResource(R.string.editor_done)) }
                }
            }
        }
    }

    val mp = menu
    if (mp != null) {
        AppMenuDialog(
            app = AppEntry(mp, appLabel(pm, mp), ""), inst = inst, tintNow = inst.s("tint_$mp", ""),
            onDismiss = { menu = null },
            onPermissions = { perm = mp; menu = null },
            onHide = {
                inst.put("items", items.filter { it != mp }.joinToString("|"))
                menu = null
            },
            hideLabel = R.string.apps_remove_folder
        )
    }
    val pp = perm
    if (pp != null) PermissionsDialog(AppEntry(pp, appLabel(pm, pp), ""), inst.host) { perm = null }
    if (picker) {
        AppPickerDialog(
            initial = items.toSet(),
            onDone = { chosen ->
                inst.put("items", (items.filter { it in chosen } + chosen.filter { it !in items }).joinToString("|"))
                picker = false
            },
            onDismiss = { picker = false }
        )
    }
}

// ------------------------------------------------------------------------------------------
// A dock: a glass bar of favorite apps. It can stay on every page while pages move.
// ------------------------------------------------------------------------------------------
object DockModule : LockModule {
    override val id = "dock"
    override val nameRes = R.string.mod_dock
    override val category = R.string.cat_access
    override val defaultW = 0.92f
    override val defaultH = 0.11f
    override val defaultY = 0.86f
    override val settings: List<Setting> = listOf(
        SliderSetting("radius", R.string.setting_radius, 0f, 50f, 24f),
        SwitchSetting("allpages", R.string.dock_allpages, true),
        ColorSetting("color", R.string.setting_color, "auto"),
        AnimSetting,
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val pm = ctx.packageManager
        val color = inst.color("color")
        val items = pkgList(inst.s("items", ""))
        val radius = inst.f("radius", 24f).roundToInt().coerceIn(0, 50)
        val canUse = !inst.editing && !inst.isPreview
        var menu by remember { mutableStateOf<String?>(null) }
        var perm by remember { mutableStateOf<String?>(null) }

        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val boxW = maxWidth
            val boxH = maxHeight
            if (items.isEmpty() && !inst.isPreview) {
                Text(stringResource(R.string.dock_empty), color = color.copy(alpha = 0.7f), fontSize = 12.sp)
            } else {
                val n = if (items.isEmpty()) 4 else items.size
                val icon = minOf(boxH * 0.82f, boxW / n * 0.78f)
                Row(
                    Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (items.isEmpty()) {
                        for (i in 0 until 4) PlaceholderIcon(icon, radius, color)
                    } else {
                        for (pkg in items) {
                            DockIcon(
                                pkg, icon, radius, tintOf(inst, pkg), canUse,
                                onTap = { pm.getLaunchIntentForPackage(pkg)?.let { inst.launch(it) } },
                                onLong = { menu = pkg }
                            )
                        }
                    }
                }
            }
        }

        val mp = menu
        if (mp != null) {
            AppMenuDialog(
                app = AppEntry(mp, appLabel(pm, mp), ""), inst = inst, tintNow = inst.s("tint_$mp", ""),
                onDismiss = { menu = null },
                onPermissions = { perm = mp; menu = null },
                onHide = {
                    inst.put("items", items.filter { it != mp }.joinToString("|"))
                    menu = null
                },
                hideLabel = R.string.apps_remove_dock
            )
        }
        val pp = perm
        if (pp != null) PermissionsDialog(AppEntry(pp, appLabel(pm, pp), ""), inst.host) { perm = null }
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        var picker by remember { mutableStateOf(false) }
        val items = pkgList(inst.s("items", ""))
        val pm = LocalContext.current.packageManager
        Button(onClick = { picker = true }) { Text(stringResource(R.string.folder_add)) }
        items.forEachIndexed { idx, pkg ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AppIcon(pkg, 32.dp, 26, null)
                Text(appLabel(pm, pkg), Modifier.weight(1f).padding(horizontal = 10.dp), maxLines = 1)
                if (idx > 0) {
                    PillButton("\u25C0") {
                        val l = items.toMutableList()
                        l[idx] = l[idx - 1].also { l[idx - 1] = l[idx] }
                        inst.put("items", l.joinToString("|"))
                    }
                    Spacer(Modifier.width(6.dp))
                }
                if (idx < items.size - 1) {
                    PillButton("\u25B6") {
                        val l = items.toMutableList()
                        l[idx] = l[idx + 1].also { l[idx + 1] = l[idx] }
                        inst.put("items", l.joinToString("|"))
                    }
                    Spacer(Modifier.width(6.dp))
                }
                PillButton(stringResource(R.string.editor_delete), danger = true) {
                    inst.put("items", items.filter { it != pkg }.joinToString("|"))
                }
            }
        }
        if (picker) {
            AppPickerDialog(
                initial = items.toSet(),
                onDone = { chosen ->
                    inst.put("items", (items.filter { it in chosen } + chosen.filter { it !in items }).joinToString("|"))
                    picker = false
                },
                onDismiss = { picker = false }
            )
        }
    }
}

/** A dock icon that springs up while pressed. */
@Composable
private fun DockIcon(
    pkg: String, size: Dp, radius: Int, tint: Color?, enabled: Boolean,
    onTap: () -> Unit, onLong: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (pressed) 1.28f else 1f,
        spring(dampingRatio = 0.45f, stiffness = 500f), label = "dock"
    )
    Box(
        Modifier
            .size(size)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationY = -(scale - 1f) * size.toPx() * 0.6f
            }
            .pointerInput(enabled, pkg) {
                if (enabled) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        },
                        onTap = { onTap() },
                        onLongPress = { onLong() }
                    )
                }
            }
    ) {
        AppIcon(pkg, size, radius, tint)
    }
}

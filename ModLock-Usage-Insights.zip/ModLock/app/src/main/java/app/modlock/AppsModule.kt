package app.modlock

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp

/** Favorite apps, as a grid or carousel. */
object AppsModule : LockModule {
    override val id = "apps"
    override val nameRes = R.string.mod_apps
    override val category = R.string.cat_access
    override val defaultW = 0.9f
    override val defaultH = 0.22f
    override val settings: List<Setting> = shortcutSettings(26f)

    fun queryApps(ctx: Context): List<Pair<String, String>> =
        AppsCache.load(ctx).sortedBy { it.second.lowercase() }

    @Composable
    override fun Content(inst: ModuleInstance) {
        val ctx = LocalContext.current
        val pm = ctx.packageManager
        val raw = inst.s("items", "")
        val list = remember(raw) {
            raw.split("|").filter { it.isNotBlank() }.mapNotNull { pkg ->
                val intent = pm.getLaunchIntentForPackage(pkg) ?: return@mapNotNull null
                val label = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                } catch (e: Exception) {
                    pkg
                }
                ShortcutItem(
                    key = pkg,
                    label = label,
                    onClick = { inst.launch(intent) },
                    loadIcon = { IconCache.appIcon(pm, pkg) },
                    cacheKey = "app:$pkg"
                )
            }
        }
        val shown = if (list.isEmpty() && inst.isPreview) {
            listOf(R.string.sample_a, R.string.sample_b, R.string.sample_c, R.string.sample_d, R.string.sample_e, R.string.sample_f)
                .map { ShortcutItem("s$it", stringResource(it), { }, { null }) }
        } else list
        ShortcutView(inst, shown, 26f)
    }

    @Composable
    override fun CustomSettings(inst: ModuleInstance) {
        val ctx = LocalContext.current
        var open by remember { mutableStateOf(false) }
        Button(onClick = { open = !open }) { Text(stringResource(R.string.apps_choose)) }
        if (open) {
            val apps = remember { queryApps(ctx) }
            val selected = inst.s("items", "").split("|").filter { it.isNotBlank() }
            for ((pkg, label) in apps) {
                val on = pkg in selected
                val toggle = {
                    val next = if (on) selected - pkg else selected + pkg
                    inst.put("items", next.joinToString("|"))
                }
                Row(
                    Modifier.fillMaxWidth().clickable { toggle() }.padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncIcon(pkg, 96, Modifier.size(36.dp)) { ctx.packageManager.getApplicationIcon(pkg) }
                    Text(label, Modifier.weight(1f).padding(horizontal = 12.dp))
                    Checkbox(checked = on, onCheckedChange = { toggle() })
                }
            }
        }
    }
}

package app.modlock

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.DrawStyle
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** How module panels look. Built from the global Appearance settings (or a module's own style). */
class PanelSpec(
    val style: String,       // glass | card | solid | outline | none
    val tint: Color,
    val opacity: Float,      // 0..1
    val radius: Float,       // dp
    val shadow: Float,       // 0..1
    val highlight: Float,    // 0..1
    val tintAuto: Boolean = true,
    /** Text color the "auto" color should use on this panel (null = follow the phone theme). */
    val autoFg: Color? = null,
)

/** Lets a panel style with a light or dark body choose readable text for "auto" colors. */
val LocalAutoFg = compositionLocalOf<Color?> { null }

/** Per-module "panel style" setting, offered next to each module's own settings. */
val StyleSetting = ChoiceSetting(
    "style", R.string.style_label,
    listOf(
        "global" to R.string.style_global,
        "glass" to R.string.style_glass,
        "card" to R.string.style_card,
        "solid" to R.string.style_solid,
        "outline" to R.string.style_outline,
        "paper" to R.string.style_paper,
        "sticker" to R.string.style_sticker,
        "neon" to R.string.style_neon,
        "aurora" to R.string.style_aurora,
        "none" to R.string.style_none,
    ),
    "global"
)

private val PanelTints = listOf(
    "auto", "FFFFFF", "B3C7FF", "D1B3FF", "FFD9A0", "A8E6CF", "1B1B22",
    "FF6B6B", "FFD54F", "6C63FF", "26C6DA"
)

@Composable
fun rememberPanelSpec(store: SettingsStore, override: String? = null): PanelSpec {
    val cs = MaterialTheme.colorScheme
    val dark = isSystemInDarkTheme()
    val style = override?.takeIf { it != "global" } ?: store.get("ap_style", "glass")
    val tintKey = store.get("ap_tint", "auto")
    val auto = tintKey == "auto"
    val tint = if (!auto) {
        hexColor(tintKey)
    } else {
        when (style) {
            "glass" -> Color.White
            "card" -> if (dark) Color(0xFF2B2B33) else Color.White
            "solid" -> cs.primaryContainer
            "paper" -> Color(0xFFFFF1A8)
            "sticker" -> Color(0xFF6C63FF)
            "neon" -> Color(0xFF00E5FF)
            "aurora" -> Color(0xFF7F5AF0)
            else -> themeFg()
        }
    }
    val ink = Color(0xFF1B1B1F)
    val autoFg: Color? = when (style) {
        "paper", "sticker" -> if (tint.luminance() > 0.5f) ink else Color.White
        "neon" -> Color.White
        "aurora" -> if (!auto && tint.luminance() > 0.6f) ink else Color.White
        else -> null
    }
    return PanelSpec(
        style = style,
        tint = tint,
        opacity = store.getFloat("ap_opacity", 0.5f).coerceIn(0f, 1f),
        radius = store.getFloat("ap_radius", 22f).coerceIn(0f, 40f),
        shadow = store.getFloat("ap_shadow", 0.5f).coerceIn(0f, 1f),
        highlight = store.getFloat("ap_highlight", 0.6f).coerceIn(0f, 1f),
        tintAuto = auto,
        autoFg = autoFg,
    )
}

/** Fills or strokes a shape outline with a brush. */
private fun DrawScope.fillOutline(outline: Outline, brush: Brush, style: DrawStyle = Fill) {
    when (outline) {
        is Outline.Rectangle -> drawRect(
            brush,
            topLeft = Offset(outline.rect.left, outline.rect.top),
            size = Size(outline.rect.width, outline.rect.height),
            style = style
        )
        is Outline.Rounded -> {
            val r = outline.roundRect
            drawRoundRect(
                brush,
                topLeft = Offset(r.left, r.top),
                size = Size(r.width, r.height),
                cornerRadius = r.topLeftCornerRadius,
                style = style
            )
        }
        is Outline.Generic -> drawPath(outline.path, brush, style = style)
    }
}

private fun outlineToPath(o: Outline): Path = when (o) {
    is Outline.Rectangle -> Path().apply { addRect(o.rect) }
    is Outline.Rounded -> Path().apply { addRoundRect(o.roundRect) }
    is Outline.Generic -> o.path
}

/**
 * A blurred shadow that is clipped away inside the shape. (The built-in elevation shadow also
 * shows through translucent panels, which looked like an extra rectangle.)
 */
private fun DrawScope.drawSoftShadow(outline: Outline, spec: PanelSpec) {
    val path = outlineToPath(outline)
    val blur = (4f + spec.shadow * 22f).dp.toPx()
    val dy = (2f + spec.shadow * 8f).dp.toPx()
    val base = when (spec.style) {
        "glass" -> Color(0xFF3B4BD6)
        "neon" -> Color(0xFF7C4DFF)
        "aurora" -> Color(0xFF7F5AF0)
        else -> Color.Black
    }
    val argb = base.copy(alpha = 0.18f + 0.30f * spec.shadow).toArgb()
    clipPath(path, clipOp = ClipOp.Difference) {
        drawIntoCanvas { canvas ->
            val paint = android.graphics.Paint().apply {
                isAntiAlias = true
                color = android.graphics.Color.BLACK
                setShadowLayer(blur, 0f, dy, argb)
            }
            canvas.nativeCanvas.drawPath(path.asAndroidPath(), paint)
        }
    }
}

/** Fills the shape shrunk by [inset] pixels (used for the colored body of the sticker). */
private fun DrawScope.fillInset(outline: Outline, inset: Float, brush: Brush) {
    when (outline) {
        is Outline.Rounded -> {
            val r = outline.roundRect
            drawRoundRect(
                brush,
                topLeft = Offset(r.left + inset, r.top + inset),
                size = Size(r.width - 2 * inset, r.height - 2 * inset),
                cornerRadius = CornerRadius(
                    maxOf(0f, r.topLeftCornerRadius.x - inset),
                    maxOf(0f, r.topLeftCornerRadius.y - inset)
                )
            )
        }
        is Outline.Rectangle -> drawRect(
            brush,
            topLeft = Offset(outline.rect.left + inset, outline.rect.top + inset),
            size = Size(outline.rect.width - 2 * inset, outline.rect.height - 2 * inset)
        )
        is Outline.Generic -> fillOutline(outline, brush)
    }
}

/** Draws the panel (glass / card / solid / outline) behind the content. */
fun Modifier.panel(spec: PanelSpec, shape: Shape): Modifier {
    if (spec.style == "none") return this
    val op = spec.opacity
    val hl = spec.highlight
    return this.drawBehind {
        val outline = shape.createOutline(size, layoutDirection, this)
        if (spec.style != "outline" && spec.shadow > 0.02f) drawSoftShadow(outline, spec)
        val rim = 1.5.dp.toPx()
        when (spec.style) {
            "glass" -> {
                // Frosted body.
                fillOutline(
                    outline,
                    Brush.verticalGradient(
                        listOf(
                            spec.tint.copy(alpha = 0.18f + 0.55f * op),
                            spec.tint.copy(alpha = 0.06f + 0.30f * op)
                        )
                    )
                )
                // Soft blue/violet glow toward the lower corner.
                fillOutline(
                    outline,
                    Brush.linearGradient(
                        listOf(Color.Transparent, Color(0xFF7C6CFF).copy(alpha = 0.22f * op + 0.04f)),
                        start = Offset(size.width * 0.3f, 0f),
                        end = Offset(size.width, size.height)
                    )
                )
                // Top gloss.
                fillOutline(
                    outline,
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.50f * hl), Color.Transparent),
                        startY = 0f, endY = size.height * 0.5f
                    )
                )
                // Bright rim.
                fillOutline(
                    outline,
                    Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = 0.95f * hl),
                            Color.White.copy(alpha = 0.12f * hl),
                            Color(0xFF9FB6FF).copy(alpha = 0.65f * hl)
                        ),
                        start = Offset.Zero,
                        end = Offset(size.width, size.height)
                    ),
                    style = Stroke(rim)
                )
            }

            "card" -> {
                fillOutline(outline, SolidColor(spec.tint.copy(alpha = 0.55f + 0.45f * op)))
                fillOutline(
                    outline,
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.22f * hl), Color.Transparent),
                        startY = 0f, endY = size.height * 0.4f
                    )
                )
                val edge = if (spec.tint.luminance() > 0.5f) Color.Black else Color.White
                fillOutline(outline, SolidColor(edge.copy(alpha = 0.10f)), style = Stroke(1.dp.toPx()))
            }

            "solid" -> {
                fillOutline(outline, SolidColor(spec.tint.copy(alpha = 0.35f + 0.65f * op)))
                fillOutline(
                    outline,
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.35f * hl), Color.Transparent),
                        startY = 0f, endY = size.height * 0.55f
                    )
                )
            }

            "paper" -> {
                // Sticky-note paper: ruled lines, a lifted shade and a strip of tape.
                fillOutline(outline, SolidColor(spec.tint.copy(alpha = 0.80f + 0.20f * op)))
                val step = 22.dp.toPx()
                val margin = 14.dp.toPx()
                val ink = if (spec.tint.luminance() > 0.5f) Color(0xFF5C7CA8) else Color.White
                var y = step + 4.dp.toPx()
                while (y < size.height - 10.dp.toPx()) {
                    drawLine(
                        ink.copy(alpha = 0.22f), Offset(margin, y), Offset(size.width - margin, y),
                        strokeWidth = 1.dp.toPx()
                    )
                    y += step
                }
                fillOutline(
                    outline,
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.07f)),
                        startY = size.height * 0.6f, endY = size.height
                    )
                )
                fillOutline(
                    outline,
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.35f * hl), Color.Transparent),
                        startY = 0f, endY = size.height * 0.25f
                    )
                )
                rotate(-4f, Offset(size.width / 2f, 0f)) {
                    drawRect(
                        Color.White.copy(alpha = 0.55f),
                        topLeft = Offset(size.width / 2f - 30.dp.toPx(), -8.dp.toPx()),
                        size = Size(60.dp.toPx(), 18.dp.toPx())
                    )
                }
            }

            "sticker" -> {
                // Die-cut vinyl sticker: thick white edge, colored body, diagonal shine.
                val edge = 5.dp.toPx()
                fillOutline(outline, SolidColor(Color.White))
                fillInset(
                    outline, edge,
                    Brush.linearGradient(
                        listOf(lerp(spec.tint, Color.White, 0.18f), spec.tint, lerp(spec.tint, Color.Black, 0.18f)),
                        start = Offset.Zero, end = Offset(size.width, size.height)
                    )
                )
                fillInset(
                    outline, edge,
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.55f * hl), Color.Transparent),
                        start = Offset.Zero, end = Offset(size.width * 0.55f, size.height * 0.9f)
                    )
                )
                fillOutline(outline, SolidColor(Color.Black.copy(alpha = 0.14f)), style = Stroke(1.dp.toPx()))
            }

            "neon" -> {
                val colors = if (spec.tintAuto) {
                    listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF), Color(0xFFFF4081))
                } else {
                    listOf(spec.tint, lerp(spec.tint, Color.White, 0.5f), spec.tint)
                }
                fillOutline(outline, SolidColor(Color(0xFF0A0A18).copy(alpha = 0.40f + 0.50f * op)))
                for (i in 3 downTo 1) {
                    fillOutline(
                        outline,
                        Brush.linearGradient(
                            colors.map { it.copy(alpha = 0.06f + 0.14f * hl) },
                            start = Offset.Zero, end = Offset(size.width, size.height)
                        ),
                        style = Stroke((2f + i * 3.5f).dp.toPx())
                    )
                }
                fillOutline(
                    outline,
                    Brush.linearGradient(colors, start = Offset.Zero, end = Offset(size.width, size.height)),
                    style = Stroke(2.dp.toPx())
                )
            }

            "aurora" -> {
                val a = 0.55f + 0.45f * op
                val base = if (spec.tintAuto) {
                    listOf(Color(0xFF7F5AF0), Color(0xFF2CB1BC), Color(0xFFFF6E7F))
                } else {
                    listOf(spec.tint, lerp(spec.tint, Color.White, 0.25f), lerp(spec.tint, Color.Black, 0.35f))
                }
                fillOutline(
                    outline,
                    Brush.linearGradient(
                        base.map { it.copy(alpha = a) },
                        start = Offset.Zero, end = Offset(size.width, size.height)
                    )
                )
                if (spec.tintAuto) {
                    fillOutline(
                        outline,
                        Brush.radialGradient(
                            listOf(Color(0xFFFFC371).copy(alpha = 0.50f), Color.Transparent),
                            center = Offset(size.width * 0.9f, size.height * 0.1f),
                            radius = maxOf(size.width, size.height) * 0.6f
                        )
                    )
                    fillOutline(
                        outline,
                        Brush.radialGradient(
                            listOf(Color(0xFF00F5A0).copy(alpha = 0.40f), Color.Transparent),
                            center = Offset(size.width * 0.05f, size.height * 0.95f),
                            radius = maxOf(size.width, size.height) * 0.6f
                        )
                    )
                }
                fillOutline(
                    outline,
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.40f * hl), Color.Transparent),
                        startY = 0f, endY = size.height * 0.45f
                    )
                )
                fillOutline(
                    outline,
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.8f * hl), Color.White.copy(alpha = 0.1f * hl)),
                        start = Offset.Zero, end = Offset(size.width, size.height)
                    ),
                    style = Stroke(1.2.dp.toPx())
                )
            }

            "outline" -> {
                fillOutline(outline, SolidColor(spec.tint.copy(alpha = 0.04f)))
                fillOutline(
                    outline,
                    SolidColor(spec.tint.copy(alpha = 0.35f + 0.65f * hl)),
                    style = Stroke(rim)
                )
            }
        }
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text(label)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

/** The global Appearance controls (shown in the app's Settings page). */
@Composable
fun AppearanceSettings(store: SettingsStore) {
    Text(stringResource(R.string.ap_note), style = MaterialTheme.typography.bodySmall)

    // Live sample on a colorful backdrop so glass is easy to judge.
    val spec = rememberPanelSpec(store)
    Box(
        Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(listOf(Color(0xFFFFC857), Color(0xFF7AB8FF), Color(0xFFB78CFF)))
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .fillMaxWidth(0.7f)
                .height(76.dp)
                .panel(spec, RoundedCornerShape(spec.radius.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("14:35".localizeDigits(store.lang), fontSize = 30.sp, color = themeFg())
        }
    }

    ChoiceRow(
        label = stringResource(R.string.ap_style),
        options = listOf(
            "glass" to stringResource(R.string.style_glass),
            "card" to stringResource(R.string.style_card),
            "solid" to stringResource(R.string.style_solid),
            "outline" to stringResource(R.string.style_outline),
            "paper" to stringResource(R.string.style_paper),
            "sticker" to stringResource(R.string.style_sticker),
            "neon" to stringResource(R.string.style_neon),
            "aurora" to stringResource(R.string.style_aurora),
            "none" to stringResource(R.string.style_none),
        ),
        selected = store.get("ap_style", "glass")
    ) { store.put("ap_style", it) }

    ColorChips(stringResource(R.string.ap_tint), PanelTints, store.get("ap_tint", "auto")) {
        store.put("ap_tint", it)
    }
    LabeledSlider(stringResource(R.string.ap_opacity), store.getFloat("ap_opacity", 0.5f), 0f..1f) {
        store.putFloat("ap_opacity", it)
    }
    LabeledSlider(stringResource(R.string.ap_radius), store.getFloat("ap_radius", 22f), 0f..40f) {
        store.putFloat("ap_radius", it)
    }
    LabeledSlider(stringResource(R.string.ap_shadow), store.getFloat("ap_shadow", 0.5f), 0f..1f) {
        store.putFloat("ap_shadow", it)
    }
    ChoiceRow(
        label = stringResource(R.string.pg_effect),
        options = listOf(
            "slide" to stringResource(R.string.fx_slide),
            "fade" to stringResource(R.string.fx_fade),
            "zoom" to stringResource(R.string.fx_zoom),
            "depth" to stringResource(R.string.fx_depth),
            "cube" to stringResource(R.string.fx_cube),
            "flip" to stringResource(R.string.fx_flip),
        ),
        selected = store.get("page_effect", "slide")
    ) { store.put("page_effect", it) }
    LabeledSlider(stringResource(R.string.ap_highlight), store.getFloat("ap_highlight", 0.6f), 0f..1f) {
        store.putFloat("ap_highlight", it)
    }
}

package app.modlock

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ClockModule : LockModule {
    override val id = "clock"
    override val nameRes = R.string.mod_clock
    override val category = R.string.cat_time
    override val defaultW = 0.84f
    override val defaultH = 0.17f
    override val settings: List<Setting> = listOf(
        SwitchSetting("h24", R.string.clock_24h, true),
        SwitchSetting("seconds", R.string.clock_seconds, false),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val is24 = inst.b("h24", true)
        val sec = inst.b("seconds", false)
        val color = inst.color("color")
        var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(Unit) {
            while (true) {
                now = System.currentTimeMillis()
                delay(1000L - now % 1000L)
            }
        }
        val date = Date(now)
        val pattern = (if (is24) "HH:mm" else "hh:mm") + (if (sec) ":ss" else "")
        val time = SimpleDateFormat(pattern, Locale.ENGLISH).format(date).localizeDigits(inst.lang)
        val hour = SimpleDateFormat("H", Locale.ENGLISH).format(date).toInt()

        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val divisor = if (sec) 4.4f else 2.9f
            val fs = minOf(maxHeight.value * (if (is24) 0.78f else 0.6f), maxWidth.value / divisor)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    time, color = color, fontSize = fs.sp,
                    fontWeight = FontWeight.Light, maxLines = 1, softWrap = false
                )
                if (!is24) {
                    Text(
                        stringResource(if (hour < 12) R.string.am else R.string.pm),
                        color = color, fontSize = (fs * 0.3f).sp
                    )
                }
            }
        }
    }
}

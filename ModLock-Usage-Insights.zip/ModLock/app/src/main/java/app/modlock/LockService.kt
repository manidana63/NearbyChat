package app.modlock

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** Keeps a receiver alive; when the screen turns off, the screen is queued to show. */
class LockService : Service() {

    private var insightsReceiver: BroadcastReceiver? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_SCREEN_OFF) {
                val i = Intent(context, LockActivity::class.java).addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_NO_ANIMATION
                )
                try {
                    context.startActivity(i)
                } catch (_: Exception) {
                }
            }
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            AppsCache.invalidate()
            AppsCache.prewarm(context)
        }
    }

    override fun onCreate() {
        super.onCreate()
        refreshNotification()
        AppsCache.prewarm(this)
        insightsReceiver = UsageInsightsTracker.start(this)
        ContextCompat.registerReceiver(
            this, pkgReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED)
                addAction(Intent.ACTION_PACKAGE_REMOVED)
                addAction(Intent.ACTION_PACKAGE_REPLACED)
                addDataScheme("package")
            },
            ContextCompat.RECEIVER_EXPORTED
        )
        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    /** (Re)builds the notification using the chosen language and the on/off choice. */
    private fun refreshNotification() {
        val store = SettingsStore(this)
        val lctx = localizedContext(this, store.lang)
        val visible = store.getBool("notif_on", true)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_VISIBLE, lctx.getString(R.string.notif_ch_visible), NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_MIN, lctx.getString(R.string.notif_ch_min), NotificationManager.IMPORTANCE_MIN)
        )
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, if (visible) CH_VISIBLE else CH_MIN)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle(lctx.getString(R.string.service_notif))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(if (visible) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_MIN)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
        }
        ServiceCompat.startForeground(this, 1, notification, type)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        refreshNotification()
        return START_STICKY
    }

    override fun onDestroy() {
        UsageInsightsTracker.stop(this, insightsReceiver)
        insightsReceiver = null
        unregisterReceiver(receiver)
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CH_VISIBLE = "service_visible"
        const val CH_MIN = "service_min"

        fun channelId(ctx: Context): String =
            if (SettingsStore(ctx).getBool("notif_on", true)) CH_VISIBLE else CH_MIN

        /** Re-applies notification text / visibility if the service is running. */
        fun refresh(ctx: Context) {
            if (SettingsStore(ctx).getBool("service_enabled", false)) {
                ContextCompat.startForegroundService(ctx, Intent(ctx, LockService::class.java))
            }
        }
    }
}

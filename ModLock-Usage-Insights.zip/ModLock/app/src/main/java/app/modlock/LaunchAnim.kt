package app.modlock

import android.app.ActivityOptions
import android.content.Context
import android.os.Bundle

/** Opening animations for apps, contacts and notifications opened from a module. */
object LaunchAnim {
    const val EXTRA = "vitrin_anim"

    private fun res(style: String): Pair<Int, Int>? = when (style) {
        "fade" -> R.anim.launch_fade_in to R.anim.launch_fade_out
        "zoom" -> R.anim.launch_zoom_in to R.anim.launch_zoom_out
        "up" -> R.anim.launch_up_in to R.anim.launch_up_out
        "side" -> R.anim.launch_side_in to R.anim.launch_side_out
        "spin" -> R.anim.launch_spin_in to R.anim.launch_spin_out
        "pop" -> R.anim.launch_pop_in to R.anim.launch_pop_out
        "drop" -> R.anim.launch_drop_in to R.anim.launch_drop_out
        else -> null
    }

    /** Options for startActivity / PendingIntent.send, or null for the system default. */
    fun options(ctx: Context, store: SettingsStore, style: String): Bundle? {
        val s = if (style == "global" || style.isEmpty()) store.get("launch_anim", "default") else style
        val r = res(s) ?: return null
        return ActivityOptions.makeCustomAnimation(ctx, r.first, r.second).toBundle()
    }
}

val AnimStyles: List<Pair<String, Int>> = listOf(
    "default" to R.string.an_default,
    "fade" to R.string.an_fade,
    "zoom" to R.string.an_zoom,
    "up" to R.string.an_up,
    "side" to R.string.an_side,
    "spin" to R.string.an_spin,
    "pop" to R.string.an_pop,
    "drop" to R.string.an_drop,
)

/** Per-module choice; "global" follows Settings. */
val AnimSetting = ChoiceSetting(
    "anim", R.string.anim_label,
    listOf("global" to R.string.an_global) + AnimStyles,
    "global"
)

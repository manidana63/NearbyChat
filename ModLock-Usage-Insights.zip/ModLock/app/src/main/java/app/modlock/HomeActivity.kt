package app.modlock

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

/**
 * The home screen (launcher). It uses the same pages and modules as the lock screen, with its
 * own layout. Make Vitrin your home app in Android settings to use it. Long-press to edit.
 */
class HomeActivity : HostActivity() {
    override val rotationKey = "rot_home"
    private var editing by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        initHost()
        editing = intent.getBooleanExtra("edit", false)
        setContent {
            LocalizedTheme(store) {
                if (!editing) BackHandler { /* already home */ }
                val host = remember(editing) {
                    buildHost(
                        editing = editing,
                        unlock = { },
                        launch = { i ->
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startWithAnim(i)
                        },
                        runAfterUnlock = { action -> try { action() } catch (e: Exception) { } },
                        requestEdit = { editing = true }
                    )
                }
                LockScreenHost(store, host, "home") { editing = false }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        editing = intent.getBooleanExtra("edit", false)
    }
}

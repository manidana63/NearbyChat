package app.modlock

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.MathContext

/** A short note. Tap the module to write; the editor is a roomy card that saves as you type. */
object NoteModule : LockModule {
    override val id = "note"
    override val nameRes = R.string.mod_note
    override val category = R.string.cat_tools
    override val defaultW = 0.8f
    override val defaultH = 0.14f
    override val settings: List<Setting> = listOf(
        SliderSetting("size", R.string.note_size, 12f, 32f, 18f),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val color = inst.color("color")
        val size = inst.f("size", 18f)
        var text = inst.s("text", "")
        if (text.isBlank() && inst.isPreview) text = stringResource(R.string.note_sample)
        var open by remember { mutableStateOf(false) }
        val canEdit = !inst.editing && !inst.isPreview
        Box(
            Modifier.fillMaxSize().clickable(enabled = canEdit) { open = true },
            contentAlignment = Alignment.CenterStart
        ) {
            if (text.isBlank()) {
                Text(stringResource(R.string.note_tap), color = color.copy(alpha = 0.6f), fontSize = 14.sp)
            } else {
                Text(
                    text, color = color, fontSize = size.sp,
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            }
        }
        if (open) {
            NoteEditorDialog(
                title = stringResource(R.string.mod_note),
                lang = inst.lang,
                text = inst.s("text", ""),
                onText = { inst.put("text", it) },
                onDismiss = { open = false }
            )
        }
    }
}

class TodoItem(val t: String, val d: Boolean)

fun parseTodos(raw: String): List<TodoItem> = try {
    val a = JSONArray(raw)
    (0 until a.length()).map {
        val o = a.getJSONObject(it)
        TodoItem(o.getString("t"), o.optBoolean("d", false))
    }
} catch (e: Exception) {
    emptyList()
}

fun todosToJson(list: List<TodoItem>): String {
    val a = JSONArray()
    for (i in list) a.put(JSONObject().put("t", i.t).put("d", i.d))
    return a.toString()
}

/** A checklist. Tick tasks on the screen; tap "+" or an empty module to add and remove them. */
object TodoModule : LockModule {
    override val id = "todo"
    override val nameRes = R.string.mod_todo
    override val category = R.string.cat_tools
    override val defaultW = 0.8f
    override val defaultH = 0.2f
    override val settings: List<Setting> = listOf(
        SliderSetting("size", R.string.note_size, 12f, 28f, 16f),
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val color = inst.color("color")
        val size = inst.f("size", 16f)
        var list = parseTodos(inst.s("items", "[]"))
        val preview = list.isEmpty() && inst.isPreview
        if (preview) {
            list = listOf(
                TodoItem(stringResource(R.string.todo_s1), true),
                TodoItem(stringResource(R.string.todo_s2), false),
                TodoItem(stringResource(R.string.todo_s3), false),
            )
        }
        val shown = list
        var open by remember { mutableStateOf(false) }
        val canEdit = !inst.editing && !inst.isPreview

        if (shown.isEmpty()) {
            Box(
                Modifier.fillMaxSize().clickable(enabled = canEdit) { open = true },
                contentAlignment = Alignment.CenterStart
            ) {
                Text(stringResource(R.string.todo_empty_tap), color = color.copy(alpha = 0.6f), fontSize = 14.sp)
            }
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                shown.forEachIndexed { idx, item ->
                    Row(
                        Modifier.fillMaxWidth().clickable(enabled = canEdit) {
                            val next = shown.mapIndexed { i, x -> if (i == idx) TodoItem(x.t, !x.d) else x }
                            inst.put("items", todosToJson(next))
                        },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = item.d, onCheckedChange = null)
                        Text(
                            item.t,
                            color = if (item.d) color.copy(alpha = 0.5f) else color,
                            fontSize = size.sp,
                            textDecoration = if (item.d) TextDecoration.LineThrough else null,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    }
                }
                Text(
                    "+  " + stringResource(R.string.todo_add),
                    color = color.copy(alpha = 0.7f),
                    fontSize = (size * 0.9f).sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = canEdit) { open = true }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        }
        if (open) {
            TodoEditorDialog(
                title = stringResource(R.string.mod_todo),
                lang = inst.lang,
                items = parseTodos(inst.s("items", "[]")),
                onItems = { inst.put("items", todosToJson(it)) },
                onDismiss = { open = false }
            )
        }
    }
}

private class Calc {
    var cur by mutableStateOf("0")
    var acc: Double? = null
    var op: Char? = null
    var fresh = true
    var error by mutableStateOf(false)

    private fun fmt(d: Double): String {
        if (d.isNaN() || d.isInfinite()) {
            error = true
            return "0"
        }
        val s = BigDecimal(d).round(MathContext(12)).stripTrailingZeros().toPlainString()
        return if (s == "-0") "0" else s
    }

    private fun apply(a: Double, o: Char, b: Double): Double = when (o) {
        '+' -> a + b
        '-' -> a - b
        '*' -> a * b
        else -> if (b == 0.0) Double.NaN else a / b
    }

    fun press(k: String) {
        if (error && k != "C") return
        when (k) {
            "C" -> { cur = "0"; acc = null; op = null; fresh = true; error = false }
            "<" -> if (!fresh) cur = if (cur.length > 1) cur.dropLast(1) else "0"
            "+/-" -> if (cur != "0") cur = if (cur.startsWith("-")) cur.drop(1) else "-$cur"
            "%" -> { cur = fmt((cur.toDoubleOrNull() ?: 0.0) / 100.0) }
            "." -> {
                if (fresh) { cur = "0."; fresh = false }
                else if (!cur.contains('.')) cur += "."
            }
            "+", "-", "*", "/" -> {
                val c = cur.toDoubleOrNull() ?: 0.0
                val a = acc
                val o = op
                if (a != null && o != null && !fresh) {
                    val r = apply(a, o, c)
                    cur = fmt(r)
                    acc = if (error) null else r
                } else {
                    acc = c
                }
                op = k[0]
                fresh = true
            }
            "=" -> {
                val a = acc
                val o = op
                if (a != null && o != null) {
                    cur = fmt(apply(a, o, cur.toDoubleOrNull() ?: 0.0))
                    acc = null
                    op = null
                    fresh = true
                }
            }
            else -> {
                if (fresh) { cur = k; fresh = false }
                else if (cur.length < 14) cur = if (cur == "0") k else cur + k
            }
        }
    }
}

/** A small calculator. */
object CalculatorModule : LockModule {
    override val id = "calc"
    override val nameRes = R.string.mod_calc
    override val category = R.string.cat_tools
    override val defaultW = 0.7f
    override val defaultH = 0.42f
    override val settings: List<Setting> = listOf(
        ColorSetting("color", R.string.setting_color, "auto"),
    )

    @Composable
    override fun Content(inst: ModuleInstance) {
        val color = inst.color("color")
        val lang = inst.lang
        val calc = remember { Calc() }
        val keys = listOf(
            listOf("C", "<", "%", "/"),
            listOf("7", "8", "9", "*"),
            listOf("4", "5", "6", "-"),
            listOf("1", "2", "3", "+"),
            listOf("+/-", "0", ".", "="),
        )
        val errorText = stringResource(R.string.calc_error)
        val shown = if (calc.error) errorText else {
            val t = calc.cur.localizeDigits(lang)
            if (lang == "fa") t.replace('.', '\u066B') else t
        }

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val boxW = maxWidth
            val boxH = maxHeight
            val cellW = boxW / 4
            val cellH = (boxH * 0.75f) / 5
            val fontSize = (minOf(cellW.value, cellH.value) * 0.4f).coerceAtLeast(10f).sp
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.CenterEnd) {
                    Text(
                        shown, color = color, maxLines = 1,
                        fontSize = (boxH.value * 0.11f).coerceIn(14f, 40f).sp
                    )
                }
                // Keypads read left-to-right in every language.
                CompositionLocalProvider(
                    androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Ltr
                ) {
                    for (row in keys) {
                        Row(Modifier.fillMaxWidth().weight(0.6f)) {
                            for (k in row) {
                                val isOp = k in listOf("/", "*", "-", "+")
                                val bg = when {
                                    k == "=" -> Color(0xFF7C6CFF)
                                    isOp -> Color(0xFF7C6CFF).copy(alpha = 0.35f)
                                    else -> color.copy(alpha = 0.12f)
                                }
                                Box(
                                    Modifier.weight(1f).fillMaxHeight().padding(2.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(bg)
                                        .clickable(enabled = !inst.editing) { calc.press(k) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        when (k) {
                                            "*" -> "\u00D7"
                                            "/" -> "\u00F7"
                                            "-" -> "\u2212"
                                            "<" -> "\u232B"
                                            "+/-" -> "\u00B1"
                                            else -> k.localizeDigits(lang).replace(".", if (lang == "fa") "\u066B" else ".")
                                        },
                                        color = if (k == "=") Color.White else color,
                                        fontSize = fontSize
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

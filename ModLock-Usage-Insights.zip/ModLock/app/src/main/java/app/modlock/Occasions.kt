package app.modlock

import android.icu.util.Calendar
import android.icu.util.ULocale

class Occasion(val fa: String, val en: String, val holiday: Boolean) {
    fun name(lang: String) = if (lang == "fa") fa else en
}

private class JDay(val month: Int, val day: Int, val o: Occasion)
private class HDay(val month: Int, val day: Int, val o: Occasion)

// Fixed (solar) official occasions.
private val solar = listOf(
    JDay(1, 1, Occasion("نوروز", "Nowruz", true)),
    JDay(1, 2, Occasion("نوروز", "Nowruz", true)),
    JDay(1, 3, Occasion("نوروز", "Nowruz", true)),
    JDay(1, 4, Occasion("نوروز", "Nowruz", true)),
    JDay(1, 12, Occasion("روز جمهوری اسلامی", "Islamic Republic Day", true)),
    JDay(1, 13, Occasion("سیزده‌بدر", "Sizdah Bedar", true)),
    JDay(3, 14, Occasion("رحلت امام خمینی", "Demise of Imam Khomeini", true)),
    JDay(3, 15, Occasion("قیام ۱۵ خرداد", "15 Khordad Uprising", true)),
    JDay(11, 22, Occasion("پیروزی انقلاب اسلامی", "Victory of the Revolution", true)),
    JDay(12, 29, Occasion("ملی شدن صنعت نفت", "Oil Nationalization Day", true)),
)

// Lunar occasions. Dates are computed, so they can differ by a day from the official calendar.
private val lunar = listOf(
    HDay(1, 9, Occasion("تاسوعا", "Tasua", true)),
    HDay(1, 10, Occasion("عاشورا", "Ashura", true)),
    HDay(2, 20, Occasion("اربعین", "Arbaeen", true)),
    HDay(2, 28, Occasion("رحلت پیامبر و شهادت امام حسن", "Demise of the Prophet", true)),
    HDay(2, 30, Occasion("شهادت امام رضا", "Martyrdom of Imam Reza", true)),
    HDay(3, 17, Occasion("میلاد پیامبر و امام صادق", "Birth of the Prophet", true)),
    HDay(6, 3, Occasion("شهادت حضرت فاطمه", "Martyrdom of Fatima", true)),
    HDay(7, 13, Occasion("ولادت امام علی", "Birth of Imam Ali", true)),
    HDay(7, 27, Occasion("مبعث پیامبر", "Mab'ath", true)),
    HDay(8, 15, Occasion("ولادت امام زمان", "Birth of Imam Mahdi", true)),
    HDay(9, 21, Occasion("شهادت امام علی", "Martyrdom of Imam Ali", true)),
    HDay(10, 1, Occasion("عید فطر", "Eid al-Fitr", true)),
    HDay(10, 2, Occasion("تعطیل عید فطر", "Eid al-Fitr holiday", true)),
    HDay(10, 25, Occasion("شهادت امام صادق", "Martyrdom of Imam Sadiq", true)),
    HDay(12, 10, Occasion("عید قربان", "Eid al-Adha", true)),
    HDay(12, 18, Occasion("عید غدیر", "Eid al-Ghadir", true)),
)

/** Occasions of one day. [ms] is that day's time; jMonth/jDay are its Jalali month (1-12) and day. */
fun occasionsOn(ms: Long, jMonth: Int, jDay: Int): List<Occasion> {
    val out = mutableListOf<Occasion>()
    for (s in solar) if (s.month == jMonth && s.day == jDay) out.add(s.o)
    try {
        val h = Calendar.getInstance(ULocale("en@calendar=islamic"))
        h.timeInMillis = ms
        val hm = h.get(Calendar.MONTH) + 1
        val hd = h.get(Calendar.DAY_OF_MONTH)
        for (l in lunar) if (l.month == hm && l.day == hd) out.add(l.o)
    } catch (e: Exception) {
    }
    return out
}

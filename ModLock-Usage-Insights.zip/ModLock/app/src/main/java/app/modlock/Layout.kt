package app.modlock

import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

/**
 * Position and size are fractions (0..1) of the page. [page] is "x:y": the main page is "0:0"
 * and pages can be added to the left, right, above and below it.
 */
data class Placement(
    val uid: String,
    val type: String,
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val page: String = "0:0",
    val rot: Float = 0f,
    val group: String = "",
)

fun pageX(key: String): Int = key.substringBefore(":").toIntOrNull() ?: 0
fun pageY(key: String): Int = key.substringAfter(":").toIntOrNull() ?: 0
fun pageKey(x: Int, y: Int): String = "$x:$y"

/** The layout of one scene ("lock" or "home"): its pages and the modules on them. */
class LayoutStore(private val store: SettingsStore, private val scene: String) {
    val items = mutableStateListOf<Placement>()
    val pages = mutableStateListOf<String>()
    private val itemsKey = "layout_${scene}_v2"
    private val pagesKey = "pages_${scene}_v2"

    init {
        load()
    }

    private fun parseItems(raw: String): List<Placement> {
        val out = mutableListOf<Placement>()
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                Placement(
                    o.getString("uid"), o.getString("type"),
                    o.getDouble("x").toFloat(), o.getDouble("y").toFloat(),
                    o.getDouble("w").toFloat(), o.getDouble("h").toFloat(),
                    o.optString("page", "0:0").ifEmpty { "0:0" },
                    o.optDouble("rot", 0.0).toFloat(),
                    o.optString("group", "")
                )
            )
        }
        return out
    }

    private fun load() {
        var ok = false
        var raw = store.get(itemsKey, "")
        if (raw.isEmpty() && scene == "lock") raw = store.get("layout_v1", "") // older versions
        if (raw.isNotEmpty()) {
            try {
                items.addAll(parseItems(raw))
                ok = true
            } catch (e: Exception) {
                items.clear()
            }
        }
        if (!ok) items.addAll(defaults())

        val set = linkedSetOf("0:0")
        try {
            val arr = JSONArray(store.get(pagesKey, "[]"))
            for (i in 0 until arr.length()) set.add(arr.getString(i))
        } catch (e: Exception) {
        }
        for (p in items) set.add(p.page)
        pages.addAll(set)
        if (!ok) save()
    }

    private fun defaults(): List<Placement> =
        if (scene == "home") {
            listOf(
                Placement("hclock", "clock", 0.08f, 0.07f, 0.84f, 0.17f),
                Placement("happs", "apps", 0.05f, 0.55f, 0.9f, 0.22f),
                Placement("hall", "allapps", 0.04f, 0.04f, 0.92f, 0.9f, page = "0:1"),
            )
        } else {
            listOf(
                Placement("clock1", "clock", 0.08f, 0.07f, 0.84f, 0.17f),
                Placement("cal1", "calendar", 0.06f, 0.27f, 0.88f, 0.45f),
                Placement("slide1", "slide", 0.08f, 0.80f, 0.84f, 0.09f),
            )
        }

    fun save() {
        val arr = JSONArray()
        for (p in items) {
            arr.put(
                JSONObject()
                    .put("uid", p.uid).put("type", p.type)
                    .put("x", p.x.toDouble()).put("y", p.y.toDouble())
                    .put("w", p.w.toDouble()).put("h", p.h.toDouble())
                    .put("page", p.page).put("rot", p.rot.toDouble()).put("group", p.group)
            )
        }
        store.put(itemsKey, arr.toString())
        val pa = JSONArray()
        for (k in pages) pa.put(k)
        store.put(pagesKey, pa.toString())
    }

    fun get(uid: String): Placement? = items.firstOrNull { it.uid == uid }

    fun update(uid: String, f: (Placement) -> Placement) {
        val i = items.indexOfFirst { it.uid == uid }
        if (i >= 0) items[i] = f(items[i])
    }

    fun add(m: LockModule, page: String): Placement {
        val uid = "m" + System.currentTimeMillis().toString(36) + (0..99).random()
        val w = m.defaultW
        val h = m.defaultH
        val y = if (m.defaultY >= 0f) m.defaultY.coerceIn(0f, 1f - h) else ((1f - h) / 2f).coerceIn(0f, 1f)
        val p = Placement(uid, m.id, (1f - w) / 2f, y, w, h, page)
        items.add(p)
        save()
        return p
    }

    /** Adds one app icon (a small "appicon" module) on a page; [index] spreads several icons in rows of four. */
    fun addIcon(page: String, pkg: String, index: Int): Placement {
        val uid = "m" + System.currentTimeMillis().toString(36) + (0..999).random()
        val w = 0.2f
        val h = 0.11f
        val col = index % 4
        val row = index / 4
        val p = Placement(
            uid, "appicon",
            0.05f + col * 0.225f, (0.10f + row * 0.125f).coerceAtMost(1f - h), w, h, page
        )
        items.add(p)
        store.put("i_${uid}_pkg", pkg)
        save()
        return p
    }

    fun remove(uid: String) {
        val p = get(uid)
        items.removeAll { it.uid == uid }
        store.removePrefix("i_${uid}_")
        if (p != null && p.group.isNotEmpty()) cleanGroup(p.group)
        save()
    }

    // ---- groups ----

    fun members(gid: String): List<Placement> = items.filter { it.group == gid }

    fun group(uids: Collection<String>): String {
        val gid = "g" + System.currentTimeMillis().toString(36) + (0..99).random()
        for (u in uids) update(u) { it.copy(group = gid) }
        save()
        return gid
    }

    fun ungroup(gid: String) {
        for (m in members(gid)) update(m.uid) { it.copy(group = "") }
        store.removePrefix("i_${gid}_")
        save()
    }

    private fun cleanGroup(gid: String) {
        if (members(gid).size < 2) ungroup(gid)
    }

    /** Moves every member of a group by the same fraction, keeping the whole group on the page. */
    fun moveGroup(gid: String, dx: Float, dy: Float) {
        val ms = members(gid)
        if (ms.isEmpty()) return
        val minX = ms.minOf { it.x }
        val minY = ms.minOf { it.y }
        val maxX = ms.maxOf { it.x + it.w }
        val maxY = ms.maxOf { it.y + it.h }
        val ddx = dx.coerceIn(-minX, 1f - maxX)
        val ddy = dy.coerceIn(-minY, 1f - maxY)
        for (m in ms) update(m.uid) { it.copy(x = it.x + ddx, y = it.y + ddy) }
    }

    // ---- pages ----

    fun hasPage(x: Int, y: Int): Boolean = pages.contains(pageKey(x, y))

    fun addPage(x: Int, y: Int): Boolean {
        val k = pageKey(x, y)
        if (pages.contains(k)) return false
        pages.add(k)
        save()
        return true
    }

    /** A page may only be removed if every remaining page can still be reached from the main page. */
    fun canRemovePage(key: String): Boolean {
        if (key == "0:0") return false
        val rest = pages.filter { it != key }.toSet()
        val seen = mutableSetOf("0:0")
        val queue = ArrayDeque(listOf("0:0"))
        while (queue.isNotEmpty()) {
            val k = queue.removeFirst()
            for ((dx, dy) in listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)) {
                val n = pageKey(pageX(k) + dx, pageY(k) + dy)
                if (n in rest && seen.add(n)) queue.addLast(n)
            }
        }
        return seen.size == rest.size
    }

    fun removePage(key: String) {
        val doomed = items.filter { it.page == key }.map { it.uid }
        for (u in doomed) remove(u)
        pages.remove(key)
        save()
    }
}

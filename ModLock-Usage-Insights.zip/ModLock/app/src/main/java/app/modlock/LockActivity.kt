package app.modlock

import android.app.KeyguardManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Shows the lock scene. With extra "edit" = true it opens in edit mode instead. */
class LockActivity : HostActivity() {
    override val rotationKey = "rot_lock"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        enableEdgeToEdge()
        initHost()
        val editing = intent.getBooleanExtra("edit", false)
        val host = buildHost(
            editing = editing,
            unlock = { dismissThen(null, null) },
            launch = { dismissThen(it, null) },
            runAfterUnlock = { action -> dismissThen(null, action) },
            requestEdit = { }
        )
        setContent {
            LocalizedTheme(store) {
                if (!editing) BackHandler { /* back does nothing on this screen */ }
                LockScreenHost(store, host, "lock") { finish() }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val c = WindowCompat.getInsetsController(window, window.decorView)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    /**
     * Asks Android to dismiss the system lock (PIN / fingerprint if set), then optionally
     * starts an intent or runs an action, and closes this screen.
     */
    private fun dismissThen(intent: Intent?, action: (() -> Unit)?) {
        intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val go = {
            if (intent != null) {
                startWithAnim(intent)
            }
            if (action != null) {
                try { action() } catch (e: Exception) { }
            }
            finish()
        }
        val km = getSystemService(KeyguardManager::class.java)
        if (km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() { go() }
                override fun onDismissError() { finish() }
                override fun onDismissCancelled() { /* stay; user can try again */ }
            })
        } else {
            go()
        }
    }
}

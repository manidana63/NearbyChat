package app.modlock

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// ---- Declarative settings: a module lists them, the editor builds the UI ----

sealed class Setting(val key: String, @StringRes val labelRes: Int)

class SwitchSetting(key: String, @StringRes labelRes: Int, val default: Boolean) :
    Setting(key, labelRes)

/** options: value to label string resource */
class ChoiceSetting(
    key: String, @StringRes labelRes: Int,
    val options: List<Pair<String, Int>>, val default: String
) : Setting(key, labelRes)

class SliderSetting(
    key: String, @StringRes labelRes: Int,
    val min: Float, val max: Float, val default: Float
) : Setting(key, labelRes)

class TextSetting(
    key: String, @StringRes labelRes: Int, val default: String, val multiline: Boolean = false
) : Setting(key, labelRes)

/** Integer stepper (- / +). */
class StepSetting(
    key: String, @StringRes labelRes: Int,
    val min: Int, val max: Int, val default: Int
) : Setting(key, labelRes)

/** default is an RRGGBB hex string, or "auto" to follow the phone theme */
class ColorSetting(key: String, @StringRes labelRes: Int, val default: String) :
    Setting(key, labelRes)

// ---- Host / instance ----

class HostApi(
    val store: SettingsStore,
    val activity: ComponentActivity?,
    val editing: Boolean,
    val unlock: () -> Unit,
    val pickBackground: () -> Unit,
    val widgets: WidgetSupport?,
    /** Starts an intent, asking for the system unlock first if needed. */
    val launch: (Intent) -> Unit,
    val requestContacts: ((Boolean) -> Unit) -> Unit,
    val pickPhotos: ((List<Uri>) -> Unit) -> Unit,
    /** Asks for the system unlock (if needed), then runs the action (used to open notifications). */
    val runAfterUnlock: (() -> Unit) -> Unit,
    /** Home screen only: long-press asks to start editing. */
    val requestEdit: () -> Unit,
) {
    val lang: String get() = store.lang
}

/** One placed copy of a module. Its settings live under "i_<uid>_<key>". */
class ModuleInstance(val uid: String, val host: HostApi, val grouped: Boolean = false) {
    val lang: String get() = host.lang
    /** True when drawn as a sample in the Add-module list. */
    val isPreview: Boolean get() = uid.startsWith("pv_")
    val editing: Boolean get() = host.editing
    private fun k(key: String) = "i_${uid}_$key"

    fun s(key: String, def: String): String = host.store.get(k(key), def)
    fun put(key: String, value: String) = host.store.put(k(key), value)
    fun b(key: String, def: Boolean): Boolean = host.store.getBool(k(key), def)
    fun putB(key: String, value: Boolean) = host.store.putBool(k(key), value)
    fun f(key: String, def: Float): Float = s(key, def.toString()).toFloatOrNull() ?: def
    fun putF(key: String, value: Float) = put(key, value.toString())

    /** Opens an app / contact with the opening animation (this module's choice, or the global one). */
    fun launch(intent: Intent) {
        intent.putExtra(LaunchAnim.EXTRA, s("anim", "global"))
        host.launch(intent)
    }

    /** The same animation as an options bundle (for PendingIntent.send / startActivity). */
    fun animOptions(): Bundle? {
        val a = host.activity ?: return null
        return LaunchAnim.options(a, host.store, s("anim", "global"))
    }

    @Composable
    fun color(key: String, def: String = "auto"): Color {
        val v = s(key, def)
        return if (v == "auto") themeFg() else hexColor(v)
    }
}

/**
 * A lock screen module. To add a new one:
 *  1. create `object MyModule : LockModule { ... }`
 *  2. add it to [ModuleRegistry.all]
 * Simple settings go in [settings]; anything special in [CustomSettings].
 */
interface LockModule {
    val id: String
    @get:StringRes val nameRes: Int
    /** Group shown in the Add-module list. */
    @get:StringRes val category: Int
    val defaultW: Float
    val defaultH: Float

    /** Default top edge (0..1) when added; negative = centered vertically. */
    val defaultY: Float get() = -1f
    val settings: List<Setting> get() = emptyList()

    /** True if the module draws its own panel (so the host does not wrap it). */
    val ownsPanel: Boolean get() = false

    /** Space between the panel edge and the module content. */
    val panelPadding: Dp get() = 10.dp

    /** Only one copy allowed on the screen. */
    val singleton: Boolean get() = false

    /** True if this module can unlock the phone (at least one must always exist). */
    val unlocks: Boolean get() = false

    @Composable fun Content(inst: ModuleInstance)

    @Composable fun CustomSettings(inst: ModuleInstance) {}

    fun onRemoved(inst: ModuleInstance) {}
}

object ModuleRegistry {
    val all: List<LockModule> = listOf(
        // time and info
        ClockModule, AnalogClockModule, CalendarModule, WeatherModule, BatteryModule,
        // quick access
        ContactsModule, AppsModule, AllAppsModule, AppIconModule, AppFolderModule, DockModule, NotificationsModule, QuickSettingsModule, MusicModule,
        FlashlightModule, VpnModule, WidgetModule,
        // daily tools
        NoteModule, TodoModule, AlarmModule, TimerModule, CalculatorModule,
        // personal
        PhotoFrameModule, WorldClockModule, QuoteModule, CountdownModule, NetworkModule,
        // entry
        SlideUnlockModule, PinModule,
    )

    /** Order of the groups in the Add-module list. */
    val categories: List<Int> = listOf(
        R.string.cat_time, R.string.cat_access, R.string.cat_tools, R.string.cat_fun, R.string.cat_entry
    )

    fun find(id: String): LockModule? = all.firstOrNull { it.id == id }
}

fun SettingsStore.isEnabled(m: LockModule): Boolean = getBool("mod_${m.id}_on", true)

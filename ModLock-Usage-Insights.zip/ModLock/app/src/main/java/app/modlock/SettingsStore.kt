package app.modlock

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateMapOf

/**
 * Key/value settings, observable from Compose. All instances share ONE in-memory copy, so a
 * change made in Settings is seen at once by the lock screen, the home screen and the service
 * (before, each screen had its own copy and could show old values until it was reopened).
 */
class SettingsStore(context: Context) {
    init {
        init(context.applicationContext)
    }

    fun get(key: String, default: String): String = cache[key] ?: default

    fun put(key: String, value: String) {
        cache[key] = value
        sp?.edit()?.putString(key, value)?.apply()
    }

    fun getBool(key: String, default: Boolean): Boolean = get(key, default.toString()).toBoolean()
    fun putBool(key: String, value: Boolean) = put(key, value.toString())

    fun getFloat(key: String, default: Float): Float = get(key, default.toString()).toFloatOrNull() ?: default
    fun putFloat(key: String, value: Float) = put(key, value.toString())

    fun removePrefix(prefix: String) {
        val keys = cache.keys.filter { it.startsWith(prefix) }
        for (k in keys) cache.remove(k)
        val e = sp?.edit() ?: return
        for (k in sp!!.all.keys) if (k.startsWith(prefix)) e.remove(k)
        e.apply()
    }

    /** A copy of everything stored (used by backup). */
    fun snapshot(): Map<String, String> = cache.toMap()

    val lang: String get() = get("lang", "fa")

    companion object {
        private val cache = mutableStateMapOf<String, String>()
        private var sp: SharedPreferences? = null

        @Synchronized
        private fun init(ctx: Context) {
            if (sp != null) return
            val p = ctx.getSharedPreferences("modlock", Context.MODE_PRIVATE)
            for ((k, v) in p.all) if (v is String) cache[k] = v
            sp = p
        }
    }
}

package app.modlock

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp

private val Palette = listOf(
    "auto", "FFFFFF", "FFEB3B", "4DD0E1", "81C784", "FFB74D", "F48FB1", "000000"
)

/** A row of color circles. "auto" follows the phone theme. */
@Composable
fun ColorChips(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column {
        if (label.isNotEmpty()) Text(label)
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            for (hex in options) {
                val sel = selected.equals(hex, ignoreCase = true)
                val fill = if (hex == "auto") {
                    Modifier.background(Brush.horizontalGradient(listOf(Color.White, Color(0xFF1B1B1F))))
                } else {
                    Modifier.background(hexColor(hex))
                }
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .then(fill)
                        .border(
                            if (sel) 3.dp else 1.dp,
                            if (sel) MaterialTheme.colorScheme.primary else Color.Gray,
                            CircleShape
                        )
                        .clickable { onSelect(hex) }
                )
            }
        }
    }
}

/** Builds the settings UI for a module from its declarative [Setting] list. */
@Composable
fun SettingControls(inst: ModuleInstance, settings: List<Setting>) {
    for (s in settings) {
        when (s) {
            is SwitchSetting -> SwitchRow(stringResource(s.labelRes), inst.b(s.key, s.default)) {
                inst.putB(s.key, it)
            }

            is ChoiceSetting -> ChoiceRow(
                label = stringResource(s.labelRes),
                options = s.options.map { it.first to stringResource(it.second) },
                selected = inst.s(s.key, s.default)
            ) { inst.put(s.key, it) }

            is SliderSetting -> Column {
                Text(stringResource(s.labelRes))
                Slider(
                    value = inst.f(s.key, s.default),
                    onValueChange = { inst.putF(s.key, it) },
                    valueRange = s.min..s.max
                )
            }

            is StepSetting -> {
                val v = (inst.s(s.key, s.default.toString()).toIntOrNull() ?: s.default)
                    .coerceIn(s.min, s.max)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(s.labelRes), Modifier.weight(1f))
                    PillButton("\u2212") { if (v > s.min) inst.put(s.key, (v - 1).toString()) }
                    Text(
                        v.toString().localizeDigits(inst.lang),
                        Modifier.padding(horizontal = 14.dp)
                    )
                    PillButton("+") { if (v < s.max) inst.put(s.key, (v + 1).toString()) }
                }
            }

            is TextSetting -> OutlinedTextField(
                value = inst.s(s.key, s.default),
                onValueChange = { inst.put(s.key, it) },
                label = { Text(stringResource(s.labelRes)) },
                singleLine = !s.multiline,
                minLines = if (s.multiline) 3 else 1,
                modifier = Modifier.fillMaxWidth()
            )

            is ColorSetting -> ColorChips(
                stringResource(s.labelRes), Palette, inst.s(s.key, s.default)
            ) { inst.put(s.key, it) }
        }
    }
}

/** Settings for the default (no image/video) background gradient. */
@Composable
fun GradientSettings(store: SettingsStore) {
    Text(stringResource(R.string.bg_gradient), style = MaterialTheme.typography.titleMedium)
    Text(stringResource(R.string.bg_note), style = MaterialTheme.typography.bodySmall)
    ChoiceRow(
        label = stringResource(R.string.grad_style),
        options = listOf(
            "vertical" to stringResource(R.string.grad_vertical),
            "horizontal" to stringResource(R.string.grad_horizontal),
            "diagonal" to stringResource(R.string.grad_diagonal),
            "radial" to stringResource(R.string.grad_radial),
        ),
        selected = store.get("bg_style", "vertical")
    ) { store.put("bg_style", it) }
    ChoiceRow(
        label = stringResource(R.string.grad_palette),
        options = listOf(
            "theme" to stringResource(R.string.grad_theme),
            "ocean" to stringResource(R.string.grad_ocean),
            "sunset" to stringResource(R.string.grad_sunset),
            "purple" to stringResource(R.string.grad_purple),
            "forest" to stringResource(R.string.grad_forest),
            "rose" to stringResource(R.string.grad_rose),
            "mono" to stringResource(R.string.grad_mono),
            "custom" to stringResource(R.string.grad_custom),
        ),
        selected = store.get("bg_palette", "theme")
    ) { store.put("bg_palette", it) }
    if (store.get("bg_palette", "theme") == "custom") {
        ColorChips(stringResource(R.string.grad_start), GradPalette, store.get("bg_c1", "5B2A86")) {
            store.put("bg_c1", it)
        }
        ColorChips(stringResource(R.string.grad_end), GradPalette, store.get("bg_c2", "2C5364")) {
            store.put("bg_c2", it)
        }
    }
    SwitchRow(stringResource(R.string.grad_animate), store.getBool("bg_anim", false)) {
        store.putBool("bg_anim", it)
    }
}

/** A bottom panel with a dimmed backdrop. Must be called inside a Box. */
@Composable
fun BoxScope.EditorPanel(title: String, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.4f))
            .pointerInput(Unit) { detectTapGestures { onClose() } }
    )
    Surface(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .fillMaxHeight(0.6f)
            .pointerInput(Unit) { detectTapGestures { } },
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(Modifier.navigationBarsPadding().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                TextButton(onClick = onClose) { Text(stringResource(R.string.editor_close)) }
            }
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                content = content
            )
        }
    }
}

@Composable
fun ModuleRow(name: String, disabled: Boolean, onClick: () -> Unit) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(onSurface.copy(alpha = if (disabled) 0.04f else 0.10f))
            .clickable(enabled = !disabled, onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name, Modifier.weight(1f), color = if (disabled) Color.Gray else onSurface)
        if (disabled) Text(stringResource(R.string.already_added), color = Color.Gray)
    }
}

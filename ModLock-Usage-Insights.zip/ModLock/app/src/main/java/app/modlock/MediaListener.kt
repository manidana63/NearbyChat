package app.modlock

import android.service.notification.NotificationListenerService

/**
 * Empty on purpose: when the user grants "notification access" to this app, Android lets
 * the music and notifications modules read media sessions and the active notifications.
 */
class MediaListener : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
        super.onListenerDisconnected()
    }

    companion object {
        @Volatile
        var instance: MediaListener? = null
    }
}

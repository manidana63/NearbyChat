package app.modlock

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

/**
 * Shared base for the lock screen and the home screen (launcher): both draw the same page
 * system, so they share the pickers, widget hosting and the host API given to modules.
 */
abstract class HostActivity : ComponentActivity() {

    protected lateinit var store: SettingsStore

    /** Settings key that says whether this screen may rotate ("rot_lock" / "rot_home"). */
    protected abstract val rotationKey: String
    protected var widgets: WidgetSupport? = null
    private var contactsCb: ((Boolean) -> Unit)? = null
    private var photosCb: ((List<Uri>) -> Unit)? = null

    private val pickMedia = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) MainScope().launch { importBackground(this@HostActivity, store, uri) }
    }

    private val contactsPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val cb = contactsCb
        contactsCb = null
        cb?.invoke(ok)
    }

    private val photosPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val cb = photosCb
        photosCb = null
        cb?.invoke(uris)
    }

    protected fun initHost() {
        store = SettingsStore(this)
        live.add(this)
        AppsCache.prewarm(this)
        widgets = try { WidgetSupport(this) } catch (e: Exception) { null }
        applyOrientation()
    }

    private fun applyOrientation() {
        val allow = store.getBool(rotationKey, true)
        requestedOrientation = if (allow) {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }

    /** Starts an intent, using the opening animation a module attached to it (if any). */
    protected fun startWithAnim(intent: Intent) {
        val style = intent.getStringExtra(LaunchAnim.EXTRA)
        intent.removeExtra(LaunchAnim.EXTRA)
        val opts = if (style != null) LaunchAnim.options(this, store, style) else null
        try {
            if (opts != null) startActivity(intent, opts) else startActivity(intent)
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        live.remove(this)
        super.onDestroy()
    }

    fun refreshOrientation() {
        if (::store.isInitialized) applyOrientation()
    }

    override fun onResume() {
        super.onResume()
        if (::store.isInitialized) applyOrientation()
    }

    protected fun buildHost(
        editing: Boolean,
        unlock: () -> Unit,
        launch: (Intent) -> Unit,
        runAfterUnlock: (() -> Unit) -> Unit,
        requestEdit: () -> Unit,
    ): HostApi = HostApi(
        store = store,
        activity = this,
        editing = editing,
        unlock = unlock,
        pickBackground = { pickMedia.launch(arrayOf("image/*", "video/*")) },
        widgets = widgets,
        launch = launch,
        requestContacts = { cb ->
            contactsCb = cb
            contactsPerm.launch(Manifest.permission.READ_CONTACTS)
        },
        pickPhotos = { cb ->
            photosCb = cb
            photosPicker.launch(arrayOf("image/*"))
        },
        runAfterUnlock = runAfterUnlock,
        requestEdit = requestEdit,
    )

    override fun onStart() {
        super.onStart()
        widgets?.start()
    }

    override fun onStop() {
        widgets?.stop()
        super.onStop()
    }

    companion object {
        private val live = mutableSetOf<HostActivity>()

        /** Recreates the open lock / home screens and refreshes the service so every setting is applied. */
        fun applyAll(ctx: android.content.Context) {
            for (a in live.toList()) a.recreate()
            LockService.refresh(ctx)
        }

        fun refreshAllOrientation() {
            for (a in live.toList()) a.refreshOrientation()
        }
    }
}

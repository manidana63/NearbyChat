package app.modlock

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap

/** Decoded icons kept in memory (about 12 MB) so scrolling never decodes the same icon twice. */
object IconCache {
    private val cache = object : LruCache<String, ImageBitmap>(12 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }

    fun get(key: String): ImageBitmap? = cache.get(key)

    fun put(key: String, value: ImageBitmap) {
        cache.put(key, value)
    }

    fun appIcon(pm: PackageManager, pkg: String): ImageBitmap? {
        cache.get("app:$pkg")?.let { return it }
        val bmp = try { pm.getApplicationIcon(pkg).toImageBitmapSafe(128) } catch (e: Exception) { null }
        if (bmp != null) cache.put("app:$pkg", bmp)
        return bmp
    }
}

/** The list of launchable apps (package, label), loaded once and refreshed when apps change. */
object AppsCache {
    @Volatile private var list: List<Pair<String, String>>? = null
    @Volatile private var time = 0L

    /** Whatever is cached right now (may be null on the very first start). */
    fun peek(): List<Pair<String, String>>? = list

    fun invalidate() {
        list = null
        time = 0L
    }

    /** Blocking: call it off the main thread. Returns the cached list when it is fresh. */
    fun load(ctx: Context): List<Pair<String, String>> {
        val cur = list
        if (cur != null && System.currentTimeMillis() - time < 10 * 60 * 1000L) return cur
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val res = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
        list = res
        time = System.currentTimeMillis()
        return res
    }

    /** Loads the app list and all icons in the background so the drawer opens instantly. */
    fun prewarm(ctx: Context) {
        val app = ctx.applicationContext
        Thread {
            try {
                val apps = load(app)
                val pm = app.packageManager
                for ((pkg, _) in apps) IconCache.appIcon(pm, pkg)
            } catch (e: Exception) {
            }
        }.start()
    }
}

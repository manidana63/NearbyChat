package app.modlock

import org.json.JSONObject

/** Saves / restores every setting (layout, styles, module settings) as one JSON file. */
object Backup {
    fun export(store: SettingsStore): String {
        val o = JSONObject()
        for ((k, v) in store.snapshot()) o.put(k, v)
        return o.toString(2)
    }

    /** Returns how many values were restored, or -1 if the text is not a backup. */
    fun import(store: SettingsStore, json: String): Int {
        return try {
            val o = JSONObject(json)
            var n = 0
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                store.put(k, o.getString(k))
                n++
            }
            n
        } catch (e: Exception) {
            -1
        }
    }
}

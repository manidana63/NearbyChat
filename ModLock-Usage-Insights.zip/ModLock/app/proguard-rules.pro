# Vitrin R8 rules. Compose and AndroidX ship their own rules; these are extra safety.
-dontwarn javax.annotation.**
-keep class app.modlock.MediaListener { *; }
-keep class app.modlock.LockService { *; }
-keep class app.modlock.BootReceiver { *; }

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Every build is signed with the SAME key (vitrin.keystore), so a new APK installs over the old
// one as an update and keeps all your settings. Each CI run also gets a higher version number.
val runNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toIntOrNull() ?: 1

android {
    namespace = "app.modlock"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.modlock"
        minSdk = 26
        targetSdk = 34
        versionCode = runNumber
        versionName = "0.1.$runNumber"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    signingConfigs {
        create("vitrin") {
            storeFile = file("vitrin.keystore")
            storePassword = "vitrin123"
            keyAlias = "vitrin"
            keyPassword = "vitrin123"
            storeType = "pkcs12"
        }
    }
    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("vitrin")
        }
        // The release build is much faster than debug (code shrinking + optimization).
        release {
            signingConfig = signingConfigs.getByName("vitrin")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.compose.material:material-icons-core")
}

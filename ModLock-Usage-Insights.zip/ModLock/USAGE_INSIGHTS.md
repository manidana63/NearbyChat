# Usage Insights module

The Usage Insights dashboard is integrated into Vitrin's existing Android/Kotlin/Jetpack Compose app.

## Where to open it

Main screen → Lock tab → **Usage insights**.

## Included reports

- Unlock events (`ACTION_USER_PRESENT`)
- Screen-on duration (`ACTION_SCREEN_ON` / `ACTION_SCREEN_OFF`)
- Device-wide received and sent traffic (`TrafficStats` cumulative counters)
- Today's top apps by foreground duration (`UsageStatsManager`)
- Latest battery level, charge-session count, and accumulated charging duration
- Today / last 7 days filters, unlock chart, independent collection switches, and local data clearing

## Important Android behavior

- Unlock, screen duration, battery events, and network sampling are collected by a receiver attached to the app's existing `LockService`. Keep the Vitrin lock service enabled for continuous collection. If it is stopped, those live events are not collected during that interval.
- Per-app usage requires the user to grant **Usage access** manually from Android settings. Android may update usage records with a delay.
- Network figures are device-wide cumulative byte counters, not per-app or Wi-Fi/mobile-separated totals. Samples are taken when the service starts and on screen transitions; data can be missed while the service is stopped or across device restarts.
- The app cannot reconstruct data from before this module was enabled. All report data is stored locally in private app preferences; no telemetry or cloud upload was added.
- Dated report entries older than 365 days are pruned when the tracker starts.
